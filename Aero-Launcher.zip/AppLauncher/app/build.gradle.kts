plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.applauncher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.applauncher"
        minSdk = 24
        targetSdk = 34
        versionCode = 8
        versionName = "3.4"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // সহজে install করার জন্য debug key দিয়ে sign করা হচ্ছে
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    lint {
        // release build-এ lint-এর কারণে যেন build না থামে
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.biometric:biometric:1.1.0")
}
