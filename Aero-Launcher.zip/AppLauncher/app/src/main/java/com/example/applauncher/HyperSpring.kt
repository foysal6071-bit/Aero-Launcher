package com.example.applauncher

import android.view.animation.Interpolator
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * HyperOS-এর spring motion-এর কাছাকাছি interpolator (0..1 সময় → 0..1 অবস্থান)।
 * damping < 1 হলে সামান্য overshoot, = 1 হলে overshoot ছাড়া নরম থামা।
 */
class HyperSpring(private val damping: Float, private val omega: Float = 9f) : Interpolator {
    override fun getInterpolation(input: Float): Float {
        if (input <= 0f) return 0f
        if (input >= 1f) return 1f
        val t = input.toDouble()
        val z = damping.toDouble()
        val w = omega.toDouble()
        val v = if (z < 1.0) {
            val wd = w * sqrt(1.0 - z * z)
            1.0 - exp(-z * w * t) * (cos(wd * t) + (z * w / wd) * sin(wd * t))
        } else {
            1.0 - exp(-w * t) * (1.0 + w * t)
        }
        // শেষে ঝাঁকুনি এড়াতে শেষ অংশে ১-এর সাথে মিশিয়ে দিই
        val tail = ((input - 0.9f) / 0.1f).coerceIn(0f, 1f)
        return (v * (1 - tail) + tail).toFloat()
    }

    companion object {
        val OPEN = HyperSpring(0.9f, 9f)   // সামান্য নরম overshoot
        val CLOSE = HyperSpring(1f, 10f)   // দ্রুত, overshoot ছাড়া
    }
}
