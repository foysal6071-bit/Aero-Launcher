package com.example.applauncher

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView

/** Home-এ drag চলার সময় কোন অ্যাপের আসল আইকন লুকানো থাকবে (তার বদলে আঙুলের সাথে ভাসমান কপি চলে)। */
class DragState {
    var hiddenPkg: String? = null
}

class AppAdapter(
    showLabel: Boolean,
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo, View) -> Unit,
    private val drag: DragState = DragState()
) : RecyclerView.Adapter<AppAdapter.VH>() {

    // drag করে জায়গা বদলানোর সময় list সঙ্গে সঙ্গে বদলাতে হয়, তাই নিজের mutable list রাখা হয়েছে
    private var items: MutableList<AppInfo> = mutableListOf()

    /** এখন যে ক্রমে আইকনগুলো দেখাচ্ছে */
    val current: List<AppInfo> get() = items

    private fun getItem(position: Int): AppInfo = items[position]

    override fun getItemCount(): Int = items.size

    /** drag-এর সময় একটি আইকনকে [from] থেকে [to] অবস্থানে সরায় */
    fun move(from: Int, to: Int) {
        if (from !in items.indices || to !in items.indices || from == to) return
        items.add(to, items.removeAt(from))
        notifyItemMoved(from, to)
    }

    fun indexOf(pkg: String): Int = items.indexOfFirst { it.packageName == pkg }

    /** নামের অক্ষরের মাপ (sp) */
    var labelSp: Float = 11.5f
        set(value) {
            if (field != value) {
                field = value
                notifyDataSetChanged()
            }
        }

    /** চাপলে আইকন ছোট হওয়ার animation */
    var pressAnim: Boolean = true

    var showLabel: Boolean = showLabel
        set(value) {
            if (field != value) {
                field = value
                notifyDataSetChanged()
            }
        }

    /** আইকনের দেখানোর সাইজ (px); 0 হলে 62dp */
    var iconSize: Int = 0
        set(value) {
            if (field != value) {
                field = value
                notifyDataSetChanged()
            }
        }

    fun submit(list: List<AppInfo>) {
        val old = items
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = list.size
            override fun areItemsTheSame(o: Int, n: Int) = old[o].packageName == list[n].packageName
            override fun areContentsTheSame(o: Int, n: Int) =
                old[o].label == list[n].label && old[o].icon === list[n].icon
        }, true) // true = জায়গা বদল সরে যাওয়ার animation হিসেবে দেখায়, মুছে-বসানো হিসেবে নয়
        items = list.toMutableList()
        diff.dispatchUpdatesTo(this)
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val label: TextView = view.findViewById(R.id.appLabel)
        val badge: TextView = view.findViewById(R.id.appBadge)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        val vh = VH(v)
        // listener একবারই বসে; প্রতিবার bind-এ নতুন object বানানো হয় না
        v.setOnClickListener {
            val p = vh.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(getItem(p), v)
        }
        v.setOnLongClickListener {
            val p = vh.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onLongClick(getItem(p), v)
            true
        }
        // HyperOS-এর মতো: চাপলে আইকন একটু ছোট হয়, ছাড়লে নরম bounce করে ফিরে আসে
        v.setOnTouchListener { view, e ->
            if (!pressAnim) return@setOnTouchListener false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate()
                    .scaleX(0.91f).scaleY(0.91f)
                    .setDuration(110)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                    .scaleX(1f).scaleY(1f)
                    .setDuration(260)
                    .setInterpolator(OvershootInterpolator(1.6f))
                    .start()
            }
            false
        }
        return vh
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = getItem(position)
        val size = if (iconSize > 0) iconSize else (62 * holder.itemView.resources.displayMetrics.density).toInt()
        val lp = holder.icon.layoutParams
        if (lp.width != size || lp.height != size) {
            lp.width = size
            lp.height = size
            holder.icon.layoutParams = lp
        }
        holder.icon.setImageBitmap(app.icon)
        holder.label.text = app.label
        if (holder.label.textSize != labelSp * holder.label.resources.displayMetrics.scaledDensity) {
            holder.label.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, labelSp)
        }
        holder.label.visibility = if (showLabel) View.VISIBLE else View.GONE
        val n = if (BadgeStore.enabled) BadgeStore.count(app.packageName) else 0
        if (n > 0) {
            holder.badge.text = if (n > 99) "99+" else n.toString()
            holder.badge.visibility = View.VISIBLE
        } else {
            holder.badge.visibility = View.GONE
        }
        // এই আইকনটা এখন আঙুলের সাথে ভাসছে — আসল জায়গাটা ফাঁকা থাকে
        holder.itemView.visibility = if (app.packageName == drag.hiddenPkg) View.INVISIBLE else View.VISIBLE
    }
}
