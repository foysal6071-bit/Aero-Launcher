package com.example.applauncher

import android.app.Activity
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.ExecutorService

/**
 * Today View (Home-এর বাঁয়ের পেজ): Android widget দেখানো, যোগ করা ও সরানো।
 * Widget বাঁধা/configure করার সিস্টেম ডায়ালগের ফল MainActivity থেকে [onActivityResult]-এ আসে।
 */
class WidgetController(
    private val activity: AppCompatActivity,
    private val store: HomeStore,
    private val settings: LauncherSettings,
    private val worker: ExecutorService,
    private val host: Host
) {

    interface Host {
        fun isDarkUi(): Boolean
        fun dur(ms: Int): Long
        fun haptic(v: View)
        fun toast(msg: String)
        /** Home pager-এর [index] নম্বর পেজে যাও (0 = Today View) */
        fun showPage(index: Int)
    }

    private companion object {
        const val REQ_BIND = 7001
        const val REQ_CONFIGURE = 7002
        const val HOST_ID = 1024
    }

    private val manager: AppWidgetManager = AppWidgetManager.getInstance(activity)
    private val widgetHost = LauncherWidgetHost(activity.applicationContext, HOST_ID)
    private var pendingId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null
    private var sig = ""

    private val container = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(24), dp(16), dp(32))
    }

    /** HomePagerAdapter-এর প্রথম পেজ হিসেবে বসে */
    val page: ScrollView = ScrollView(activity).apply {
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        clipToPadding = false
        addView(container)
    }

    private fun dp(v: Int): Int = (v * activity.resources.displayMetrics.density).toInt()

    // ---------- Activity lifecycle ----------

    fun startListening() {
        try {
            widgetHost.startListening()
        } catch (_: Exception) {
        }
    }

    fun stopListening() {
        try {
            widgetHost.stopListening()
        } catch (_: Exception) {
        }
    }

    /** মেমরি ছাড়ার সময়: widget view ফেলে দেয় (পরে [rebuild] আবার বানাবে) */
    fun release() {
        container.removeAllViews()
    }

    /** (x, y) স্ক্রিন-বিন্দুটা কোনো widget বা "Add widget" বাটনের ওপর কিনা */
    fun isOverWidget(x: Float, y: Float): Boolean {
        for (i in 0 until container.childCount) {
            val v = container.getChildAt(i)
            if ((v is AppWidgetHostView || v.tag == "addWidget") && isPointInView(v, x, y)) return true
        }
        return false
    }

    // ---------- পেজ সাজানো ----------

    fun rebuild() {
        // widget-এর তালিকা বা lock না বদলালে নতুন করে বানাই না (প্রতিটা সেটিং বদলে widget ঝিলিক দিত)
        val newSig = store.widgetIds.joinToString(",") + "|" + settings.lockLayout
        if (newSig == sig && container.childCount > 0) return
        sig = newSig
        container.removeAllViews()
        container.alpha = 0f
        container.animate().alpha(1f).setDuration(host.dur(260)).setInterpolator(SmoothCurve).start()
        container.addView(TextView(activity).apply {
            text = "Today"
            setTextColor(Color.WHITE)
            textSize = 34f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setShadowLayer(8f, 0f, 2f, Color.parseColor("#66000000"))
            setPadding(dp(4), 0, 0, dp(14))
        })

        val dead = mutableListOf<Int>()
        store.widgetIds.toList().forEach { id ->
            val info = manager.getAppWidgetInfo(id)
            if (info == null) {
                dead.add(id)
                return@forEach
            }
            try {
                val hv = widgetHost.createView(activity, id, info)
                val h = maxOf(info.minHeight, dp(110)).coerceAtMost(dp(420))
                hv.clipToOutline = true
                hv.outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, dp(22).toFloat())
                    }
                }
                hv.setOnLongClickListener {
                    host.haptic(hv)
                    IosMenu.showAtView(
                        activity, hv,
                        listOf(IosMenuItem("Remove Widget", destructive = true) { remove(id) }),
                        host.isDarkUi()
                    )
                    true
                }
                container.addView(
                    hv,
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { bottomMargin = dp(14) }
                )
                hv.post {
                    val d = activity.resources.displayMetrics.density
                    val wDp = (hv.width / d).toInt()
                    val hDp = (h / d).toInt()
                    try {
                        hv.updateAppWidgetSize(null, wDp, hDp, wDp, hDp)
                    } catch (_: Exception) {
                    }
                }
            } catch (_: Exception) {
                dead.add(id)
            }
        }
        dead.forEach {
            store.removeWidget(it)
            try {
                widgetHost.deleteAppWidgetId(it)
            } catch (_: Exception) {
            }
        }

        if (!settings.lockLayout) {
            container.addView(TextView(activity).apply {
                tag = "addWidget"
                text = if (store.widgetIds.isEmpty()) "+  Add your first widget" else "+  Add widget"
                setTextColor(Color.WHITE)
                textSize = 16f
                gravity = Gravity.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                background = GradientDrawable().apply {
                    cornerRadius = dp(22).toFloat()
                    setColor(Color.parseColor("#47404048"))
                }
                setOnClickListener { openPicker() }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
        }
    }

    private fun remove(id: Int) {
        store.removeWidget(id)
        try {
            widgetHost.deleteAppWidgetId(id)
        } catch (_: Exception) {
        }
        rebuild()
    }

    // ---------- নতুন widget যোগ ----------

    fun openPicker() {
        val providers = try {
            manager.installedProviders
        } catch (_: Exception) {
            emptyList<AppWidgetProviderInfo>()
        }
        Sheets.showWidgetPicker(activity, host.isDarkUi(), providers, worker) { info -> beginAdd(info) }
    }

    private fun beginAdd(info: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        pendingId = id
        pendingInfo = info
        try {
            if (manager.bindAppWidgetIdIfAllowed(id, info.provider)) {
                onBound(id, info)
            } else {
                activity.startActivityForResult(
                    Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider),
                    REQ_BIND
                )
            }
        } catch (_: Exception) {
            cancel(id)
            host.toast("Couldn't add this widget")
        }
    }

    private fun onBound(id: Int, info: AppWidgetProviderInfo) {
        if (info.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(activity, id, 0, REQ_CONFIGURE, null)
            } catch (_: Exception) {
                finishAdd(id)
            }
        } else {
            finishAdd(id)
        }
    }

    private fun finishAdd(id: Int) {
        pendingId = -1
        pendingInfo = null
        store.addWidget(id)
        rebuild()
        host.showPage(0)
    }

    private fun cancel(id: Int) {
        pendingId = -1
        pendingInfo = null
        try {
            widgetHost.deleteAppWidgetId(id)
        } catch (_: Exception) {
        }
    }

    /** MainActivity.onActivityResult থেকে ডাকা হয় (widget বাঁধা / configure ডায়ালগের ফল) */
    fun onActivityResult(requestCode: Int, resultCode: Int) {
        val id = pendingId
        val info = pendingInfo
        if (id == -1) return
        val ok = resultCode == Activity.RESULT_OK
        when (requestCode) {
            REQ_BIND -> if (ok && info != null) onBound(id, info) else cancel(id)
            REQ_CONFIGURE -> if (ok) finishAdd(id) else cancel(id)
        }
    }
}
