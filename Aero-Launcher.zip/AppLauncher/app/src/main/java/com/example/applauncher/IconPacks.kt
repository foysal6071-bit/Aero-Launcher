package com.example.applauncher

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.drawable.Drawable
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

/** ADW / Nova / Apex / GO ধরনের বাইরের icon pack (appfilter.xml) সাপোর্ট। */
object IconPacks {

    data class Pack(val pkg: String, val label: String)

    class Loaded(
        val pkg: String,
        val res: Resources,
        val byComponent: Map<String, String>,
        val byPackage: Map<String, String>
    ) {
        fun iconFor(component: ComponentName): Drawable? {
            val name = byComponent[component.packageName + "/" + component.className]
                ?: byPackage[component.packageName]
                ?: return null
            for (type in arrayOf("drawable", "mipmap")) {
                val id = res.getIdentifier(name, type, pkg)
                if (id != 0) {
                    try {
                        return res.getDrawable(id, null)
                    } catch (_: Exception) {
                    }
                }
            }
            return null
        }
    }

    val ACTIONS = listOf(
        "org.adw.launcher.THEMES",
        "com.novalauncher.THEME",
        "com.anddoes.launcher.THEME",
        "com.gau.go.launcherex.theme"
    )

    fun list(pm: PackageManager): List<Pack> {
        val seen = linkedMapOf<String, Pack>()
        for (action in ACTIONS) {
            val infos = try {
                pm.queryIntentActivities(Intent(action), 0)
            } catch (_: Exception) {
                emptyList()
            }
            for (ri in infos) {
                val p = ri.activityInfo.packageName
                if (!seen.containsKey(p)) seen[p] = Pack(p, ri.loadLabel(pm).toString())
            }
        }
        return seen.values.sortedBy { it.label.lowercase() }
    }

    private var cached: Loaded? = null

    @Synchronized
    fun load(pm: PackageManager, packPkg: String): Loaded? {
        if (packPkg.isEmpty()) return null
        cached?.let { if (it.pkg == packPkg) return it }
        val loaded = try {
            parse(pm, packPkg)
        } catch (_: Throwable) {
            null
        }
        cached = loaded
        return loaded
    }

    @Synchronized
    fun invalidate() {
        cached = null
    }

    private fun parse(pm: PackageManager, packPkg: String): Loaded? {
        val res = pm.getResourcesForApplication(packPkg)
        val parser: XmlPullParser = run {
            val id = res.getIdentifier("appfilter", "xml", packPkg)
            if (id != 0) {
                res.getXml(id)
            } else {
                val p = XmlPullParserFactory.newInstance().newPullParser()
                p.setInput(res.assets.open("appfilter.xml"), null)
                p
            }
        }
        val byComponent = HashMap<String, String>()
        val byPackage = HashMap<String, String>()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "item") {
                val comp = parser.getAttributeValue(null, "component")
                val drawable = parser.getAttributeValue(null, "drawable")
                if (comp != null && drawable != null) {
                    val start = comp.indexOf('{')
                    val end = comp.lastIndexOf('}')
                    if (start >= 0 && end > start) {
                        var key = comp.substring(start + 1, end)
                        val slash = key.indexOf('/')
                        if (slash > 0) {
                            val pkg = key.substring(0, slash)
                            val cls = key.substring(slash + 1)
                            // কিছু pack ছোট নাম লেখে ("pkg/.MainActivity"); পুরো নামে মিলিয়ে নিই
                            if (cls.startsWith(".")) key = pkg + cls
                            byPackage.putIfAbsent(pkg, drawable)
                        }
                        byComponent[key] = drawable
                    }
                }
            }
            event = parser.next()
        }
        return Loaded(packPkg, res, byComponent, byPackage)
    }
}
