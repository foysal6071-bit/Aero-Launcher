package com.example.applauncher

import android.app.Activity
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView

class IosMenuItem(
    val title: CharSequence,
    val iconRes: Int = 0,
    val destructive: Boolean = false,
    val action: () -> Unit
)

/** iPhone-এর context menu-এর মতো গোল-কোণা মেনু: আইকন বা স্পর্শের জায়গা থেকে scale হয়ে খোলে। */
object IosMenu {

    private var currentPopup: PopupWindow? = null

    /** খোলা মেনু থাকলে বন্ধ করে (অ্যাপ drag শুরু হলে ব্যবহার হয়) */
    fun dismissCurrent() {
        try {
            currentPopup?.dismiss()
        } catch (_: Exception) {
        }
        currentPopup = null
    }

    fun showAtView(activity: Activity, anchor: View, items: List<IosMenuItem>, dark: Boolean) {
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        show(activity, Rect(loc[0], loc[1], loc[0] + anchor.width, loc[1] + anchor.height), items, dark)
    }

    fun showAtPoint(activity: Activity, x: Int, y: Int, items: List<IosMenuItem>, dark: Boolean) {
        val r = (8 * activity.resources.displayMetrics.density).toInt()
        show(activity, Rect(x - r, y - r, x + r, y + r), items, dark)
    }

    private fun show(activity: Activity, anchor: Rect, items: List<IosMenuItem>, dark: Boolean) {
        if (items.isEmpty()) return
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val bg = if (dark) Color.parseColor("#F0262628") else Color.parseColor("#F2F6F6F8")
        val fg = if (dark) Color.WHITE else Color.BLACK
        val line = if (dark) Color.parseColor("#33FFFFFF") else Color.parseColor("#26000000")
        val red = Color.parseColor("#FF453A")

        val card = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(bg)
            }
            clipToOutline = true
        }
        val popup = PopupWindow(card, dp(250), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.isOutsideTouchable = true
        currentPopup = popup
        popup.setOnDismissListener { if (currentPopup === popup) currentPopup = null }

        items.forEachIndexed { i, item ->
            if (i > 0) {
                card.addView(View(activity).apply { setBackgroundColor(line) },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
            }
            val row = LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
                isClickable = true
                setOnClickListener {
                    popup.dismiss()
                    item.action()
                }
                setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        android.view.MotionEvent.ACTION_DOWN ->
                            v.setBackgroundColor(if (dark) Color.parseColor("#26FFFFFF") else Color.parseColor("#1A000000"))
                        android.view.MotionEvent.ACTION_UP,
                        android.view.MotionEvent.ACTION_CANCEL -> v.setBackgroundColor(Color.TRANSPARENT)
                    }
                    false
                }
            }
            val color = if (item.destructive) red else fg
            row.addView(TextView(activity).apply {
                text = item.title
                setTextColor(color)
                textSize = 16f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (item.iconRes != 0) {
                row.addView(ImageView(activity).apply {
                    setImageResource(item.iconRes)
                    setColorFilter(color)
                }, LinearLayout.LayoutParams(dp(22), dp(22)))
            }
            card.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        }

        val screenW = activity.resources.displayMetrics.widthPixels
        val screenH = activity.resources.displayMetrics.heightPixels
        card.measure(
            View.MeasureSpec.makeMeasureSpec(dp(250), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = dp(250)
        val h = card.measuredHeight
        var x = anchor.centerX() - w / 2
        x = x.coerceIn(dp(12), (screenW - w - dp(12)).coerceAtLeast(dp(12)))
        val below = anchor.bottom + dp(8)
        val showBelow = below + h < screenH - dp(24)
        val y = if (showBelow) below else (anchor.top - dp(8) - h).coerceAtLeast(dp(24))

        card.pivotX = (anchor.centerX() - x).toFloat().coerceIn(0f, w.toFloat())
        card.pivotY = if (showBelow) 0f else h.toFloat()
        card.scaleX = 0.4f
        card.scaleY = 0.4f
        card.alpha = 0f
        popup.showAtLocation(activity.window.decorView, Gravity.NO_GRAVITY, x, y)
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(230)
            .setInterpolator(PathInterpolator(0.22f, 1f, 0.36f, 1f)).start()
    }
}
