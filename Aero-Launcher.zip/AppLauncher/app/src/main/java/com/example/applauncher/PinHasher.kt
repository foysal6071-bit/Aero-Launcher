package com.example.applauncher

import java.security.MessageDigest
import java.security.SecureRandom

/** Hidden-apps PIN-এর hash ও salt — আগে MainActivity-তে ছিল। */
object PinHasher {
    fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun newSalt(): String {
        val bytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
