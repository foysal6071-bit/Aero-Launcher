package com.example.applauncher

import android.transition.AutoTransition
import android.transition.Transition
import android.transition.TransitionManager
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import androidx.recyclerview.widget.DefaultItemAnimator

/** সব জায়গার জন্য একই নরম ease-out curve */
val SmoothCurve = PathInterpolator(0.22f, 1f, 0.36f, 1f)

/**
 * আইকন যোগ / মোছা / জায়গা বদলের সময় হুট করে না বদলে নরমভাবে ফোটে, মিলিয়ে যায়, সরে যায়।
 * (change animation বন্ধ — নাহলে একই আইকন ঝিলিক দেয়)
 */
class SoftItemAnimator : DefaultItemAnimator() {
    init {
        supportsChangeAnimations = false
        addDuration = 280
        removeDuration = 200
        moveDuration = 300
        changeDuration = 200
    }
}

object Motion {

    /** [view]-এর দেখা/না-দেখা নরমভাবে বদলায়। আগে থেকে ঠিক অবস্থায় থাকলে কিছু করে না। */
    fun fadeVisible(view: View, visible: Boolean, duration: Long, targetAlpha: Float = 1f) {
        view.animate().cancel()
        if (visible) {
            if (view.visibility == View.VISIBLE && view.alpha == targetAlpha) return
            if (view.visibility != View.VISIBLE) {
                view.alpha = 0f
                view.visibility = View.VISIBLE
            }
            view.animate().alpha(targetAlpha).setDuration(duration).setInterpolator(SmoothCurve).start()
        } else {
            if (view.visibility == View.GONE) return
            view.animate().alpha(0f).setDuration(duration).setInterpolator(SmoothCurve)
                .withEndAction { view.visibility = View.GONE; view.alpha = 1f }
                .start()
        }
    }

    /** layout বদলের (যেমন কোনো কার্ড আসা/যাওয়া) আগে ডাকলে নিচের জিনিসগুলো লাফ না দিয়ে সরে যায় */
    fun beginLayoutChange(container: ViewGroup, duration: Long, vararg skipChildrenOf: View) {
        val t: Transition = AutoTransition().apply {
            this.duration = duration
            interpolator = SmoothCurve
            skipChildrenOf.forEach { excludeChildren(it, true) }
        }
        TransitionManager.beginDelayedTransition(container, t)
    }

    /** সেটিং বদলে পুরো grid নতুন করে সাজলে একটু নেমে এসে ফুটে ওঠে, ঝট করে বদলায় না */
    fun settle(view: View, duration: Long) {
        view.animate().cancel()
        view.alpha = 0.25f
        view.scaleX = 0.965f
        view.scaleY = 0.965f
        view.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(duration).setInterpolator(SmoothCurve).start()
    }
}
