package com.example.applauncher

import android.graphics.Rect
import android.view.View

/** স্ক্রিনের (x, y) বিন্দুটা [v]-এর দৃশ্যমান অংশের ভেতরে পড়ে কিনা */
fun isPointInView(v: View, x: Float, y: Float): Boolean {
    val r = Rect()
    if (!v.getGlobalVisibleRect(r)) return false
    return r.contains(x.toInt(), y.toInt())
}
