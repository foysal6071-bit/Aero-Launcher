package com.example.applauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/**
 * আইকন ডিস্কে সংরক্ষণ: launcher বন্ধ হয়ে আবার খুললেও ১০০+ আইকন নতুন করে আঁকতে হয় না,
 * PNG থেকে সরাসরি পড়া হয়। কী (key)-তে অ্যাপের APK-র সময়, আকৃতি, ছায়া, icon pack ও সাইজ থাকে —
 * তাই এগুলোর কোনোটা বদলালে নিজে থেকেই নতুন করে আঁকে।
 */
class IconDiskCache(context: Context) {
    private val dir = File(context.cacheDir, "icons").apply { mkdirs() }

    private fun file(pkg: String, key: String) = File(dir, "${pkg}__${key.hashCode().toUInt()}.png")

    fun get(pkg: String, key: String): Bitmap? {
        val f = file(pkg, key)
        if (!f.exists()) return null
        return try {
            BitmapFactory.decodeFile(f.path)
        } catch (_: Throwable) {
            null
        }
    }

    fun put(pkg: String, key: String, bmp: Bitmap) {
        try {
            val f = file(pkg, key)
            // একই অ্যাপের পুরোনো সংস্করণ মুছি
            dir.listFiles { x -> x.name.startsWith("${pkg}__") && x.name != f.name }?.forEach { it.delete() }
            val tmp = File(dir, f.name + ".tmp")
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            tmp.renameTo(f)
        } catch (_: Throwable) {
        }
    }

    /** আর ইনস্টল নেই এমন অ্যাপের ফাইল মুছে দেয় */
    fun prune(installed: Set<String>) {
        dir.listFiles()?.forEach {
            val pkg = it.name.substringBefore("__")
            if (pkg !in installed) it.delete()
        }
    }
}
