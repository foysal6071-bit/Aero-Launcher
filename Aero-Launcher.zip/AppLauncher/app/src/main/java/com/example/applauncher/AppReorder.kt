package com.example.applauncher

import android.view.HapticFeedbackConstants
import android.view.View
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView

/**
 * আইকনে চেপে ধরে (hold) drag করলে জায়গা বদলায় — Home, Dock ও Drawer, সব জায়গায়।
 * চেপে ধরলে মেনু খোলে; আঙুল নড়ালে মেনু বন্ধ হয়ে drag শুরু হয়।
 */
object AppReorder {

    fun attach(
        rv: RecyclerView,
        adapter: AppAdapter,
        enabled: () -> Boolean,
        haptics: () -> Boolean = { true },
        /** > 0: ধরা আইকনের কেন্দ্র স্ক্রিনের এই Y-এর (px) ওপরে ~০.৪ সেকেন্ড থাকলে [onDragOut] চলে */
        outZoneY: Int = -1,
        /** আইকন Home-এ টেনে নেওয়ার জন্য: (package, আইকনের view) */
        onDragOut: ((String, View) -> Unit)? = null,
        onFinished: (List<AppInfo>) -> Unit
    ) {
        val cb = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            private var changed = false
            private var zoneSince = 0L
            private var firedOut = false

            override fun isLongPressDragEnabled() = enabled()

            override fun getMovementFlags(r: RecyclerView, vh: RecyclerView.ViewHolder): Int =
                if (enabled()) super.getMovementFlags(r, vh) else 0

            override fun onMove(
                r: RecyclerView,
                vh: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = vh.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                if (!changed) {
                    changed = true
                    // আঙুল নড়েছে: এবার মেনু সরে যায়, শুধু drag চলে
                    IosMenu.dismissCurrent()
                }
                adapter.move(from, to)
                if (haptics()) vh.itemView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                return true
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}

            override fun onSelectedChanged(vh: RecyclerView.ViewHolder?, actionState: Int) {
                super.onSelectedChanged(vh, actionState)
                if (actionState == ItemTouchHelper.ACTION_STATE_DRAG && vh != null) {
                    changed = false
                    zoneSince = 0L
                    firedOut = false
                    // drag চলার সময় অন্য আইকনগুলো নরমভাবে সরে জায়গা করে দেয়
                    rv.itemAnimator = DefaultItemAnimator().apply {
                        supportsChangeAnimations = false
                        moveDuration = 200
                    }
                }
            }

            override fun onChildDraw(
                c: android.graphics.Canvas, r: RecyclerView, vh: RecyclerView.ViewHolder,
                dX: Float, dY: Float, actionState: Int, isCurrentlyActive: Boolean
            ) {
                super.onChildDraw(c, r, vh, dX, dY, actionState, isCurrentlyActive)
                if (isCurrentlyActive && actionState == ItemTouchHelper.ACTION_STATE_DRAG) {
                    // চাপ দেওয়ার ছোট হওয়ার animation বন্ধ করে ধরা আইকন একটু বড় দেখায়
                    vh.itemView.animate().cancel()
                    vh.itemView.scaleX = 1.14f
                    vh.itemView.scaleY = 1.14f
                    if (outZoneY > 0 && onDragOut != null && !firedOut) {
                        val loc = IntArray(2)
                        vh.itemView.getLocationOnScreen(loc)
                        val cy = loc[1] + vh.itemView.height / 2
                        val cx = loc[0] + vh.itemView.width / 2
                        val sw = r.resources.displayMetrics.widthPixels
                        val edge = (36 * r.resources.displayMetrics.density).toInt()
                        // ওপরে, বাঁয়ে বা ডানে কিনারায় নিলে Home-এ চলে যায়
                        if (cy < outZoneY || cx < edge || cx > sw - edge) {
                            val now = android.os.SystemClock.uptimeMillis()
                            if (zoneSince == 0L) zoneSince = now
                            if (now - zoneSince > 250) {
                                firedOut = true
                                // এই drag আর drawer-এর ক্রম বদলাবে না
                                changed = false
                                val pos = vh.bindingAdapterPosition
                                val pkg = if (pos != RecyclerView.NO_POSITION) adapter.current.getOrNull(pos)?.packageName else null
                                val v = vh.itemView
                                if (pkg != null) v.post { onDragOut(pkg, v) }
                            }
                        } else {
                            zoneSince = 0L
                        }
                    }
                }
            }

            override fun clearView(r: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(r, vh)
                vh.itemView.scaleX = 1f
                vh.itemView.scaleY = 1f
                rv.itemAnimator = SoftItemAnimator()
                if (changed) {
                    changed = false
                    onFinished(adapter.current)
                }
            }
        }
        ItemTouchHelper(cb).attachToRecyclerView(rv)
    }
}
