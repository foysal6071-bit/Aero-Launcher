package com.example.applauncher

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Build
import java.io.File

/** Wallpaper পড়া, ঝাপসা (blur) করা ও সেট করার কাজ — আগে MainActivity-তে ছিল। */
object WallpaperTools {

    fun cacheFile(ctx: Context) = File(ctx.filesDir, "wall_cache.jpg")

    /** সিস্টেম wallpaper পড়ে; না পারলে launcher থেকে সেট করা শেষ wallpaper-এর কপি ব্যবহার করে। */
    fun loadBitmap(ctx: Context): Bitmap? {
        try {
            val d = WallpaperManager.getInstance(ctx).drawable
            if (d != null) {
                val bd = d as? BitmapDrawable
                var bmp = bd?.bitmap
                if (bmp == null) {
                    val w = d.intrinsicWidth.coerceIn(1, 1440)
                    val h = d.intrinsicHeight.coerceIn(1, 2880)
                    bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    d.setBounds(0, 0, w, h)
                    d.draw(Canvas(bmp))
                }
                if (Build.VERSION.SDK_INT >= 26 && bmp!!.config == Bitmap.Config.HARDWARE) {
                    bmp = bmp.copy(Bitmap.Config.ARGB_8888, false)
                }
                if (bmp != null) return bmp
            }
        } catch (_: Throwable) {
        }
        return try {
            val f = cacheFile(ctx)
            if (f.exists()) BitmapFactory.decodeFile(f.path) else null
        } catch (_: Throwable) {
            null
        }
    }

    /** স্ক্রিনের অনুপাতে crop → ছোট করে → box blur। */
    fun makeBlurred(src: Bitmap, tw: Int, th: Int): Bitmap {
        val scale = maxOf(tw / src.width.toFloat(), th / src.height.toFloat())
        val cw = minOf(src.width, (tw / scale).toInt().coerceAtLeast(1))
        val ch = minOf(src.height, (th / scale).toInt().coerceAtLeast(1))
        val crop = Bitmap.createBitmap(src, (src.width - cw) / 2, (src.height - ch) / 2, cw, ch)
        val sw = (tw / 8).coerceAtLeast(8)
        val sh = (th / 8).coerceAtLeast(8)
        val small = Bitmap.createScaledBitmap(crop, sw, sh, true).copy(Bitmap.Config.ARGB_8888, true)!!
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        repeat(2) { boxBlur(px, sw, sh, 4) }
        small.setPixels(px, 0, sw, 0, 0, sw, sh)
        return small
    }

    private fun boxBlur(p: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(p.size)
        fun pass(src: IntArray, dst: IntArray, len: Int, count: Int, stride: Int, step: Int) {
            for (line in 0 until count) {
                val base = line * stride
                var a = 0; var rr = 0; var g = 0; var b = 0
                for (i in -r..r) {
                    val c = src[base + i.coerceIn(0, len - 1) * step]
                    a += c ushr 24; rr += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255
                }
                val n = 2 * r + 1
                for (i in 0 until len) {
                    dst[base + i * step] = ((a / n) shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (b / n)
                    val add = src[base + (i + r + 1).coerceIn(0, len - 1) * step]
                    val rem = src[base + (i - r).coerceIn(0, len - 1) * step]
                    a += (add ushr 24) - (rem ushr 24)
                    rr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                    g += ((add shr 8) and 255) - ((rem shr 8) and 255)
                    b += (add and 255) - (rem and 255)
                }
            }
        }
        pass(p, tmp, w, h, w, 1)   // আড়াআড়ি
        pass(tmp, p, h, w, 1, w)   // লম্বালম্বি
    }

    /** Background thread-এ চালান। সফল হলে true। */
    fun apply(ctx: Context, bmp: Bitmap): Boolean {
        val ok = try {
            val wm = WallpaperManager.getInstance(ctx)
            if (Build.VERSION.SDK_INT >= 24) {
                wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
            } else {
                wm.setBitmap(bmp)
            }
            true
        } catch (_: Exception) {
            false
        }
        if (ok) {
            try {
                cacheFile(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            } catch (_: Exception) {
            }
        }
        return ok
    }

    /** গ্যালারির ছবি স্ক্রিনের মাপে center-crop করে দেয়। Background thread-এ চালান। */
    fun decodeForScreen(ctx: Context, uri: Uri, tw: Int, th: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= tw && bounds.outHeight / (sample * 2) >= th) sample *= 2
        val src = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw IllegalStateException("decode failed")
        val scale = maxOf(tw / src.width.toFloat(), th / src.height.toFloat())
        val sw = (tw / scale).toInt().coerceAtMost(src.width)
        val sh = (th / scale).toInt().coerceAtMost(src.height)
        val cropped = Bitmap.createBitmap(src, (src.width - sw) / 2, (src.height - sh) / 2, sw, sh)
        return Bitmap.createScaledBitmap(cropped, tw, th, true)
    }
}
