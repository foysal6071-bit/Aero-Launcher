package com.example.applauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2

/**
 * Home screen ও dock-এ আইকন চেপে ধরে আঙুল সরালে জায়গা বদলায় (পোকো/iPhone-এর মতো):
 *  - ধরা আইকনের কপি আঙুলের সাথে ভাসে, আসল জায়গা ফাঁকা থাকে
 *  - আঙুল অন্য আইকনের ওপর গেলে সেটা নরমভাবে সরে জায়গা করে দেয়
 *  - পাশের কিনারায় ধরে রাখলে পরের/আগের পেজে যায়
 *  - dock ↔ home পেজের মধ্যেও আনা-নেওয়া যায়
 *  - ছাড়লে কপিটা নিজের জায়গায় নরমভাবে বসে যায়
 *
 * Touch event আসে MainActivity.dispatchTouchEvent থেকে।
 */
class HomeDrag(
    private val root: FrameLayout,
    private val store: HomeStore,
    private val pager: ViewPager2,
    private val dock: RecyclerView,
    private val state: DragState,
    private val pagerAdapter: HomePagerAdapter,
    private val dockAdapter: AppAdapter,
    /** store-এর বর্তমান অবস্থা দিয়ে সব adapter আবার সাজায় (diff হয় বলে animation চলে) */
    private val submitFromStore: () -> Unit,
    /** drag শেষে পেজ-সংখ্যা/ডট সহ পুরো Home নতুন করে সাজায় */
    private val refreshAll: () -> Unit,
    private val haptics: () -> Boolean,
    private val edgeFlip: () -> Boolean,
    private val duration: (Int) -> Long,
    /** উপরের "Uninstall" জায়গায় ছাড়লে */
    private val onUninstall: (String) -> Unit = {}
) {
    var active = false
        private set

    private val density = root.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())

    private var pkg = ""
    private var proxy: ImageView? = null
    private var grabDx = 0f
    private var grabDy = 0f
    private var startX = 0f
    private var startY = 0f
    private var curX = 0f
    private var curY = 0f
    private var movedFar = false
    private var lastSwapAt = 0L
    private var edgeSide = 0
    private var edgeSince = 0L

    // একটা আইকন আরেকটার ওপর ধরে রাখলে folder হয়
    private var hoverPos = RecyclerView.NO_POSITION
    private var hoverSince = 0L
    private var mergeTarget: String? = null
    private var mergeReady = false
    private var mergeView: View? = null

    private fun dp(v: Int) = (v * density).toInt()

    // ওপরের Remove / Uninstall জায়গা
    private var bar: LinearLayout? = null
    private var rmView: TextView? = null
    private var unView: TextView? = null
    private var zone = 0
    private val topInset get() = dp(28)

    private fun chip(text: String, color: Int): TextView = TextView(root.context).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 15f
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(color)
        }
        alpha = 0.75f
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
            setMargins(dp(6), dp(6), dp(6), dp(6))
        }
    }

    private fun showBar() {
        hideBar(false)
        zone = 0
        if (HomeStore.isFolderId(pkg)) return
        val canUninstall = pkg != root.context.packageName
        val l = LinearLayout(root.context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60) + topInset)
            setPadding(dp(10), topInset, dp(10), 0)
            alpha = 0f
        }
        val rm = chip("Remove", Color.parseColor("#FF8E8E93"))
        l.addView(rm)
        rmView = rm
        if (canUninstall) {
            val un = chip("Uninstall", Color.parseColor("#FFFF3B30"))
            l.addView(un)
            unView = un
        }
        root.addView(l)
        bar = l
        l.animate().alpha(1f).setDuration(duration(180)).start()
    }

    private fun hideBar(animate: Boolean = true) {
        val b = bar ?: return
        bar = null
        rmView = null
        unView = null
        zone = 0
        if (animate) b.animate().alpha(0f).setDuration(duration(160)).withEndAction { root.removeView(b) }.start()
        else {
            b.animate().cancel()
            root.removeView(b)
        }
    }

    private fun zoneAt(): Int {
        if (bar == null) return 0
        val rl = IntArray(2)
        root.getLocationOnScreen(rl)
        if (curY > rl[1] + dp(60) + topInset) return 0
        val half = rl[0] + root.width / 2f
        return if (unView == null) 1 else if (curX < half) 1 else 2
    }

    private fun highlight() {
        rmView?.animate()?.alpha(if (zone == 1) 1f else 0.75f)?.scaleX(if (zone == 1) 1.04f else 1f)?.scaleY(if (zone == 1) 1.04f else 1f)?.setDuration(120)?.start()
        unView?.animate()?.alpha(if (zone == 2) 1f else 0.75f)?.scaleX(if (zone == 2) 1.04f else 1f)?.scaleY(if (zone == 2) 1.04f else 1f)?.setDuration(120)?.start()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!active) return
            evaluate()
            handler.postDelayed(this, 33)
        }
    }

    /** [itemView] = যে আইকনে long-press হয়েছে; [rawX]/[rawY] = আঙুলের স্ক্রিন-অবস্থান */
    fun start(packageName: String, itemView: View, rawX: Float, rawY: Float) {
        if (active) return
        finishNow() // আগের drop animation চলতে থাকলে সেটা শেষ করে দিই

        pkg = packageName
        val w = itemView.width.coerceAtLeast(1)
        val h = itemView.height.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        itemView.draw(Canvas(bmp))

        val itemLoc = IntArray(2)
        val rootLoc = IntArray(2)
        itemView.getLocationOnScreen(itemLoc)
        root.getLocationOnScreen(rootLoc)
        grabDx = rawX - itemLoc[0]
        grabDy = rawY - itemLoc[1]
        startX = rawX
        startY = rawY
        curX = rawX
        curY = rawY

        val p = ImageView(root.context).apply {
            setImageBitmap(bmp)
            layoutParams = FrameLayout.LayoutParams(w, h)
            translationX = (itemLoc[0] - rootLoc[0]).toFloat()
            translationY = (itemLoc[1] - rootLoc[1]).toFloat()
            isClickable = false
            isFocusable = false
        }
        showBar()
        root.addView(p)
        proxy = p
        p.animate().scaleX(1.14f).scaleY(1.14f).alpha(0.94f)
            .setDuration(duration(220)).setInterpolator(OvershootInterpolator(2.2f)).start()

        state.hiddenPkg = pkg
        itemView.visibility = View.INVISIBLE

        movedFar = false
        edgeSide = 0
        clearMerge()
        lastSwapAt = SystemClock.uptimeMillis()
        active = true
        if (haptics()) p.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        handler.postDelayed(tick, 50)
    }

    /**
     * Drawer থেকে আইকন Home-এ আনার drag: [bmp] = আঙুলের সাথে ভাসা কপি।
     * অ্যাপটা আগেই store-এ (Home-এর কোনো পেজে) বসানো থাকতে হবে।
     */
    fun startExternal(packageName: String, bmp: Bitmap, rawX: Float, rawY: Float) {
        if (active) return
        finishNow()
        pkg = packageName
        val w = bmp.width
        val h = bmp.height
        grabDx = w / 2f
        grabDy = h / 2f
        startX = rawX
        startY = rawY
        curX = rawX
        curY = rawY
        val rootLoc = IntArray(2)
        root.getLocationOnScreen(rootLoc)
        val p = ImageView(root.context).apply {
            setImageBitmap(bmp)
            layoutParams = FrameLayout.LayoutParams(w, h)
            translationX = rawX - grabDx - rootLoc[0]
            translationY = rawY - grabDy - rootLoc[1]
            scaleX = 1.14f
            scaleY = 1.14f
            alpha = 0.94f
            isClickable = false
            isFocusable = false
        }
        showBar()
        root.addView(p)
        proxy = p
        state.hiddenPkg = pkg
        pagerAdapter.refreshVisible()
        dockAdapter.notifyItemRangeChanged(0, dockAdapter.itemCount)
        movedFar = true
        edgeSide = 0
        clearMerge()
        lastSwapAt = SystemClock.uptimeMillis()
        active = true
        if (haptics()) p.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        handler.postDelayed(tick, 50)
    }

    fun move(rawX: Float, rawY: Float) {
        if (!active) return
        curX = rawX
        curY = rawY
        val p = proxy ?: return
        val rootLoc = IntArray(2)
        root.getLocationOnScreen(rootLoc)
        p.translationX = rawX - grabDx - rootLoc[0]
        p.translationY = rawY - grabDy - rootLoc[1]
        if (!movedFar) {
            val dx = rawX - startX
            val dy = rawY - startY
            if (dx * dx + dy * dy > dp(10) * dp(10)) {
                movedFar = true
                // আঙুল নড়তে শুরু করেছে: মেনু আর দরকার নেই, শুধু drag চলবে
                IosMenu.dismissCurrent()
            }
        }
    }

    /** আঙুল ছাড়লে বা বাতিল হলে */
    fun drop() {
        if (!active) return
        active = false
        handler.removeCallbacks(tick)

        val z = zone
        hideBar()
        if (z == 1) {
            // ওপরে Remove-এ ছাড়লে Home থেকে সরে যায়
            clearMerge()
            store.removeFromHome(pkg)
            refreshAll()
            val pr = proxy
            if (pr == null) finishNow()
            else pr.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f)
                .setDuration(duration(180)).withEndAction { finishNow() }.start()
            return
        }
        if (z == 2) {
            clearMerge()
            onUninstall(pkg)
        }
        val mt = mergeTarget
        if (mergeReady && mt != null) store.mergeInto(mt, pkg)
        clearMerge()
        store.commit()
        refreshAll()
        // পেজ বাদ পড়লে ক্রম বদলাতে পারে — যে পেজে অ্যাপটা বসেছে সেখানেই থাকি
        val pi = store.pageIndexOf(pkg)
        if (pi >= 0 && pager.currentItem != pi + 1) pager.setCurrentItem(pi + 1, false)

        val p = proxy
        if (p == null) {
            finishNow()
            return
        }
        // layout হয়ে গেলে সঠিক জায়গা পাওয়া যায়, তাই পরের frame-এ
        p.post { settleProxy() }
    }

    /** Activity থেকে বেরোলে ইত্যাদি: যেখানে আছে সেখানেই রেখে শেষ করে */
    fun cancel() {
        if (active) {
            zone = 0
            drop()
        } else finishNow()
    }

    private fun settleProxy() {
        val p = proxy ?: return
        val target = slotView()
        if (target == null) {
            p.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f)
                .setDuration(duration(180)).withEndAction { finishNow() }.start()
            return
        }
        val loc = IntArray(2)
        val rootLoc = IntArray(2)
        // translation বাদ দিয়ে layout-এর চূড়ান্ত জায়গা
        val parent = target.parent as View
        parent.getLocationOnScreen(loc)
        root.getLocationOnScreen(rootLoc)
        val tx = (loc[0] + target.left - rootLoc[0]).toFloat()
        val ty = (loc[1] + target.top - rootLoc[1]).toFloat()
        p.animate().translationX(tx).translationY(ty).scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(duration(260)).setInterpolator(SmoothCurve)
            .withEndAction { finishNow() }.start()
    }

    private fun finishNow() {
        hideBar(false)
        val p = proxy ?: run {
            state.hiddenPkg = null
            return
        }
        p.animate().cancel()
        root.removeView(p)
        proxy = null
        state.hiddenPkg = null
        pagerAdapter.refreshVisible()
        dockAdapter.notifyItemRangeChanged(0, dockAdapter.itemCount)
    }

    /** এখন যে আইকনটা আসল জায়গায় (লুকানো অবস্থায়) আছে তার view */
    private fun slotView(): View? {
        val di = store.dock.indexOf(pkg)
        if (di >= 0) return dock.findViewHolderForAdapterPosition(di)?.itemView
        val rv = currentPageRecycler() ?: return null
        val pi = store.pageIndexOf(pkg)
        if (pi < 0 || pi + 1 != pager.currentItem) return null
        val idx = store.pages[pi].indexOf(pkg)
        return rv.findViewHolderForAdapterPosition(idx)?.itemView
    }

    private fun currentPageRecycler(): RecyclerView? {
        val inner = pager.getChildAt(0) as? RecyclerView ?: return null
        val vh = inner.findViewHolderForAdapterPosition(pager.currentItem)
        return (vh as? HomePagerAdapter.PageVH)?.recycler
    }

    // ---------- প্রতি ৫০ms-এ: কিনারায় পেজ বদল ও জায়গা বদল / folder ----------

    private fun clearMerge() {
        mergeView?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(120)?.start()
        mergeView = null
        mergeTarget = null
        mergeReady = false
        hoverPos = RecyclerView.NO_POSITION
    }

    private fun evaluate() {
        val now = SystemClock.uptimeMillis()
        val screenW = root.resources.displayMetrics.widthPixels
        val edge = dp(44)
        val dockRect = dockHitRect()
        val overDock = dockRect != null && dockRect.contains(curX.toInt(), curY.toInt())

        val z = zoneAt()
        if (z != zone) {
            zone = z
            highlight()
            if (z != 0 && haptics()) proxy?.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        if (z != 0) {
            edgeSide = 0
            clearMerge()
            return
        }

        // ১) কিনারায় ধরে রাখলে পেজ বদলে যায়; শেষ পেজের ডান কিনারায় নতুন ফাঁকা পেজ খোলে
        val side = when {
            overDock || !edgeFlip() -> 0
            curX < edge -> -1
            curX > screenW - edge -> 1
            else -> 0
        }
        if (side == 0) {
            edgeSide = 0
        } else if (edgeSide != side) {
            edgeSide = side
            edgeSince = now
        } else if (now - edgeSince > 600) {
            val target = pager.currentItem + side
            if (side == 1 && target >= pagerAdapter.itemCount && store.canAddPage(pkg)) {
                store.addEmptyPage()
                refreshAll()
            }
            if (target >= 1 && target < pagerAdapter.itemCount) {
                clearMerge()
                pager.setCurrentItem(target, true)
                if (haptics()) proxy?.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            edgeSince = now + 500 // পেজ settle হওয়ার সময় দিই, তারপর আবার গণনা
            lastSwapAt = now + 300
            return
        }

        // ২) আইকন সরানো (খুব ঘন ঘন নয়, নইলে আইকনগুলো কাঁপতে থাকে)
        if (now - lastSwapAt < 110) return

        val moved = if (overDock) {
            clearMerge()
            val idx = slotIndex(dock, dockLocation(), store.dock.size)
            store.moveTo(pkg, true, -1, idx)
        } else {
            val page = pager.currentItem - 1
            if (page < 0) return
            val rv = currentPageRecycler() ?: return
            val loc = IntArray(2)
            rv.getLocationOnScreen(loc)
            val r = Rect(loc[0], loc[1], loc[0] + rv.width, loc[1] + rv.height)
            if (!r.contains(curX.toInt(), curY.toInt())) {
                clearMerge()
                return
            }
            val under = rv.findChildViewUnder(curX - loc[0], curY - loc[1])
            val underPos = if (under != null) rv.getChildAdapterPosition(under) else RecyclerView.NO_POSITION
            if (under != null && underPos != RecyclerView.NO_POSITION) {
                if (underPos != hoverPos) {
                    // অন্য আইকনের ওপর নতুন করে এসেছে
                    clearMerge()
                    hoverPos = underPos
                    hoverSince = now
                    return
                }
                val targetId = store.pages.getOrNull(page)?.getOrNull(underPos)
                val inCenter = isCenter(under, curX - loc[0], curY - loc[1])
                if (targetId != null && targetId != pkg && !HomeStore.isFolderId(pkg) && inCenter) {
                    // আইকনের মাঝখানে ধরে রাখলে folder হবে; ততক্ষণ আইকন সরে না
                    if (mergeTarget != targetId) {
                        mergeTarget = targetId
                        mergeReady = false
                        mergeView = under
                    }
                    if (!mergeReady && now - hoverSince > 600) {
                        mergeReady = true
                        under.animate().scaleX(1.16f).scaleY(1.16f).setDuration(160).start()
                        if (haptics()) proxy?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    }
                    return
                }
                if (mergeTarget != null) {
                    mergeView?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(120)?.start()
                    mergeView = null
                    mergeTarget = null
                    mergeReady = false
                }
                // কিনারার দিকে: একটু থেমে থাকলে জায়গা বদল
                if (now - hoverSince < 220) return
            } else {
                clearMerge()
            }
            val idx = slotIndex(rv, loc, rv.adapter?.itemCount ?: 0)
            store.moveTo(pkg, false, page, idx)
        }
        if (moved) {
            lastSwapAt = now
            submitFromStore()
            if (haptics()) proxy?.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    /** আঙুল আইকন-ঘরের মাঝের ৫০%-এ আছে কি */
    private fun isCenter(v: View, x: Float, y: Float): Boolean {
        val cx = v.left + v.width / 2f
        val cy = v.top + v.height / 2f
        return Math.abs(x - cx) < v.width * 0.25f && Math.abs(y - cy) < v.height * 0.25f
    }

    private fun dockLocation(): IntArray {
        val loc = IntArray(2)
        dock.getLocationOnScreen(loc)
        return loc
    }

    /** dock-এর ধরার জায়গা (ফাঁকা dock-ও যেন সহজে ধরা যায়, তাই ওপরে একটু বাড়ানো) */
    private fun dockHitRect(): Rect? {
        if (dock.visibility != View.VISIBLE) return null
        val loc = dockLocation()
        return Rect(loc[0], loc[1] - dp(36), loc[0] + dock.width, loc[1] + dock.height + dp(24))
    }

    /** আঙুল যে ঘরের ওপর আছে সেই ঘরের অবস্থান নম্বর; ঘর না থাকলে সবচেয়ে কাছেরটা / শেষে */
    private fun slotIndex(rv: RecyclerView, loc: IntArray, count: Int): Int {
        val x = curX - loc[0]
        val y = curY - loc[1]
        val under = rv.findChildViewUnder(x, y)
        if (under != null) {
            val p = rv.getChildAdapterPosition(under)
            if (p != RecyclerView.NO_POSITION) return p
        }
        var best = RecyclerView.NO_POSITION
        var bestD = Float.MAX_VALUE
        var bestView: View? = null
        for (i in 0 until rv.childCount) {
            val c = rv.getChildAt(i)
            val p = rv.getChildAdapterPosition(c)
            if (p == RecyclerView.NO_POSITION) continue
            val dx = c.left + c.width / 2f - x
            val dy = c.top + c.height / 2f - y
            val d = dx * dx + dy * dy
            if (d < bestD) {
                bestD = d
                best = p
                bestView = c
            }
        }
        if (best == RecyclerView.NO_POSITION || bestView == null) return count
        // শেষ আইকনের পেছনের ফাঁকা জায়গায় আঙুল থাকলে শেষে বসাই
        val beyond = y > bestView.bottom || (y >= bestView.top && x > bestView.right)
        return if (beyond && best == count - 1) count else best
    }
}
