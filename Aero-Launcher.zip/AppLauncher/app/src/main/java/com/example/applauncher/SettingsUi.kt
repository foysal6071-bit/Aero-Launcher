package com.example.applauncher

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat

interface SettingsCallbacks {
    fun clearUsage()
    /** কোনো সেটিং বদলালে। [reloadIcons] true হলে আইকন নতুন করে রেন্ডার করতে হবে। */
    fun onChanged(reloadIcons: Boolean)
    fun onThemeChanged()
    fun onClose()
    fun openWallpapers()
    fun openWidgets()
    fun openHidden()
    fun changePin()
    fun setDefault()
    fun resetLayout()
    fun resetAll()
    fun isDefaultLauncher(): Boolean
    fun hasBadgeAccess(): Boolean
    fun requestBadgeAccess()
    fun hasLockAccess(): Boolean
    fun requestLockAccess()
    fun iconPackLabel(): String
    fun chooseIconPack()
    fun canUseBiometric(): Boolean
}

/** iPhone "Settings"-এর মতো grouped list; কোডে বানানো, তাই আলাদা XML লাগে না। */
class SettingsUi(
    private val activity: Activity,
    private val s: LauncherSettings,
    private val dark: Boolean,
    private val cb: SettingsCallbacks
) {
    private val d = activity.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private val bg = if (dark) Color.BLACK else Color.parseColor("#F2F2F7")
    private val cardBg = if (dark) Color.parseColor("#1C1C1E") else Color.WHITE
    private val fg = if (dark) Color.WHITE else Color.BLACK
    private val sub = if (dark) Color.parseColor("#99EBEBF5") else Color.parseColor("#993C3C43")
    private val line = if (dark) Color.parseColor("#38FFFFFF") else Color.parseColor("#2E3C3C43")
    private val blue = if (dark) Color.parseColor("#0A84FF") else Color.parseColor("#007AFF")
    private val red = if (dark) Color.parseColor("#FF453A") else Color.parseColor("#FF3B30")
    private val green = Color.parseColor("#34C759")
    private val segBg = if (dark) Color.parseColor("#3A3A3C") else Color.parseColor("#E3E3E8")
    private val segOn = if (dark) Color.parseColor("#636366") else Color.WHITE

    var scrollView: ScrollView? = null

    /** null = প্রধান তালিকা, নইলে খোলা উপ-পেজের নাম */
    var currentPage: String? = null
        private set

    private lateinit var content: LinearLayout
    private lateinit var backBtn: TextView

    /** উপ-পেজ খোলা থাকলে প্রধান তালিকায় ফেরে এবং true দেয়; নইলে false */
    fun handleBack(): Boolean {
        if (currentPage == null) return false
        showPage(null)
        return true
    }

    fun build(startPage: String? = null): View {
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            fitsSystemWindows = true
        }

        // উপরের বার: বাঁয়ে Back (উপ-পেজে), ডানে Done
        val bar = FrameLayout(activity)
        backBtn = TextView(activity).apply {
            text = "‹ Settings"
            setTextColor(blue)
            textSize = 17f
            setPadding(dp(16), dp(10), dp(20), dp(10))
            visibility = View.INVISIBLE
            setOnClickListener { handleBack() }
        }
        bar.addView(backBtn, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.CENTER_VERTICAL))
        bar.addView(TextView(activity).apply {
            this.text = "Done"
            setTextColor(blue)
            textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(dp(20), dp(10), dp(20), dp(10))
            setOnClickListener { cb.onClose() }
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL))
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))

        content = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), dp(40))
        }
        val scroll = ScrollView(activity).apply {
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            addView(content)
        }
        scrollView = scroll
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        showPage(startPage, animate = false)
        return root
    }

    private fun showPage(key: String?, animate: Boolean = true) {
        currentPage = key
        content.removeAllViews()
        backBtn.visibility = if (key == null) View.INVISIBLE else View.VISIBLE
        content.addView(TextView(activity).apply {
            this.text = when (key) {
                "home" -> "Home Screen"
                "library" -> "App Library"
                "icons" -> "Icons"
                "gestures" -> "Gestures"
                "animations" -> "Animations"
                "appearance" -> "Appearance"
                "privacy" -> "Privacy"
                "general" -> "General"
                else -> "Settings"
            }
            setTextColor(fg)
            textSize = 34f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(dp(4), dp(4), 0, dp(8))
        })
        when (key) {
            "home" -> buildHome()
            "library" -> buildLibrary()
            "icons" -> buildIcons()
            "gestures" -> buildGestures()
            "animations" -> buildAnimations()
            "appearance" -> buildAppearance()
            "privacy" -> buildPrivacy()
            "general" -> buildGeneral()
            else -> buildMain()
        }
        scrollView?.scrollTo(0, 0)
        if (animate) {
            content.alpha = 0f
            content.animate().alpha(1f).setDuration(160).start()
        }
    }

    // ---------- প্রধান তালিকা: অল্প কয়েকটা সারি ----------

    private fun buildMain() {
        var g = section(content, "")
        link(g, "Home Screen") { showPage("home") }
        link(g, "App Library") { showPage("library") }
        link(g, "Icons") { showPage("icons") }

        g = section(content, "")
        link(g, "Wallpapers") { cb.openWallpapers() }
        link(g, "Add widget") { cb.openWidgets() }

        g = section(content, "")
        link(g, "Gestures") { showPage("gestures") }
        link(g, "Animations") { showPage("animations") }
        link(g, "Appearance") { showPage("appearance") }

        g = section(content, "")
        link(g, "Privacy") { showPage("privacy") }
        link(g, "General") { showPage("general") }
    }

    // ---------- উপ-পেজ ----------

    private fun buildHome() {
        var g = section(content, "LAYOUT")
        segment(g, "Columns", listOf("4", "5"), { s.homeCols - 4 }) { s.homeCols = 4 + it; cb.onChanged(false) }
        segment(g, "Rows", listOf("4", "5", "6"), { s.homeRows - 4 }) { s.homeRows = 4 + it; cb.onChanged(false) }
        slider(g, "Icon size", 70, 130, { s.iconScale }, { "$it%" }) { s.iconScale = it; cb.onChanged(false) }
        toggle(g, "Show app names", { s.showLabels }) { s.showLabels = it; cb.onChanged(false) }
        segment(g, "Name size", listOf("Small", "Medium", "Large"), { s.labelSize }) { s.labelSize = it; cb.onChanged(false) }
        toggle(g, "Lock layout", { s.lockLayout }) { s.lockLayout = it; cb.onChanged(false) }
        toggle(g, "Home button returns to first page", { s.homeOnPress }) { s.homeOnPress = it; cb.onChanged(false) }

        g = section(content, "SHOW")
        toggle(g, "Clock & date", { s.showClock }) { s.showClock = it; cb.onChanged(false) }
        toggle(g, "Search button", { s.showSearchPill }) { s.showSearchPill = it; cb.onChanged(false) }
        toggle(g, "Dock", { s.showDock }) { s.showDock = it; cb.onChanged(false) }
        toggle(g, "Dock background", { s.dockBackground }) { s.dockBackground = it; cb.onChanged(false) }
        toggle(g, "Status bar", { !s.hideStatusBar }) { s.hideStatusBar = !it; cb.onChanged(false) }
        toggle(g, "Page dots", { s.showDots }) { s.showDots = it; cb.onChanged(false) }
        toggle(g, "Greeting & battery", { s.showChip }) { s.showChip = it; cb.onChanged(false) }
        toggle(g, "Wallpaper parallax", { s.parallax }) { s.parallax = it; cb.onChanged(false) }
        toggle(g, "Notification badges", { s.badges && cb.hasBadgeAccess() }) {
            s.badges = it
            if (it && !cb.hasBadgeAccess()) cb.requestBadgeAccess()
            cb.onChanged(false)
        }
        toggle(g, "Allow landscape", { s.landscape }) { s.landscape = it; cb.onChanged(false) }
    }

    private fun buildLibrary() {
        var g = section(content, "")
        toggle(g, "Background blur", { s.blur }) { s.blur = it; cb.onChanged(false) }
        slider(g, "Dim", 0, 80, { s.dim }, { "$it%" }) { s.dim = it; cb.onChanged(false) }

        g = section(content, "LAYOUT")
        segment(g, "Columns", listOf("4", "5"), { s.drawerCols - 4 }) { s.drawerCols = 4 + it; cb.onChanged(false) }
        segment(g, "Sort apps", listOf("A–Z", "Most used", "Custom"), { s.sortMode }) { s.sortMode = it; cb.onChanged(false) }
        toggle(g, "Show app names", { s.drawerLabels }) { s.drawerLabels = it; cb.onChanged(false) }
        toggle(g, "Suggested apps", { s.showSuggested }) { s.showSuggested = it; cb.onChanged(false) }
        toggle(g, "Open keyboard with search", { s.drawerKeyboard }) { s.drawerKeyboard = it; cb.onChanged(false) }
    }

    private fun buildIcons() {
        val g = section(content, "")
        segment(g, "Shape", listOf("HyperOS", "Circle", "Rounded", "Square"), { s.iconShape }) {
            s.iconShape = it; cb.onChanged(true)
        }
        toggle(g, "Shadow", { s.iconShadow }) { s.iconShadow = it; cb.onChanged(true) }
        link(g, "Icon pack: " + cb.iconPackLabel()) { cb.chooseIconPack() }
    }

    private fun buildGestures() {
        val g = section(content, "")
        toggle(g, "Swipe up for App Library", { s.swipeUp }) { s.swipeUp = it; cb.onChanged(false) }
        segment(g, "Swipe down", listOf("Notifications", "Search", "Off"), { s.swipeDown }) {
            s.swipeDown = it; cb.onChanged(false)
        }
        toggle(g, "Pinch out for hidden apps", { s.pinchHidden }) { s.pinchHidden = it; cb.onChanged(false) }
        toggle(g, "Haptic feedback", { s.haptics }) { s.haptics = it; cb.onChanged(false) }
        toggle(g, "Flip page when dragging to edge", { s.edgeFlip }) { s.edgeFlip = it; cb.onChanged(false) }
        toggle(g, "Double-tap to lock screen", { s.doubleTapLock && cb.hasLockAccess() }) {
            s.doubleTapLock = it
            if (it && !cb.hasLockAccess()) cb.requestLockAccess()
            cb.onChanged(false)
        }
    }

    private fun buildAnimations() {
        val g = section(content, "")
        toggle(g, "HyperOS app open animation", { s.iosAnim }) { s.iosAnim = it; cb.onChanged(false) }
        toggle(g, "Highest refresh rate (120 Hz)", { s.highRefresh }) { s.highRefresh = it; cb.onChanged(false) }
        toggle(g, "Icon press effect", { s.pressAnim }) { s.pressAnim = it; cb.onChanged(false) }
        segment(g, "Page effect", listOf("Soft", "Classic", "Zoom"), { s.pageEffect }) {
            s.pageEffect = it; cb.onChanged(false)
        }
        segment(g, "Speed", listOf("Slow", "Normal", "Fast"), { s.animSpeed }) {
            s.animSpeed = it; cb.onChanged(false)
        }
    }

    private fun buildAppearance() {
        val g = section(content, "")
        segment(g, "Menus & settings", listOf("System", "Light", "Dark"), { s.theme }) {
            s.theme = it; cb.onThemeChanged()
        }
    }

    private fun buildPrivacy() {
        val g = section(content, "")
        link(g, "Hidden apps") { cb.openHidden() }
        link(g, "Change PIN") { cb.changePin() }
        if (cb.canUseBiometric()) {
            toggle(g, "Unlock hidden apps with fingerprint", { s.fingerprint }) { s.fingerprint = it; cb.onChanged(false) }
        }
        link(g, "Clear usage history") { cb.clearUsage() }
    }

    private fun buildGeneral() {
        var g = section(content, "")
        if (!cb.isDefaultLauncher()) {
            link(g, "Set as default launcher") { cb.setDefault() }
            toggle(g, "Remind me to set as default", { s.defaultReminder }) { s.defaultReminder = it; cb.onChanged(false) }
        } else info(g, "Default launcher", "Yes")
        val ver = try {
            activity.packageManager.getPackageInfo(activity.packageName, 0).versionName
        } catch (_: Exception) {
            ""
        }
        info(g, "Version", ver ?: "")

        g = section(content, "")
        link(g, "Reset home screen layout", destructive = true) {
            confirm("Reset home screen layout?", "Apps on home and dock return to the default arrangement.") { cb.resetLayout() }
        }
        link(g, "Reset all settings", destructive = true) {
            confirm("Reset all settings?", "Your hidden-apps PIN is kept.") { cb.resetAll() }
        }
    }

    // ---------- বিল্ডিং ব্লক ----------

    private fun section(parent: LinearLayout, title: String): LinearLayout {
        if (title.isEmpty()) {
            parent.addView(View(activity), LinearLayout.LayoutParams(1, dp(18)))
        } else parent.addView(TextView(activity).apply {
            this.text = title
            setTextColor(sub)
            textSize = 13f
            setPadding(dp(16), dp(22), 0, dp(7))
        })
        val card = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(cardBg)
            }
        }
        parent.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return card
    }

    private fun addRow(group: LinearLayout, row: View) {
        if (group.childCount > 0) {
            group.addView(View(activity).apply { setBackgroundColor(line) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1).apply { marginStart = dp(16) })
        }
        group.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun titleView(t: String, color: Int = fg) = TextView(activity).apply {
        this.text = t
        setTextColor(color)
        textSize = 17f
    }

    private fun toggle(group: LinearLayout, title: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(6), dp(16), dp(6))
            minimumHeight = dp(50)
        }
        row.addView(titleView(title), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = SwitchCompat(activity).apply {
            isChecked = get()
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(green, if (dark) Color.parseColor("#48484A") else Color.parseColor("#D1D1D6"))
            )
            setOnCheckedChangeListener { _, v -> set(v) }
        }
        row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        addRow(group, row)
    }

    private fun segment(group: LinearLayout, title: String, options: List<String>, get: () -> Int, set: (Int) -> Unit) {
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        row.addView(titleView(title))
        val seg = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2), dp(2), dp(2), dp(2))
            background = GradientDrawable().apply { cornerRadius = dp(9).toFloat(); setColor(segBg) }
        }
        val cells = mutableListOf<TextView>()
        fun refresh() {
            val sel = get()
            cells.forEachIndexed { i, tv ->
                tv.background = if (i == sel) GradientDrawable().apply {
                    cornerRadius = dp(7).toFloat(); setColor(segOn)
                } else null
                tv.typeface = Typeface.create("sans-serif-medium", if (i == sel) Typeface.BOLD else Typeface.NORMAL)
            }
        }
        options.forEachIndexed { i, label ->
            val tv = TextView(activity).apply {
                this.text = label
                setTextColor(fg)
                textSize = 13f
                gravity = Gravity.CENTER
                maxLines = 1
                setOnClickListener {
                    set(i)
                    refresh()
                }
            }
            cells.add(tv)
            seg.addView(tv, LinearLayout.LayoutParams(0, dp(32), 1f))
        }
        refresh()
        row.addView(seg, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        })
        addRow(group, row)
    }

    private fun slider(
        group: LinearLayout, title: String, min: Int, max: Int,
        get: () -> Int, fmt: (Int) -> String, set: (Int) -> Unit
    ) {
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        val head = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(titleView(title), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val value = TextView(activity).apply {
            this.text = fmt(get())
            setTextColor(sub)
            textSize = 15f
        }
        head.addView(value)
        row.addView(head)
        val bar = SeekBar(activity).apply {
            this.max = max - min
            progress = get() - min
            progressTintList = ColorStateList.valueOf(blue)
            thumbTintList = ColorStateList.valueOf(blue)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    value.text = fmt(p + min)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    set((sb?.progress ?: 0) + min)
                }
            })
        }
        row.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addRow(group, row)
    }

    private fun link(group: LinearLayout, title: String, destructive: Boolean = false, onClick: () -> Unit) {
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(6), dp(16), dp(6))
            minimumHeight = dp(50)
            setOnClickListener { onClick() }
        }
        row.addView(titleView(title, if (destructive) red else fg), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (!destructive) {
            row.addView(TextView(activity).apply {
                this.text = "›"
                setTextColor(sub)
                textSize = 22f
            })
        }
        addRow(group, row)
    }

    private fun info(group: LinearLayout, title: String, value: String) {
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(6), dp(16), dp(6))
            minimumHeight = dp(50)
        }
        row.addView(titleView(title), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(activity).apply {
            this.text = value
            setTextColor(sub)
            textSize = 16f
        })
        addRow(group, row)
    }

    private fun confirm(title: String, msg: String, onYes: () -> Unit) {
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(msg)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Reset") { _, _ -> onYes() }
            .show()
    }
}
