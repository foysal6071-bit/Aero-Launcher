package com.example.applauncher

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Folder খুললে যে ছোট প্যানেল দেখায়: নাম বদলানো, অ্যাপ খোলা, অ্যাপ বের করা। */
object FolderUi {

    fun show(
        activity: AppCompatActivity,
        store: HomeStore,
        folderId: String,
        appMap: Map<String, AppInfo>,
        focusName: Boolean,
        onLaunch: (AppInfo) -> Unit,
        onChanged: () -> Unit
    ) {
        val folder = store.folders[folderId] ?: return
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val dialog = Dialog(activity)
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)

        val panel = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E61C1C1E"))
                cornerRadius = dp(28).toFloat()
            }
        }

        val title = EditText(activity).apply {
            setText(folder.name)
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine(true)
            setSelectAllOnFocus(true)
        }
        panel.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        var adapterRef: AppAdapter? = null
        val adapter = AppAdapter(
            showLabel = true,
            onClick = { app, _ ->
                dialog.dismiss()
                onLaunch(app)
            },
            onLongClick = { app, _ ->
                AlertDialog.Builder(activity)
                    .setTitle(app.label)
                    .setItems(arrayOf("Remove from folder")) { _, _ ->
                        store.removeFromFolder(folderId, app.packageName)
                        onChanged()
                        if (store.folders[folderId] == null) dialog.dismiss()
                        else bind(store, folderId, appMap, adapterRef)
                    }
                    .show()
            }
        )
        adapterRef = adapter
        adapter.iconSize = dp(56)

        val rv = RecyclerView(activity).apply {
            layoutManager = GridLayoutManager(activity, 4)
            this.adapter = adapter
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
        }
        val rows = (folder.apps.size + 3) / 4
        val h = if (rows > 4) dp(4 * 96) else ViewGroup.LayoutParams.WRAP_CONTENT
        panel.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
        bind(store, folderId, appMap, adapter)

        dialog.setContentView(panel)
        dialog.setOnDismissListener {
            store.renameFolder(folderId, title.text.toString())
            onChanged()
        }
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout((activity.resources.displayMetrics.widthPixels * 0.9f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.CENTER)
            setDimAmount(0.45f)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        title.setOnEditorActionListener { v, _, _ ->
            v.clearFocus()
            true
        }
        dialog.show()
        if (focusName) {
            title.requestFocus()
            dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }
    }

    private fun bind(store: HomeStore, folderId: String, appMap: Map<String, AppInfo>, adapter: AppAdapter?) {
        val f = store.folders[folderId] ?: return
        adapter?.submit(f.apps.mapNotNull { appMap[it] })
    }
}
