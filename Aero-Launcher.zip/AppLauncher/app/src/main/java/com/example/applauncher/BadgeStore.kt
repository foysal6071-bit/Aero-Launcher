package com.example.applauncher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.ConcurrentHashMap

/** অ্যাপ অনুযায়ী অপঠিত notification-এর সংখ্যা। AppAdapter এখান থেকে পড়ে badge আঁকে। */
object BadgeStore {
    @Volatile var enabled = false
    @Volatile var onChange: (() -> Unit)? = null
    private val counts = ConcurrentHashMap<String, Int>()

    fun count(pkg: String): Int = counts[pkg] ?: 0

    fun replace(newCounts: Map<String, Int>) {
        counts.clear()
        counts.putAll(newCounts)
        onChange?.invoke()
    }
}

/** Settings → Notification access থেকে অনুমতি দিলে সিস্টেম এটা চালায়। */
class BadgeListenerService : NotificationListenerService() {

    override fun onListenerConnected() = refresh()

    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()

    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()

    private fun refresh() {
        val list = try {
            activeNotifications
        } catch (_: Exception) {
            null
        } ?: return
        val map = HashMap<String, Int>()
        for (n in list) {
            if (n.isOngoing) continue
            if ((n.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
            map[n.packageName] = (map[n.packageName] ?: 0) + 1
        }
        BadgeStore.replace(map)
    }
}
