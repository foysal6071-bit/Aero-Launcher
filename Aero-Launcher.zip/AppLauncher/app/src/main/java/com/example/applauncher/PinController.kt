package com.example.applauncher

import android.animation.ObjectAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** PIN স্ক্রিন কী উদ্দেশ্যে খোলা হলো */
enum class PinPurpose { OPEN, CHANGE }

/**
 * Hidden apps-এর ৬ ডিজিটের PIN স্ক্রিন: PIN বসানো/বদলানো, ভুল হলে অপেক্ষা (lockout), fingerprint।
 * MainActivity-র সাথে যোগাযোগ [Host]-এর মাধ্যমে।
 */
class PinController(
    private val activity: AppCompatActivity,
    private val settings: LauncherSettings,
    private val host: Host
) {

    interface Host {
        /** PIN খোলা/বন্ধের সময় যে Home layer মিলিয়ে যায়/ফিরে আসে */
        fun homeLayer(): View
        /** drawer বা hidden প্যানেল খোলা আছে কিনা */
        fun isPanelOpen(): Boolean
        fun isStopped(): Boolean
        /** wallpaper ঝাপসা করার কোনো উপায় (blur bitmap বা window blur) আছে কিনা */
        fun blurAvailable(): Boolean
        fun showBlur(on: Boolean)
        fun dur(ms: Int): Long
        /** সঠিক PIN বা fingerprint হলে: Hidden apps প্যানেল খোলো */
        fun onUnlocked()
    }

    private enum class PinMode { ENTER, SET_FIRST, SET_CONFIRM }

    private val pinLength = 6
    private val prefs get() = activity.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)

    private val panel: View = activity.findViewById(R.id.pinPanel)
    private val title: TextView = activity.findViewById(R.id.pinTitle)
    private val subtitle: TextView = activity.findViewById(R.id.pinSubtitle)
    private val content: View = activity.findViewById(R.id.pinContent)
    private val dots: LinearLayout = activity.findViewById(R.id.pinDots)
    private val pad: GridLayout = activity.findViewById(R.id.pinPad)
    private val dotViews = mutableListOf<View>()
    private val entry = StringBuilder()
    private var mode = PinMode.ENTER
    private var purpose = PinPurpose.OPEN
    private var first = ""
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var action: TextView   // নিচের ডানের "Cancel" / "Delete"

    val isVisible: Boolean get() = panel.visibility == View.VISIBLE

    init {
        setupPad()
        // পুরো স্ক্রিন ভরে থাকে; শুধু notch/bar-এর জায়গা ছেড়ে ভেতরের জিনিস বসে
        ViewCompat.setOnApplyWindowInsetsListener(panel) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            content.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
    }

    private var prevLightStatus = false
    private var prevLightNav = false

    /**
     * PIN খোলা থাকলে পুরো স্ক্রিন (status bar ও navigation bar-এর পেছনেও) PIN-এর ব্যাকগ্রাউন্ডে ভরে যায়;
     * bar দুটো স্বচ্ছ থাকে, আইকনগুলো সাদা। বন্ধ হলে আগের অবস্থায় ফেরে।
     */
    private fun setImmersive(on: Boolean) {
        val window = activity.window
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            // Notch/punch-hole-এর জায়গাতেও ব্যাকগ্রাউন্ড আঁকি — নইলে ওপরে ফাঁকা দাগ থাকে
            if (Build.VERSION.SDK_INT >= 28) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode =
                    if (Build.VERSION.SDK_INT >= 30) android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    else android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
            prevLightStatus = c.isAppearanceLightStatusBars
            prevLightNav = c.isAppearanceLightNavigationBars
            c.isAppearanceLightStatusBars = false
            c.isAppearanceLightNavigationBars = false
            c.show(WindowInsetsCompat.Type.navigationBars())
            if (settings.hideStatusBar) c.hide(WindowInsetsCompat.Type.statusBars())
            else c.show(WindowInsetsCompat.Type.statusBars())
        } else {
            c.isAppearanceLightStatusBars = prevLightStatus
            c.isAppearanceLightNavigationBars = prevLightNav
        }
    }

    private fun dp(v: Int): Int = (v * activity.resources.displayMetrics.density).toInt()

    // ---------- দেখানো / লুকানো ----------

    /** PIN সেট না থাকলে নতুন ৬ ডিজিটের PIN বানাতে বলে, নইলে PIN চায়। */
    fun show(purpose: PinPurpose) {
        if (isVisible) return
        if (purpose == PinPurpose.OPEN && host.isPanelOpen()) return
        this.purpose = purpose
        mode = if (prefs.getString("pin6_hash", null) == null) PinMode.SET_FIRST else PinMode.ENTER
        entry.clear()
        first = ""
        dots.translationX = 0f
        updateDots()
        refreshTitle()
        // iPhone-এর মতো: wallpaper ঝাপসা হয়, পেছনের আইকন দেখা যায় না
        val blurOk = settings.blur && host.blurAvailable()
        panel.setBackgroundResource(if (blurOk) R.drawable.pin_bg_blur else R.drawable.pin_bg_solid)
        setImmersive(true)
        if (!host.isPanelOpen()) {
            // PIN ফুটে ওঠার সাথে সাথে Home মিলিয়ে যায় (ঝট করে উধাও হয় না)
            val home = host.homeLayer()
            home.animate().cancel()
            home.animate().alpha(0f).setDuration(host.dur(240)).setInterpolator(SmoothCurve)
                .withEndAction {
                    if (isVisible && !host.isPanelOpen()) home.visibility = View.INVISIBLE
                }.start()
        }
        host.showBlur(true)
        panel.animate().cancel()
        panel.visibility = View.VISIBLE
        panel.alpha = 0f
        panel.scaleX = 1.06f
        panel.scaleY = 1.06f
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(host.dur(260)).setInterpolator(SmoothCurve).start()
        if (purpose == PinPurpose.OPEN && mode == PinMode.ENTER) maybeFingerprint()
    }

    fun hide(animate: Boolean = true) {
        handler.removeCallbacksAndMessages(null)
        setImmersive(false)
        panel.animate().cancel()
        if (!host.isPanelOpen()) {
            val home = host.homeLayer()
            home.animate().cancel()
            home.visibility = View.VISIBLE
            if (animate) {
                home.animate().alpha(1f).setDuration(host.dur(260)).setInterpolator(SmoothCurve).start()
            } else {
                home.alpha = 1f
            }
            host.showBlur(false)
        }
        if (!animate) {
            panel.visibility = View.GONE
            return
        }
        panel.animate().alpha(0f).scaleX(1.06f).scaleY(1.06f)
            .setDuration(host.dur(220)).setInterpolator(SmoothCurve)
            .withEndAction { panel.visibility = View.GONE }
            .start()
    }

    /** Fingerprint চালু থাকলে PIN-এর আগেই আঙুলের ছাপ চায়; "Use PIN" চাপলে PIN-ই চলে। */
    private fun maybeFingerprint() {
        if (!settings.fingerprint || !BiometricHelper.canUse(activity) || lockRemainingMs() > 0L) return
        panel.post {
            if (!isVisible || host.isStopped()) return@post
            BiometricHelper.prompt(
                activity, "Unlock hidden apps", "Use PIN",
                onSuccess = {
                    if (isVisible) {
                        clearFails()
                        hide()
                        host.onUnlocked()
                    }
                }
            )
        }
    }

    // ---------- PIN pad তৈরি ----------

    private fun setupPad() {
        repeat(pinLength) {
            val d = View(activity)
            d.layoutParams = LinearLayout.LayoutParams(dp(14), dp(14)).apply {
                marginStart = dp(10)
                marginEnd = dp(10)
            }
            d.setBackgroundResource(R.drawable.pin_dot_empty)
            dots.addView(d)
            dotViews.add(d)
        }
        // iPhone-এর মতো প্রতিটি সংখ্যার নিচে ছোট অক্ষর
        val letters = mapOf(
            "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL",
            "6" to "MNO", "7" to "PQRS", "8" to "TUV", "9" to "WXYZ"
        )
        // স্ক্রিনের উচ্চতা অনুযায়ী বাটনের মাপ: বড় ফোনে ৮০dp, ছোট স্ক্রিনে কমে
        val hDp = activity.resources.displayMetrics.heightPixels / activity.resources.displayMetrics.density
        val btn = dp(((hDp - 278f) / 4f - 16f).toInt().coerceIn(52, 80))
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "ACTION").forEach { key ->
            val lp = GridLayout.LayoutParams().apply {
                width = btn
                height = btn
                setMargins(dp(13), dp(8), dp(13), dp(8))
            }
            when {
                key.isEmpty() -> pad.addView(Space(activity), lp)
                key == "ACTION" -> {
                    // সংখ্যা না থাকলে "Cancel", থাকলে "Delete" (iPhone-এর মতো)
                    action = TextView(activity).apply {
                        gravity = Gravity.CENTER
                        textSize = 16f
                        setTextColor(Color.WHITE)
                        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                        setShadowLayer(4f, 0f, 1f, Color.parseColor("#40000000"))
                        isClickable = true
                        setOnClickListener {
                            if (entry.isEmpty()) hide() else backspace()
                        }
                    }
                    pad.addView(action, lp)
                    updateDots()
                }
                else -> {
                    val sub = letters[key]
                    val label = SpannableString(if (sub != null) "$key\n$sub" else key).apply {
                        setSpan(AbsoluteSizeSpan(36, true), 0, key.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        if (sub != null) {
                            setSpan(AbsoluteSizeSpan(10, true), key.length + 1, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                            setSpan(StyleSpan(Typeface.BOLD), key.length + 1, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    }
                    val b = TextView(activity).apply {
                        text = label
                        gravity = Gravity.CENTER
                        // চাপলে বাটন সাদা হয়, সংখ্যা কালো — iPhone-এর মতো
                        setTextColor(
                            ColorStateList(
                                arrayOf(intArrayOf(android.R.attr.state_pressed), intArrayOf()),
                                intArrayOf(Color.parseColor("#1C1C1E"), Color.WHITE)
                            )
                        )
                        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                        includeFontPadding = false
                        letterSpacing = 0.02f
                        setLineSpacing(0f, 0.8f)
                        setBackgroundResource(R.drawable.pad_btn)
                        isClickable = true
                        setOnClickListener { digit(key) }
                    }
                    pad.addView(b, lp)
                }
            }
        }
    }

    // ---------- ভুল PIN হলে অপেক্ষা ----------

    private fun lockRemainingMs(): Long =
        (prefs.getLong("pin_lock_until", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    /** iPhone-এর মতো: ৫ বার ভুল হলে ১ মিনিট, তারপর ৫ → ১৫ → ৬০ মিনিট অপেক্ষা। */
    private fun registerWrongPin() {
        val fails = prefs.getInt("pin_fails", 0) + 1
        val e = prefs.edit().putInt("pin_fails", fails)
        if (fails >= 5) {
            val mins = listOf(1L, 5L, 15L, 60L)[(fails - 5).coerceAtMost(3)]
            e.putLong("pin_lock_until", System.currentTimeMillis() + mins * 60_000L)
        }
        e.apply()
    }

    private fun clearFails() {
        prefs.edit().remove("pin_fails").remove("pin_lock_until").apply()
    }

    private fun updateLockUi() {
        handler.removeCallbacksAndMessages(null)
        if (!isVisible) return
        val rem = lockRemainingMs()
        if (rem <= 0L) {
            refreshTitle()
            return
        }
        val t = if (rem >= 60_000L) "${(rem + 59_999L) / 60_000L} min" else "${(rem + 999L) / 1000L} sec"
        title.setTextColor(Color.WHITE)
        title.text = "Try again in $t"
        subtitle.text = "Too many wrong attempts"
        entry.clear()
        updateDots()
        handler.postDelayed({ updateLockUi() }, 1000)
    }

    private fun refreshTitle() {
        if (mode == PinMode.ENTER && lockRemainingMs() > 0L) {
            updateLockUi()
            return
        }
        title.setTextColor(Color.WHITE)
        title.setText(
            when (mode) {
                PinMode.ENTER -> R.string.pin_enter_title
                PinMode.SET_FIRST -> R.string.pin_set_title
                PinMode.SET_CONFIRM -> R.string.pin_confirm_title
            }
        )
        subtitle.text = when (mode) {
            PinMode.ENTER -> "Enter your 6-digit PIN to open hidden apps"
            PinMode.SET_FIRST ->
                if (purpose == PinPurpose.CHANGE) "Choose a new PIN for your hidden apps"
                else "This PIN will protect your hidden apps"
            PinMode.SET_CONFIRM -> "Enter the same PIN once more"
        }
    }

    // ---------- সংখ্যা চাপা ----------

    private fun updateDots() {
        dotViews.forEachIndexed { i, v ->
            val filled = i < entry.length
            v.setBackgroundResource(if (filled) R.drawable.pin_dot_filled else R.drawable.pin_dot_empty)
        }
        if (::action.isInitialized) action.text = if (entry.isEmpty()) "Cancel" else "Delete"
    }

    private fun digit(d: String) {
        if (mode == PinMode.ENTER && lockRemainingMs() > 0L) return
        if (entry.length >= pinLength) return
        entry.append(d)
        updateDots()
        dotViews[entry.length - 1].apply {
            scaleX = 1.35f
            scaleY = 1.35f
            animate().scaleX(1f).scaleY(1f).setDuration(host.dur(220)).setInterpolator(SmoothCurve).start()
        }
        if (entry.length == pinLength) dots.postDelayed({ submit() }, 140)
    }

    private fun backspace() {
        if (entry.isNotEmpty()) {
            entry.deleteCharAt(entry.length - 1)
            updateDots()
        }
    }

    private fun submit() {
        if (!isVisible || entry.length != pinLength) return
        val pin = entry.toString()
        when (mode) {
            PinMode.ENTER -> {
                val salt = prefs.getString("pin6_salt", "") ?: ""
                if (PinHasher.hash(pin, salt) == prefs.getString("pin6_hash", null)) {
                    clearFails()
                    if (purpose == PinPurpose.CHANGE) {
                        // পুরনো PIN ঠিক হলে এবার নতুন PIN বানাতে বলে
                        mode = PinMode.SET_FIRST
                        entry.clear()
                        updateDots()
                        refreshTitle()
                    } else {
                        hide()
                        host.onUnlocked()
                    }
                } else {
                    registerWrongPin()
                    error(R.string.pin_wrong)
                }
            }
            PinMode.SET_FIRST -> {
                first = pin
                mode = PinMode.SET_CONFIRM
                entry.clear()
                updateDots()
                refreshTitle()
            }
            PinMode.SET_CONFIRM -> {
                if (pin == first) {
                    val salt = PinHasher.newSalt()
                    prefs.edit()
                        .putString("pin6_salt", salt)
                        .putString("pin6_hash", PinHasher.hash(pin, salt))
                        .apply()
                    hide()
                    if (purpose == PinPurpose.CHANGE) {
                        Toast.makeText(activity, R.string.pin_changed, Toast.LENGTH_SHORT).show()
                    } else {
                        host.onUnlocked()
                    }
                } else {
                    mode = PinMode.SET_FIRST
                    first = ""
                    error(R.string.pin_mismatch)
                }
            }
        }
    }

    /** ভুল PIN: ডটগুলো কাঁপে, ভাইব্রেট করে, বার্তা দেখায়। */
    private fun error(msg: Int) {
        dots.performHapticFeedback(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT
            else HapticFeedbackConstants.LONG_PRESS
        )
        title.setText(msg)
        title.setTextColor(Color.WHITE)
        subtitle.text = ""
        val d = dp(12).toFloat()
        ObjectAnimator.ofFloat(dots, View.TRANSLATION_X, 0f, -d, d, -d * 0.7f, d * 0.7f, -d * 0.3f, d * 0.3f, 0f)
            .setDuration(host.dur(380)).start()
        entry.clear()
        updateDots()
        dots.postDelayed({ if (isVisible) refreshTitle() }, 1000)
    }
}
