package com.example.applauncher

import android.content.res.Configuration
import android.content.pm.ActivityInfo
import androidx.appcompat.app.AlertDialog
import androidx.core.app.NotificationManagerCompat
import android.graphics.RenderEffect
import android.graphics.Shader
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.app.SearchManager
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.content.IntentFilter
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Process
import android.os.SystemClock
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.PathInterpolator
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.util.Calendar
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import android.content.ComponentCallbacks2
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private companion object {
        const val SRC_HOME = 0
        const val SRC_DRAWER = 1
        const val SRC_HIDDEN = 2
    }

    private lateinit var store: HomeStore

    private var allApps: List<AppInfo> = emptyList()
    private var appMap: Map<String, AppInfo> = emptyMap()
    private var drawerList: List<AppInfo> = emptyList()

    private lateinit var homeLayer: View
    private lateinit var homePager: ViewPager2
    private lateinit var indicator: LinearLayout
    private lateinit var dockView: RecyclerView
    private lateinit var clockWidget: View
    private lateinit var drawer: View
    private lateinit var drawerGrid: RecyclerView
    private lateinit var searchBox: EditText
    private lateinit var hiddenPanel: View
    private lateinit var hiddenGrid: RecyclerView
    private lateinit var hiddenEmpty: View
    private lateinit var chipDot: View
    private lateinit var suggestedCard: View
    private lateinit var drawerEmpty: View
    private lateinit var settings: LauncherSettings
    private val sortMode: Int get() = settings.sortMode
    private lateinit var chip: View
    private lateinit var searchPill: View
    private lateinit var settingsPanel: FrameLayout
    private var settingsUi: SettingsUi? = null
    private var lastHomeCols = 4
    private var pagerInitialized = false

    // Widgets (Today View), Wallpaper, PIN, অ্যাপ-খোলার পর্দা, Default launcher — আলাদা ফাইলে
    private lateinit var widgets: WidgetController
    private lateinit var wallpapers: WallpaperController
    private lateinit var pin: PinController
    private lateinit var launchAnim: LaunchOverlay
    private lateinit var defaultLauncher: DefaultLauncher

    private lateinit var suggestedRow: RecyclerView
    private lateinit var suggestedAdapter: AppAdapter
    private lateinit var chipText: TextView

    private var blurAnimator: ValueAnimator? = null
    private var currentBlur = 0

    private lateinit var pagerAdapter: HomePagerAdapter
    private lateinit var homeDrag: HomeDrag
    private val dragState = DragState()
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var indicatorCount = -1
    private var indicatorDots = true
    private var layoutSig = ""
    private var lastHomeRows = 5
    private var dockBg: android.graphics.drawable.Drawable? = null
    private lateinit var dockAdapter: AppAdapter
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var hiddenAdapter: AppAdapter
    private lateinit var gestures: GestureDetector
    private lateinit var scaleDetector: ScaleGestureDetector

    /** এখন যে প্যানেল (drawer / hidden apps) খোলা আছে; কোনোটা না থাকলে null। */
    private var openPanelView: View? = null

    // Default launcher বেছে নেওয়ার সিস্টেম ডায়ালগের জন্য
    private val roleRequest =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    private var panelAtTopOnDown = true
    private var gestureBlocked = false
    // কাজ না থাকলে ৩ সেকেন্ড পরে thread নিজেই বন্ধ হয় — ব্যাকগ্রাউন্ডে অযথা thread/stack থাকে না
    private val filterRun = Runnable { applyFilter() }
    private val worker = ThreadPoolExecutor(0, 1, 3L, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>())

    // ব্যাকগ্রাউন্ডে মেমরি ছেড়ে দেওয়ার অবস্থা
    private val memHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var isStopped = false
    private var released = false
    private var dirty = false          // ব্যাকগ্রাউন্ডে অ্যাপ ইনস্টল/মোছা হয়েছে
    private var goHomeAfterLoad = false
    private var lastWallpaperId = -1
    private var lastRateKey = ""

    // আইকন বারবার রেন্ডার না করার জন্য ক্যাশ
    private val iconCache = ConcurrentHashMap<String, Bitmap>()
    private var iconPx = 0

    // wallpaper-এর ঝাপসা কপি (PIN ও প্যানেলের পেছনে)
    private lateinit var blurBg: ImageView
    private var blurBitmap: Bitmap? = null

    // PIN, Widget, Wallpaper ইত্যাদি আলাদা ক্লাসের সাথে MainActivity-র যোগাযোগ
    private val pinHost = object : PinController.Host {
        override fun homeLayer(): View = this@MainActivity.homeLayer
        override fun isPanelOpen() = openPanelView != null
        override fun isStopped() = this@MainActivity.isStopped
        override fun blurAvailable() = blurBitmap != null || windowBlurSupported()
        override fun showBlur(on: Boolean) = this@MainActivity.showBlur(on)
        override fun dur(ms: Int) = this@MainActivity.dur(ms)
        override fun onUnlocked() = openHidden()
    }

    private val widgetUiHost = object : WidgetController.Host {
        override fun isDarkUi() = this@MainActivity.isDarkUi()
        override fun dur(ms: Int) = this@MainActivity.dur(ms)
        override fun haptic(v: View) = this@MainActivity.haptic(v)
        override fun toast(msg: String) = this@MainActivity.toast(msg)
        override fun showPage(index: Int) {
            homePager.setCurrentItem(index, true)
        }
    }

    private val wallpaperUiHost = object : WallpaperController.Host {
        override fun isDarkUi() = this@MainActivity.isDarkUi()
        override fun toast(msg: String) = this@MainActivity.toast(msg)
        override fun onWallpaperChanged() = refreshBlurBitmap()
    }

    private var lastWallpaperX = -1f

    // অ্যাপ খোলা/বন্ধের animation-এর pivot (যে আইকনে চাপা হয়েছিল)
    private var launchPivotX = -1f
    private var launchPivotY = -1f

    // HyperOS-এর মতো নরম ease-out curve
    private val smooth = PathInterpolator(0.22f, 1f, 0.36f, 1f)

    // HyperOS-এর app open/close spring
    private val hyperOpen = HyperSpring.OPEN
    private val hyperClose = HyperSpring.CLOSE
    // অ্যাপ খুললে Home একটু পেছনে সরে (ছোট হয়ে) ফিকে হয়
    private val homeRecedeScale = 0.9f

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            // অ্যাপ আপডেটের সময় আসা "removed" ইভেন্ট উপেক্ষা করি
            if (intent?.action == Intent.ACTION_PACKAGE_REMOVED &&
                intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)
            ) return
            intent?.data?.schemeSpecificPart?.let { iconCache.remove(it) }
            // ব্যাকগ্রাউন্ডে আইকন রেন্ডার করি না (RAM বাঁচাতে); ফিরে এলে একবারে লোড হবে
            if (isStopped) {
                dirty = true
                return
            }
            loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Landscape সেটিং বন্ধ থাকলে শুধু portrait
        requestedOrientation = if (LauncherSettings(this).landscape)
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        // স্ক্রিনের পুরোটা (status bar ও নিচের navigation bar-এর পেছনেও) জুড়ে আঁকি — নইলে দুই পাশে ফাঁকা দেখায়
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        setContentView(R.layout.activity_main)

        settings = LauncherSettings(this)
        store = HomeStore(this)
        store.landscape = isLandscape()
        store.columns = homeCols()
        store.rows = homeRows()
        lastHomeCols = homeCols()
        lastHomeRows = homeRows()
        // কলাম/সারি/orientation বদলালে পেজগুলো নতুন করে ভাগ হয় (নইলে আইকন গ্রিডে ধরবে না)
        store.ensureLayout("${homeCols()}x${homeRows()}x${isLandscape()}")
        BadgeStore.enabled = settings.badges
        BadgeStore.onChange = { runOnUiThread { if (!isDestroyed) refreshBadges() } }
        // রেন্ডার সাইজ = স্ক্রিনে সর্বোচ্চ যতটা বড় দেখানো হয় ততটুকুই (আগে ৮০dp ছিল, অনেক বেশি RAM নিত)
        iconPx = minOf(dp(78), ((resources.displayMetrics.widthPixels - dp(20)) / 4 * 0.80f).toInt())

        homeLayer = findViewById(R.id.homeLayer)
        homePager = findViewById(R.id.homePager)
        indicator = findViewById(R.id.pageIndicator)
        dockView = findViewById(R.id.dock)
        clockWidget = findViewById(R.id.clockWidget)
        // ঘড়ি আগের মতোই status bar-এর ঠিক নিচে থাকে
        val clockTop = (clockWidget.layoutParams as ViewGroup.MarginLayoutParams).topMargin
        ViewCompat.setOnApplyWindowInsetsListener(homeLayer) { _, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            val lp = clockWidget.layoutParams as ViewGroup.MarginLayoutParams
            if (lp.topMargin != clockTop + top) {
                lp.topMargin = clockTop + top
                clockWidget.layoutParams = lp
            }
            insets
        }
        drawer = findViewById(R.id.drawer)
        drawerGrid = findViewById(R.id.drawerGrid)
        searchBox = findViewById(R.id.searchBox)
        hiddenPanel = findViewById(R.id.hiddenPanel)
        hiddenGrid = findViewById(R.id.hiddenGrid)
        hiddenEmpty = findViewById(R.id.hiddenEmpty)
        chipDot = findViewById(R.id.chipDot)
        chipText = findViewById(R.id.chipText)
        chipDot.backgroundTintList = ColorStateList.valueOf(accentColor())
        suggestedCard = findViewById(R.id.suggestedCard)
        drawerEmpty = findViewById(R.id.drawerEmpty)
        chip = findViewById(R.id.chip)
        searchPill = findViewById(R.id.searchPill)
        settingsPanel = findViewById(R.id.settingsPanel)
        blurBg = findViewById(R.id.blurBg)
        if (Build.VERSION.SDK_INT >= 31) {
            blurBg.setRenderEffect(RenderEffect.createBlurEffect(18f, 18f, Shader.TileMode.CLAMP))
        }
        launchAnim = LaunchOverlay(this, settings) { dur(it) }
        searchPill.setOnClickListener { openSearch() }
        suggestedRow = findViewById(R.id.suggestedRow)
        pin = PinController(this, settings, pinHost)

        // Home pages
        widgets = WidgetController(this, store, settings, worker, widgetUiHost)
        wallpapers = WallpaperController(this, worker, wallpaperUiHost)
        pagerAdapter = HomePagerAdapter(
            widgets.page,
            onClick = { app, v -> launchApp(app, v) },
            onLongClick = { app, v -> onHomeLongPress(app, v) },
            drag = dragState
        )
        homePager.adapter = pagerAdapter
        // পাশের পেজ আগে থেকেই তৈরি থাকে, তাই প্রথম swipe-এ আটকায় না
        homePager.offscreenPageLimit = 1
        // পেজ swipe করার সময় পাশের পেজ একটু ছোট হয়ে ফিকে হয়ে যায়
        homePager.setPageTransformer { page, position ->
            val a = abs(position).coerceAtMost(1f)
            when (settings.pageEffect) {
                1 -> { // Classic: সাধারণ slide
                    page.scaleX = 1f
                    page.scaleY = 1f
                    page.alpha = 1f
                }
                2 -> { // Zoom: পাশের পেজ বেশি ছোট হয়ে ফিকে হয়
                    val s = 1f - 0.22f * a
                    page.scaleX = s
                    page.scaleY = s
                    page.alpha = 1f - 0.85f * a
                }
                else -> { // Soft
                    val s = 1f - 0.1f * a
                    page.scaleX = s
                    page.scaleY = s
                    page.alpha = 1f - 0.6f * a
                }
            }
        }
        homePager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                // ঘড়ি শুধু প্রথম আইকন-পেজে (position 1) দেখায়
                clockWidget.alpha = when (position) {
                    0 -> positionOffset
                    1 -> 1f - positionOffset
                    else -> 0f
                }
                updateDots(position, positionOffset)
                // Wallpaper parallax: পেজের সাথে সাথে ব্যাকগ্রাউন্ডও সরে
                val n = pagerAdapter.itemCount
                val wx = (position + positionOffset) / (n - 1).coerceAtLeast(1)
                // প্রতি frame-এ binder call করলে scroll আটকে যায়, তাই ছোট পরিবর্তনে বাদ দিই
                if (n > 1 && settings.parallax &&
                    (abs(wx - lastWallpaperX) >= 0.004f || positionOffset == 0f)) {
                    lastWallpaperX = wx
                    try {
                        WallpaperManager.getInstance(this@MainActivity).setWallpaperOffsets(
                            homePager.windowToken, (position + positionOffset) / (n - 1), 0.5f
                        )
                    } catch (_: Exception) {
                    }
                }
            }

            override fun onPageSelected(position: Int) {
                updateDots(position, 0f)
            }
        })

        // Dock
        dockAdapter = AppAdapter(
            showLabel = false,
            onClick = { app, v -> launchApp(app, v) },
            onLongClick = { app, v -> onHomeLongPress(app, v) },
            drag = dragState
        )
        dockView.layoutManager = GridLayoutManager(this, 4)
        dockView.adapter = dockAdapter
        dockView.itemAnimator = SoftItemAnimator()
        dockBg = dockView.background

        // Home ও dock-এ আইকন ধরে সরিয়ে জায়গা বদল
        homeDrag = HomeDrag(
            root = homeLayer.parent as FrameLayout,
            store = store,
            pager = homePager,
            dock = dockView,
            state = dragState,
            pagerAdapter = pagerAdapter,
            dockAdapter = dockAdapter,
            submitFromStore = { submitHome() },
            refreshAll = { refreshHome() },
            haptics = { settings.haptics },
            edgeFlip = { settings.edgeFlip },
            duration = { dur(it) },
            onUninstall = { pkg ->
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
            }
        )

        // Drawer
        drawerAdapter = AppAdapter(
            showLabel = true,
            onClick = { app, v ->
                launchApp(app, v)
                closePanel()
            },
            onLongClick = { app, v -> showMenu(app, v, SRC_DRAWER) }
        )
        drawerGrid.layoutManager = GridLayoutManager(this, 4)
        drawerGrid.adapter = drawerAdapter
        drawerGrid.itemAnimator = SoftItemAnimator()
        drawerGrid.setHasFixedSize(true)
        drawerGrid.setItemViewCacheSize(24)
        drawerGrid.recycledViewPool.setMaxRecycledViews(0, 40)
        drawerGrid.overScrollMode = View.OVER_SCROLL_NEVER
        // Drawer-এ ধরে drag করলে নিজের ক্রম সংরক্ষিত হয় (সার্চ চলার সময় বন্ধ)
        AppReorder.attach(
            drawerGrid, drawerAdapter,
            { !settings.lockLayout && searchBox.text.isNullOrEmpty() },
            outZoneY = dp(170),
            onDragOut = { pkg, v -> dragFromDrawer(pkg, v) }
        ) { list ->
            settings.drawerOrder = list.map { it.packageName }
            settings.sortMode = 2
            drawerList = list
        }

        // Suggested (বেশি ব্যবহৃত অ্যাপ)
        suggestedAdapter = AppAdapter(
            showLabel = true,
            onClick = { app, v ->
                launchApp(app, v)
                closePanel()
            },
            onLongClick = { app, v -> showMenu(app, v, SRC_DRAWER) }
        )
        suggestedRow.layoutManager = object : GridLayoutManager(this, 4) {
            override fun canScrollVertically() = false
        }
        suggestedRow.adapter = suggestedAdapter
        suggestedRow.itemAnimator = SoftItemAnimator()
        suggestedRow.isNestedScrollingEnabled = false
        // Suggested থেকেও ধরে Home-এ আনা যায়
        AppReorder.attach(
            suggestedRow, suggestedAdapter,
            { !settings.lockLayout },
            outZoneY = dp(170),
            onDragOut = { pkg, v -> dragFromDrawer(pkg, v) }
        ) { }

        drawerGrid.layoutAnimation = AnimationUtils.loadLayoutAnimation(this, R.anim.layout_rise)

        // Hidden apps
        hiddenAdapter = AppAdapter(
            showLabel = true,
            onClick = { app, v ->
                launchApp(app, v)
                closePanel()
            },
            onLongClick = { app, v -> showMenu(app, v, SRC_HIDDEN) }
        )
        hiddenGrid.layoutManager = GridLayoutManager(this, 4)
        hiddenGrid.adapter = hiddenAdapter
        hiddenGrid.itemAnimator = SoftItemAnimator()

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                findViewById<View>(R.id.searchClear).visibility =
                    if (s.isNullOrEmpty()) View.GONE else View.VISIBLE
                // দ্রুত টাইপে বারবার ফিল্টার না চালিয়ে একটু থেমে চালাই (কম CPU)
                searchBox.removeCallbacks(filterRun)
                if (s.isNullOrEmpty()) applyFilter() else searchBox.postDelayed(filterRun, 90)
            }
        })

        findViewById<View>(R.id.searchClear).setOnClickListener { searchBox.setText("") }

        // Enter চাপলে: একটাই ফলাফল থাকলে সেটা খোলে, কিছু না পেলে ওয়েবে সার্চ করে
        searchBox.setOnEditorActionListener { _, _, _ ->
            val q = searchBox.text.toString().trim()
            when {
                drawerList.size == 1 -> {
                    launchApp(drawerList[0])
                    closePanel()
                }
                drawerList.isEmpty() && q.isNotEmpty() -> {
                    webSearch(q)
                    closePanel()
                }
            }
            true
        }

        // Swipe up = drawer, swipe down = notifications
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || gestureBlocked) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dy) < dp(80) || abs(dy) < abs(dx) * 1.5f) return false
                if (openPanelView != null) {
                    if (dy > 0 && panelAtTopOnDown) closePanel()
                } else {
                    if (dy < 0) {
                        if (settings.swipeUp) openDrawer()
                    } else when (settings.swipeDown) {
                        0 -> expandNotifications()
                        1 -> openSearch()
                    }
                }
                return false
            }

            // Home-এর ফাঁকা জায়গায় double-tap = screen lock (Accessibility চালু থাকলে)
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (!settings.doubleTapLock || gestureBlocked || openPanelView != null) return false
                if (pin.isVisible || settingsPanel.visibility == View.VISIBLE) return false
                if (!isEmptyHomeSpot(e.rawX, e.rawY)) return false
                if (!LockAccessibilityService.lock()) {
                    toast(if (Build.VERSION.SDK_INT < 28) "Needs Android 9 or newer"
                          else "Turn on Aero Launcher in Accessibility settings")
                }
                return true
            }

            // Home-এর ফাঁকা জায়গায় চেপে ধরলে: Settings / Wallpapers / Widgets
            override fun onLongPress(e: MotionEvent) {
                if (gestureBlocked || openPanelView != null) return
                if (pin.isVisible || settingsPanel.visibility == View.VISIBLE) return
                if (isEmptyHomeSpot(e.rawX, e.rawY)) showHomeMenu(e.rawX, e.rawY)
            }
        })

        // Home-এ zoom (দুই আঙুল ছড়ালে) = hidden apps; পেছনে চিমটি দিলে বন্ধ
        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            private var startSpan = 0f
            private var handled = false

            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                startSpan = detector.currentSpan
                handled = false
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (handled || startSpan <= 0f) return true
                val ratio = detector.currentSpan / startSpan
                val panel = openPanelView
                if (panel == null && ratio > 1.25f && settings.pinchHidden) {
                    handled = true
                    requestHiddenAccess()
                } else if (panel === hiddenPanel && ratio < 0.8f) {
                    handled = true
                    closePanel()
                }
                return true
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    settingsPanel.visibility == View.VISIBLE ->
                        if (settingsUi?.handleBack() != true) closeSettings()
                    pin.isVisible -> pin.hide()
                    openPanelView != null -> closePanel()
                    homePager.currentItem != 1 -> homePager.currentItem = 1
                }
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)

        defaultLauncher = DefaultLauncher(
            this, settings,
            roleLauncher = { roleRequest.launch(it) },
            isStopped = { isStopped },
            // অন্য কিছু খোলা থাকলে বিরক্ত করি না
            canInterrupt = {
                settingsPanel.visibility != View.VISIBLE && !pin.isVisible &&
                    openPanelView == null && !launchAnim.active
            }
        )

        applySettings()
        loadApps()
        defaultLauncher.askOnce()
        applyRefreshRate()
    }

    /**
     * ফোন যদি 90/120 Hz সাপোর্ট করে তবে একই resolution-এর সবচেয়ে উঁচু refresh rate চাই।
     * বন্ধ করলে সিস্টেমের নিজের ডিফল্টে ফেরে।
     */
    private fun applyRefreshRate() {
        try {
            @Suppress("DEPRECATION")
            val d = if (Build.VERSION.SDK_INT >= 30) display else windowManager.defaultDisplay
            val attrs = window.attributes
            if (!settings.highRefresh || d == null) {
                attrs.preferredDisplayModeId = 0
                attrs.preferredRefreshRate = 0f
                if (Build.VERSION.SDK_INT >= 34) attrs.preferredMinDisplayRefreshRate = 0f
            } else {
                val cur = d.mode
                val best = d.supportedModes
                    .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                    .maxByOrNull { it.refreshRate }
                if (best != null) {
                    attrs.preferredDisplayModeId = best.modeId
                    attrs.preferredRefreshRate = best.refreshRate
                    // Android 14+: সিস্টেম যেন idle/স্ক্রলের সময় rate নামিয়ে না দেয়
                    if (Build.VERSION.SDK_INT >= 34) attrs.preferredMinDisplayRefreshRate = best.refreshRate
                }
            }
            val key = "${attrs.preferredDisplayModeId}|${attrs.preferredRefreshRate}"
            if (key != lastRateKey) {
                lastRateKey = key
                window.attributes = attrs
            }
        } catch (_: Throwable) {
        }
    }

    override fun onStart() {
        super.onStart()
        isStopped = false
        memHandler.removeCallbacksAndMessages(null)
        if (released || dirty) {
            released = false
            dirty = false
            loadApps()
        }
        widgets.startListening()
    }

    override fun onPause() {
        super.onPause()
        homeDrag.cancel()
        defaultLauncher.stopReminders()
        launchAnim.onPause()
    }

    // অ্যাপ থেকে বেরিয়ে গেলে hidden প্যানেল বন্ধ হয়, আবার খুলতে PIN লাগবে
    override fun onStop() {
        super.onStop()
        isStopped = true
        // আইকন/wallpaper ক্যাশ ধরে রাখি — তাই ফিরে এলে আবার লোড হয় না।
        // মেমরি সত্যিই কম পড়লে শুধু তখন onTrimMemory-তে ছাড়া হয়।
        widgets.stopListening()
        if (pin.isVisible) pin.hide(animate = false)
        if (openPanelView === hiddenPanel) closePanel()
    }

    // অ্যাপ থেকে Home-এ ফিরলে আইকনগুলো নরমভাবে বড় হয়ে আসে
    override fun onResume() {
        super.onResume()
        updateChip()
        defaultLauncher.startReminders()
        applyRefreshRate()
        refreshBlurBitmap()
        val badgesOn = settings.badges && hasBadgeAccess()
        if (badgesOn != BadgeStore.enabled) {
            BadgeStore.enabled = badgesOn
            refreshBadges()
        }
        // অ্যাপ বন্ধ করলে overlay আবার আইকনে ছোট হয়ে ফিরে যায়
        launchAnim.collapse()
        if (openPanelView == null) {
            // অ্যাপ বন্ধ করলে সেটা যেন যে আইকন থেকে খুলেছিল সেখানেই ছোট হয়ে ফিরে আসে
            homeLayer.animate().cancel()
            homeLayer.visibility = View.VISIBLE
            homeLayer.pivotX = if (launchPivotX >= 0f) launchPivotX else homeLayer.width / 2f
            homeLayer.pivotY = if (launchPivotY >= 0f) launchPivotY else homeLayer.height / 2f
            launchPivotX = -1f
            launchPivotY = -1f
            homeLayer.scaleX = homeRecedeScale
            homeLayer.scaleY = homeRecedeScale
            homeLayer.alpha = 0f
            homeLayer.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(dur(400)).setInterpolator(hyperClose).withLayer().start()
            animateBlur(0)
        }
    }


    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // শুধু সিস্টেম সত্যিই মেমরি চাইলে ছাড়ি (UI_HIDDEN-এ নয়; তাতে প্রতিবার ধীর হতো)
        if (isStopped && level >= ComponentCallbacks2.TRIM_MEMORY_MODERATE) releaseMemory()
    }

    /**
     * Launcher ব্যাকগ্রাউন্ডে গেলে সব ভারী জিনিস ফেলে দেয়: আইকনের ছবি, ঝাপসা wallpaper, widget view।
     * Home-এর পেজ ও আইকনের সাজানো (শুধু অ্যাপের নাম) SharedPreferences-এ থাকে, তাই ফিরে এলে আগের জায়গায়ই লোড হয়।
     */
    private fun releaseMemory() {
        if (released) return
        released = true
        launchAnim.reset()
        blurAnimator?.cancel()
        blurBg.animate().cancel()
        blurBg.visibility = View.GONE
        blurBg.setImageDrawable(null)
        blurBitmap = null

        // পেজ-সংখ্যা একই রাখি (যাতে ফিরে এলে একই পেজে থাকে), কিন্তু আইকন বাদ
        pagerAdapter.submit(store.pages.map { emptyList<AppInfo>() })
        pagerAdapter.release()
        dockAdapter.submit(emptyList())
        drawerAdapter.submit(emptyList())
        suggestedAdapter.submit(emptyList())
        hiddenAdapter.submit(emptyList())
        drawerGrid.recycledViewPool.clear()
        hiddenGrid.recycledViewPool.clear()
        suggestedRow.recycledViewPool.clear()
        dockView.recycledViewPool.clear()

        widgets.release()
        if (settingsPanel.visibility != View.VISIBLE) settingsPanel.removeAllViews()

        allApps = emptyList()
        appMap = emptyMap()
        drawerList = emptyList()
        // Home/dock-এর আইকন (ছোট, মোট ২-৩ MB) রেখে দিই — ফিরে এলে সঙ্গে সঙ্গে দেখা যায়
        val keep: Set<String> = try {
            store.allHomeApps()
        } catch (_: Exception) {
            emptySet()
        }
        iconCache.keys.retainAll(keep)
        lastWallpaperId = -1
    }

    override fun onDestroy() {
        super.onDestroy()
        BadgeStore.onChange = null
        memHandler.removeCallbacksAndMessages(null)
        defaultLauncher.destroy()
        unregisterReceiver(packageReceiver)
        worker.shutdown()
        iconPool.shutdown()
    }

    // Home বাটন চাপলে: প্যানেল বন্ধ, নইলে প্রথম পেজে ফিরে যাও
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            if (settingsPanel.visibility == View.VISIBLE) closeSettings()
            else if (openPanelView != null) closePanel()
            else {
                if (released) goHomeAfterLoad = true
                if (settings.homeOnPress || released) homePager.setCurrentItem(1, true)
            }
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        lastTouchX = ev.x
        lastTouchY = ev.y
        lastRawX = ev.rawX
        lastRawY = ev.rawY
        // আইকন drag চলছে: সব touch এখানেই সামলাই, নিচের view বা pager কিছু পায় না
        if (homeDrag.active) {
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> homeDrag.move(ev.rawX, ev.rawY)
                MotionEvent.ACTION_UP -> {
                    homeDrag.move(ev.rawX, ev.rawY)
                    homeDrag.drop()
                }
                MotionEvent.ACTION_CANCEL -> homeDrag.cancel()
            }
            return true
        }
        // Settings বা PIN খোলা থাকলে home-এর gesture কাজ করবে না
        if (settingsPanel.visibility == View.VISIBLE || pin.isVisible) {
            return super.dispatchTouchEvent(ev)
        }
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gestureBlocked = false
                val grid = when {
                    openPanelView === drawer -> drawerGrid
                    openPanelView === hiddenPanel -> hiddenGrid
                    else -> null
                }
                panelAtTopOnDown = grid == null || !grid.canScrollVertically(-1)
            }
            // দুই আঙুল নামলে এটা zoom — swipe হিসেবে ধরা হবে না
            MotionEvent.ACTION_POINTER_DOWN -> gestureBlocked = true
        }
        scaleDetector.onTouchEvent(ev)
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------- অ্যাপ লোড ----------

    // আইকন বানানোর কাজ কয়েকটা thread-এ ভাগ হয় — একটা thread-এ হলে ১০০+ অ্যাপে অনেক সময় লাগত
    private val iconPool = ThreadPoolExecutor(3, 3, 3L, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>())
        .apply { allowCoreThreadTimeOut(true) }

    /** [list]-এর সব অ্যাপের নাম ও আইকন সমান্তরালে বানায় (ক্যাশে থাকলে নতুন করে বানায় না) */
    private fun renderApps(pm: PackageManager, list: List<android.content.pm.ResolveInfo>): List<AppInfo> {
        val shape = settings.iconShape
        val shadow = settings.iconShadow
        val pack = IconPacks.load(pm, settings.iconPack)
        val tasks = list.map { ri ->
            java.util.concurrent.Callable<AppInfo?> {
                try {
                    val pkg = ri.activityInfo.packageName
                    AppInfo(
                        label = ri.loadLabel(pm).toString(),
                        packageName = pkg,
                        icon = iconCache.getOrPut(pkg) {
                            val packIcon = pack?.iconFor(android.content.ComponentName(pkg, ri.activityInfo.name))
                            if (packIcon != null) IconRenderer.renderRaw(packIcon, iconPx)
                            else IconRenderer.render(ri.loadIcon(pm), iconPx, shape, shadow)
                        }
                    )
                } catch (_: Throwable) {
                    null
                }
            }
        }
        return try {
            iconPool.invokeAll(tasks).mapNotNull { it.get() }.sortedBy { it.label.lowercase() }
        } catch (_: Exception) {
            emptyList() // Activity বন্ধ হয়ে গেছে
        }
    }

    private fun loadApps() {
        worker.execute {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val infos = pm.queryIntentActivities(intent, 0).distinctBy { it.activityInfo.packageName }

            // ধাপ ১: আগে শুধু Home ও dock-এর অ্যাপ — এগুলো হয়ে গেলেই স্ক্রিন দেখা যায়
            if (allApps.isEmpty() && !store.isFirstRun) {
                val wanted: Set<String> = try {
                    store.allHomeApps()
                } catch (_: Exception) {
                    emptySet()
                }
                val first = infos.filter { it.activityInfo.packageName in wanted }
                if (first.isNotEmpty() && first.size < infos.size) {
                    val partial = renderApps(pm, first)
                    runOnUiThread {
                        if (isDestroyed || isStopped) return@runOnUiThread
                        if (allApps.isEmpty()) onAppsLoaded(partial, partial = true)
                    }
                }
            }

            // ধাপ ২: বাকি সব (drawer-এর জন্য)
            val apps = renderApps(pm, infos)
            // আর ইনস্টল নেই এমন অ্যাপের আইকন ক্যাশ থেকে সরাই
            val installed = apps.map { it.packageName }.toSet()
            iconCache.keys.retainAll(installed)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                // লোড চলার মধ্যে ব্যাকগ্রাউন্ডে চলে গেলে ছবি ধরে রাখি না; ফিরে এলে আবার লোড হবে
                if (isStopped) {
                    dirty = true
                    iconCache.clear()
                    return@runOnUiThread
                }
                onAppsLoaded(apps)
            }
        }
    }

    /** [partial] = শুধু Home/dock-এর অ্যাপ এসেছে; তাই কিছু মোছা বা default বসানো হয় না */
    private fun onAppsLoaded(apps: List<AppInfo>, partial: Boolean = false) {
        allApps = apps
        appMap = apps.associateBy { it.packageName }
        if (partial) {
            applySettings()
            return
        }
        if (store.isFirstRun) {
            val dock = defaultDock()
            store.setDefaults(defaultHome(dock), dock)
        } else if (apps.isNotEmpty()) {
            store.prune(appMap.keys)
        }
        applySettings()
    }

    private fun defaultDock(): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents
            .mapNotNull {
                packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)
                    ?.activityInfo?.packageName
            }
            .filter { appMap.containsKey(it) && !store.isHidden(it) }
            .distinct()
    }

    private fun defaultHome(dock: List<String>): List<String> {
        val known = listOf(
            "com.android.settings", "com.android.vending",
            "com.google.android.youtube", "com.google.android.apps.maps",
            "com.google.android.gm", "com.google.android.apps.photos",
            "com.android.chrome", "com.whatsapp", "com.facebook.katana",
            "com.miui.gallery", "com.google.android.apps.messaging"
        )
        val result = known.filter { appMap.containsKey(it) && it !in dock && !store.isHidden(it) }.toMutableList()
        for (app in allApps) {
            if (result.size >= 8) break
            if (app.packageName != packageName && app.packageName !in result &&
                app.packageName !in dock && !store.isHidden(app.packageName)) {
                result.add(app.packageName)
            }
        }
        return result
    }

    // ---------- Home UI ----------

    /** store-এর অবস্থা adapter-এ পাঠায়; পার্থক্যটুকু animation হয়ে দেখা যায় (drag চলার সময়ও এটাই চলে) */
    private fun submitHome() {
        pagerAdapter.submit(store.pages.map { page -> page.mapNotNull { homeItem(it) } })
        val dockApps = store.dock.mapNotNull { appMap[it] }
        (dockView.layoutManager as GridLayoutManager).spanCount = dockApps.size.coerceAtLeast(1)
        dockAdapter.submit(dockApps)
    }

    // Folder-এর আইকন: ভেতরের অ্যাপ বদলালেই কেবল নতুন করে আঁকি (একই Bitmap থাকলে animation ঝিলিক দেয় না)
    private val folderInfoCache = HashMap<String, Pair<String, AppInfo>>()

    /** Home-এর তালিকার একটি id (package বা folder) থেকে দেখানোর AppInfo */
    private fun homeItem(id: String): AppInfo? {
        if (!HomeStore.isFolderId(id)) return appMap[id]
        val f = store.folders[id] ?: return null
        val apps = f.apps.mapNotNull { appMap[it] }
        val sig = f.name + "|" + f.apps.joinToString(",") + "|" + iconPx + "|" + settings.iconShape + "|" + apps.size
        val cached = folderInfoCache[id]
        if (cached != null && cached.first == sig) return cached.second
        val info = AppInfo(f.name, id, FolderIcon.render(apps.map { it.icon }, iconPx, settings.iconShape))
        folderInfoCache[id] = sig to info
        return info
    }

    private fun refreshBadges() {
        pagerAdapter.refreshVisible()
        dockAdapter.notifyItemRangeChanged(0, dockAdapter.itemCount)
        drawerAdapter.notifyItemRangeChanged(0, drawerAdapter.itemCount)
        suggestedAdapter.notifyItemRangeChanged(0, suggestedAdapter.itemCount)
    }

    private fun openFolder(id: String, focusName: Boolean = false) {
        if (!store.folders.containsKey(id)) return
        FolderUi.show(
            this, store, id, appMap, focusName,
            onLaunch = { app -> launchApp(app) },
            onChanged = { refreshHome() }
        )
    }

    private fun refreshHome() {
        submitHome()
        val total = store.pages.size + 1   // Today View + আইকন-পেজ
        buildIndicator(total)
        if (!pagerInitialized) {
            pagerInitialized = true
            homePager.setCurrentItem(1, false)
        } else if (homePager.currentItem >= total) {
            homePager.setCurrentItem(total - 1, false)
        }
        if (goHomeAfterLoad) {
            goHomeAfterLoad = false
            homePager.setCurrentItem(1, false)
        }
        updateDots(homePager.currentItem, 0f)
        try {
            WallpaperManager.getInstance(this)
                .setWallpaperOffsetSteps(if (total > 1) 1f / (total - 1) else 0f, 1f)
        } catch (_: Exception) {
        }
    }

    private fun buildIndicator(count: Int) {
        // সংখ্যা না বদলালে ডটগুলো নতুন করে বানাই না — নইলে ঝিলিক দেয়
        if (count == indicatorCount && settings.showDots == indicatorDots) return
        indicatorCount = count
        indicatorDots = settings.showDots
        indicator.removeAllViews()
        if (count <= 1 || !settings.showDots) {
            indicator.visibility = View.INVISIBLE
            return
        }
        indicator.visibility = View.VISIBLE
        repeat(count) {
            val dot = View(this)
            dot.layoutParams = LinearLayout.LayoutParams(dp(7), dp(7)).apply {
                marginStart = dp(4)
                marginEnd = dp(4)
            }
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
            }
            dot.alpha = 0f
            indicator.addView(dot)
        }
        // নতুন ডটগুলো ফিকে থেকে ফুটে ওঠে
        indicator.alpha = 0f
        indicator.animate().alpha(1f).setDuration(dur(240)).setInterpolator(smooth).start()
    }

    /** iPhone-এর মতো গোল ডট: সক্রিয় পেজের ডট উজ্জ্বল, বাকিগুলো ফিকে। */
    private fun updateDots(position: Int, offset: Float) {
        for (i in 0 until indicator.childCount) {
            val w = when (i) {
                position -> 1f - offset
                position + 1 -> offset
                else -> 0f
            }
            indicator.getChildAt(i).alpha = 0.4f + 0.6f * w
        }
    }

    // ---------- Dynamic রং ও chip ----------

    /** Android 12+ হলে wallpaper থেকে নেওয়া সিস্টেম accent রং, নইলে নীল। */
    private fun accentColor(): Int =
        if (Build.VERSION.SDK_INT >= 31) getColor(android.R.color.system_accent1_200)
        else Color.parseColor("#8AB4FF")

    private fun updateChip() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greeting = when {
            hour < 5 -> "Good night"
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            hour < 21 -> "Good evening"
            else -> "Good night"
        }
        val battery = try {
            (getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
                .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (_: Exception) {
            -1
        }
        chipText.text = if (battery in 0..100) "$greeting  ·  $battery%" else greeting
    }

    private fun windowBlurSupported(): Boolean = Build.VERSION.SDK_INT >= 31 && try {
        windowManager.isCrossWindowBlurEnabled
    } catch (_: Exception) {
        false
    }

    /**
     * Blur চালু/বন্ধ। wallpaper-এর ঝাপসা কপি থাকলে সেটা ফুটিয়ে তোলে (সব Android ও সব ফোনে চলে);
     * না থাকলে Android 12+ window blur চেষ্টা করে।
     */
    private fun showBlur(on: Boolean) {
        if (on && !settings.blur) return
        if (blurBitmap == null) {
            animateBlur(if (on) dp(30) else 0)
            return
        }
        blurBg.animate().cancel()
        if (on) {
            if (blurBg.visibility != View.VISIBLE) {
                blurBg.alpha = 0f
                blurBg.visibility = View.VISIBLE
            }
            blurBg.animate().alpha(1f).setDuration(dur(320)).setInterpolator(smooth).start()
        } else {
            blurBg.animate().alpha(0f).setDuration(dur(260)).setInterpolator(smooth)
                .withEndAction { if (blurBg.alpha == 0f) blurBg.visibility = View.GONE }
                .start()
        }
    }

    private fun refreshBlurBitmap() {
        if (!settings.blur) return
        val id = try {
            WallpaperManager.getInstance(this).getWallpaperId(WallpaperManager.FLAG_SYSTEM)
        } catch (_: Exception) {
            -1
        }
        if (blurBitmap != null && id == lastWallpaperId && id != -1) return
        lastWallpaperId = id
        worker.execute {
            try {
                val src = WallpaperTools.loadBitmap(this) ?: return@execute
                val dm = resources.displayMetrics
                val out = WallpaperTools.makeBlurred(src, dm.widthPixels, dm.heightPixels)
                runOnUiThread {
                    if (!isDestroyed) {
                        blurBitmap = out
                        blurBg.setImageBitmap(out)
                    }
                }
            } catch (_: Throwable) {
            }
        }
    }

    /** Android 12+: প্যানেল খুললে wallpaper ঝাপসা (blur) হয়ে যায়। */
    private fun animateBlur(to: Int) {
        if (Build.VERSION.SDK_INT < 31) return
        if (to > 0 && !settings.blur) return
        try {
            if (!windowManager.isCrossWindowBlurEnabled) return
            blurAnimator?.cancel()
            blurAnimator = ValueAnimator.ofInt(currentBlur, to).apply {
                duration = dur(320)
                interpolator = smooth
                addUpdateListener {
                    currentBlur = it.animatedValue as Int
                    window.setBackgroundBlurRadius(currentBlur)
                }
                start()
            }
        } catch (_: Exception) {
        }
    }

    // ---------- Drawer / Hidden প্যানেল ----------

    private fun openDrawer() {
        if (openPanelView != null) return
        searchBox.setText("")
        drawerGrid.scrollToPosition(0)
        applyFilter()
        // আইকনগুলো একটার পর একটা নিচ থেকে উঠে আসে
        drawerGrid.scheduleLayoutAnimation()
        showPanel(drawer)
        if (settings.drawerKeyboard) {
            searchBox.postDelayed({
                if (openPanelView === drawer) {
                    searchBox.requestFocus()
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                        .showSoftInput(searchBox, 0)
                }
            }, dur(260))
        }
    }

    private fun applyStatusBar() {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (settings.hideStatusBar) c.hide(WindowInsetsCompat.Type.statusBars())
        else c.show(WindowInsetsCompat.Type.statusBars())
    }

    // ---------- Hidden apps PIN ----------

    /** Hidden apps দেখানোর আগে PIN স্ক্রিন দেখায়; PIN সেট না থাকলে নতুন ৬ ডিজিটের PIN বানাতে বলে। */
    private fun requestHiddenAccess() = pin.show(PinPurpose.OPEN)

    private fun openHidden() {
        if (openPanelView != null) return
        refreshHidden()
        hiddenGrid.scrollToPosition(0)
        showPanel(hiddenPanel)
    }

    /**
     * প্যানেল transparent, তাই খোলার সময় home পুরোপুরি লুকিয়ে ফেলি
     * (নইলে পেছনের আইকন প্যানেলের সাথে মিশে যেত, আর অযথা overdraw হতো)।
     * Animation-এ hardware layer ব্যবহার হয় বলে সেটা মসৃণ চলে।
     */
    private fun showPanel(panel: View) {
        openPanelView = panel
        homeLayer.pivotX = homeLayer.width / 2f
        homeLayer.pivotY = homeLayer.height / 2f
        showBlur(true)
        panel.visibility = View.VISIBLE
        panel.alpha = 0f
        panel.translationY = 0f
        panel.scaleX = 1.1f
        panel.scaleY = 1.1f
        panel.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(dur(340))
            .setInterpolator(smooth)
            .withLayer()
            .start()
        homeLayer.animate()
            .alpha(0f)
            .scaleX(0.88f)
            .scaleY(0.88f)
            .setDuration(dur(280))
            .setInterpolator(smooth)
            .withLayer()
            .withEndAction { if (openPanelView != null) homeLayer.visibility = View.INVISIBLE }
            .start()
    }

    private fun closePanel() {
        val panel = openPanelView ?: return
        openPanelView = null
        showBlur(false)
        hideKeyboard()
        searchBox.clearFocus()
        homeLayer.visibility = View.VISIBLE
        homeLayer.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(dur(320)).setInterpolator(smooth).withLayer().start()
        panel.animate()
            .alpha(0f)
            .scaleX(1.1f)
            .scaleY(1.1f)
            .setDuration(dur(240))
            .setInterpolator(smooth)
            .withLayer()
            .withEndAction { if (openPanelView !== panel) panel.visibility = View.GONE }
            .start()
    }

    private fun applyFilter() {
        val q = searchBox.text.toString().trim().lowercase()
        var visible = allApps.filter { !store.isHidden(it.packageName) }
        if (sortMode == 1) {
            val usage = usagePrefs
            visible = visible.sortedWith(
                compareByDescending<AppInfo> { usage.getInt(it.packageName, 0) }
                    .thenBy { it.label.lowercase() }
            )
        }
        if (sortMode == 2) {
            val order = settings.drawerOrder.withIndex().associate { it.value to it.index }
            visible = visible.sortedWith(
                compareBy<AppInfo> { order[it.packageName] ?: Int.MAX_VALUE }
                    .thenBy { it.label.lowercase() }
            )
        }
        drawerList = if (q.isEmpty()) visible else visible.mapNotNull { a ->
            val l = a.label.lowercase()
            val s = when {
                l.startsWith(q) -> 0
                l.split(' ', '-', '.', '_').any { it.startsWith(q) } -> 1
                l.contains(q) -> 2
                a.packageName.lowercase().contains(q) -> 3
                else -> -1
            }
            if (s < 0) null else s to a
        }.sortedBy { it.first }.map { it.second }
        drawerAdapter.submit(drawerList)

        val suggested = if (q.isEmpty() && settings.showSuggested) topUsed(visible) else emptyList()
        suggestedAdapter.submit(suggested)
        val showCard = suggested.isNotEmpty()
        val showEmpty = drawerList.isEmpty() && q.isNotEmpty()
        val cardChanged = (suggestedCard.visibility == View.VISIBLE) != showCard
        val emptyChanged = (drawerEmpty.visibility == View.VISIBLE) != showEmpty
        if ((cardChanged || emptyChanged) && openPanelView === drawer) {
            // সার্চ লিখতে লিখতে "Suggested" কার্ড যাওয়া-আসায় নিচের তালিকা লাফ দেয় না, নরমভাবে সরে
            Motion.beginLayoutChange(suggestedCard.parent as ViewGroup, dur(240), drawerGrid, suggestedRow)
        }
        suggestedCard.visibility = if (showCard) View.VISIBLE else View.GONE
        drawerEmpty.visibility = if (showEmpty) View.VISIBLE else View.GONE
    }

    // ---------- ব্যবহারের হিসাব ----------

    private val usagePrefs get() = getSharedPreferences("usage_counts", Context.MODE_PRIVATE)

    private fun topUsed(apps: List<AppInfo>): List<AppInfo> {
        val prefs = usagePrefs
        return apps
            .map { it to prefs.getInt(it.packageName, 0) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(4)
            .map { it.first }
    }

    private fun refreshHidden() {
        val list = allApps.filter { store.isHidden(it.packageName) }
        hiddenAdapter.submit(list)
        hiddenEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
    }

    // ---------- অ্যাপ অ্যাকশন ----------

    private fun webSearch(q: String) {
        try {
            startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
        } catch (_: Exception) {
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                )
            } catch (_: Exception) {
            }
        }
    }

    /** অ্যাপের shortcut (যেমন Camera → Selfie)। শুধু default launcher হলে পাওয়া যায়। */
    private fun appShortcuts(pkg: String): List<ShortcutInfo> {
        if (Build.VERSION.SDK_INT < 25) return emptyList()
        return try {
            val la = getSystemService(LauncherApps::class.java)
            if (la == null || !la.hasShortcutHostPermission()) return emptyList()
            val q = LauncherApps.ShortcutQuery()
                .setPackage(pkg)
                .setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
                )
            la.getShortcuts(q, Process.myUserHandle())?.filter { it.isEnabled }?.take(4) ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun startShortcut(sc: ShortcutInfo) {
        try {
            if (Build.VERSION.SDK_INT >= 25) {
                getSystemService(LauncherApps::class.java).startShortcut(sc, null, null)
            }
        } catch (_: Exception) {
        }
    }

    /**
     * HyperOS-এর মতো: আইকন থেকে গোল-কোণা পর্দা spring-এ বড় হয়ে পুরো স্ক্রিন ভরে, তার ওপর অ্যাপ ফুটে ওঠে।
     * অ্যাপ বন্ধ করলে (onResume) পর্দা আবার সেই আইকনে ছোট হয়ে ফিরে যায়।
     */
    private fun launchApp(app: AppInfo, anchor: View? = null) {
        if (HomeStore.isFolderId(app.packageName)) {
            openFolder(app.packageName)
            return
        }
        // Aero Launcher নিজেই: নতুন করে খোলার দরকার নেই, Home-এর প্রথম পেজে নরমভাবে ফিরে আসে
        if (app.packageName == packageName) {
            if (openPanelView != null) closePanel()
            homePager.setCurrentItem(1, true)
            return
        }
        val intent = packageManager.getLaunchIntentForPackage(app.packageName) ?: return
        usagePrefs.edit().putInt(app.packageName, usagePrefs.getInt(app.packageName, 0) + 1).apply()
        val ios = settings.iosAnim && anchor != null // নামটা পুরোনো, এখন HyperOS animation
        val options = when {
            ios -> ActivityOptions.makeCustomAnimation(this, R.anim.launch_in, R.anim.launch_hold).toBundle()
            anchor != null -> ActivityOptions.makeScaleUpAnimation(anchor, 0, 0, anchor.width, anchor.height).toBundle()
            else -> null
        }
        if (ios) launchAnim.begin(app, anchor!!, fromHome = openPanelView == null)
        try {
            startActivity(intent, options)
        } catch (_: Exception) {
            if (ios) launchAnim.collapse()
            return
        }
        // Home খোলার সময় আইকনের দিকে zoom হয়ে ফিকে হয়ে যায়, ফেরার সময় (onResume) সেখান থেকেই ফেরে
        if (anchor != null) {
            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            launchPivotX = loc[0] + anchor.width / 2f
            launchPivotY = loc[1] + anchor.height / 2f
            if (openPanelView == null && homeLayer.visibility == View.VISIBLE) {
                homeLayer.pivotX = launchPivotX
                homeLayer.pivotY = launchPivotY
                homeLayer.animate().alpha(0f).scaleX(homeRecedeScale).scaleY(homeRecedeScale)
                    .setDuration(dur(420)).setInterpolator(hyperOpen).withLayer().start()
                animateBlur(dp(22))
            }
        }
    }

    // ---------- Home-এর ফাঁকা জায়গায় long-press ----------

    /** আইকন, dock-আইকন, search বাটন বা widget-এর ওপর না হলে true */
    private fun isEmptyHomeSpot(x: Float, y: Float): Boolean {
        if (dockView.visibility == View.VISIBLE && isPointInView(dockView, x, y)) {
            val loc = IntArray(2)
            dockView.getLocationOnScreen(loc)
            if (dockView.findChildViewUnder(x - loc[0], y - loc[1]) != null) return false
        }
        if (searchPill.visibility == View.VISIBLE && isPointInView(searchPill, x, y)) return false
        val inner = homePager.getChildAt(0) as? RecyclerView ?: return true
        val vh = inner.findViewHolderForAdapterPosition(homePager.currentItem) ?: return true
        if (vh is HomePagerAdapter.PageVH) {
            val loc = IntArray(2)
            vh.recycler.getLocationOnScreen(loc)
            return vh.recycler.findChildViewUnder(x - loc[0], y - loc[1]) == null
        }
        return !widgets.isOverWidget(x, y)
    }

    private fun showHomeMenu(x: Float, y: Float) {
        haptic(homePager)
        IosMenu.showAtPoint(
            this, x.toInt(), y.toInt(),
            listOf(
                IosMenuItem("Settings", R.drawable.ic_settings) { openSettings() },
                IosMenuItem("Wallpapers", R.drawable.ic_wallpaper) { wallpapers.openSheet() },
                IosMenuItem("Widgets", R.drawable.ic_widgets) { widgets.openPicker() }
            ),
            isDarkUi()
        )
    }

    private fun haptic(v: View, type: Int = HapticFeedbackConstants.LONG_PRESS) {
        if (settings.haptics) v.performHapticFeedback(type)
    }

    /** animation গতি সেটিং অনুযায়ী সময় বদলায় */
    private fun dur(ms: Int): Long = (ms * when (settings.animSpeed) {
        0 -> 1.6f
        2 -> 0.65f
        else -> 1f
    }).toLong()

    private fun isDarkUi(): Boolean = when (settings.theme) {
        1 -> false
        2 -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- iPhone-স্টাইল long-press মেনু (অ্যাপের জন্য) ----------

    /** Home/dock-এ long-press: মেনু খোলে, আর আঙুল নড়ালে একই সাথে আইকনটা ধরে সরানো শুরু হয় */
    private fun onHomeLongPress(app: AppInfo, v: View) {
        if (!settings.lockLayout) {
            // নিচের view-গুলো যেন আর touch না পায়; এরপর থেকে সব touch HomeDrag সামলায়
            homeDrag.start(app.packageName, v, lastRawX, lastRawY)
            cancelChildTouch()
        }
        showMenu(app, v, SRC_HOME)
    }

    /**
     * Drawer-এ আইকন ধরে স্ক্রিনের উপরের দিকে (~০.৪ সেকেন্ড) নিলে drawer বন্ধ হয়ে
     * আইকনটা আঙুলের সাথে Home-এ চলে আসে; এরপর যেখানে ছাড়বেন সেখানে বসবে।
     */
    private fun dragFromDrawer(pkg: String, itemView: View) {
        if (settings.lockLayout || homeDrag.active || openPanelView !== drawer) return
        if (!appMap.containsKey(pkg)) return
        val w = itemView.width.coerceAtLeast(1)
        val h = itemView.height.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        itemView.draw(android.graphics.Canvas(bmp))
        IosMenu.dismissCurrent()
        val rx = lastRawX
        val ry = lastRawY
        cancelChildTouch()   // drawer-এর ক্রম-বদলের drag এখানেই শেষ
        closePanel()
        if (homePager.currentItem < 1) homePager.setCurrentItem(1, false)
        store.ensureOnHomePage(pkg, homePager.currentItem - 1)
        refreshHome()
        homeDrag.startExternal(pkg, bmp, rx, ry)
    }

    private fun cancelChildTouch() {
        val t = SystemClock.uptimeMillis()
        val c = MotionEvent.obtain(t, t, MotionEvent.ACTION_CANCEL, lastTouchX, lastTouchY, 0)
        try {
            super.dispatchTouchEvent(c)
            gestures.onTouchEvent(c)
            scaleDetector.onTouchEvent(c)
        } finally {
            c.recycle()
        }
    }

    private fun showMenu(app: AppInfo, anchor: View, source: Int) {
        haptic(anchor)
        if (HomeStore.isFolderId(app.packageName)) {
            val id = app.packageName
            val items = mutableListOf(
                IosMenuItem("Rename Folder") { openFolder(id, focusName = true) }
            )
            if (!settings.lockLayout) {
                items.add(IosMenuItem("Remove Folder", destructive = true) {
                    store.dissolveFolder(id)
                    refreshHome()
                })
            }
            IosMenu.showAtView(this, anchor.findViewById<View>(R.id.appIcon) ?: anchor, items, isDarkUi())
            return
        }
        val items = mutableListOf<IosMenuItem>()
        val shortcuts = appShortcuts(app.packageName)
        shortcuts.forEach { sc ->
            items.add(IosMenuItem(sc.shortLabel ?: sc.id) {
                startShortcut(sc)
                if (source != SRC_HOME) closePanel()
            })
        }
        val locked = settings.lockLayout
        if (source == SRC_HIDDEN) {
            items.add(IosMenuItem("Unhide App") {
                store.unhide(app.packageName)
                applyFilter()
                refreshHidden()
            })
        } else if (!locked) {
            val onHome = store.isOnHome(app.packageName)
            if (!onHome) {
                items.add(IosMenuItem("Add to Home Screen") {
                    if (store.addToHome(app.packageName)) {
                        refreshHome()
                        Toast.makeText(this, R.string.added_home, Toast.LENGTH_SHORT).show()
                    }
                    if (source == SRC_DRAWER) closePanel()
                })
            } else {
                items.add(IosMenuItem("Remove from Home Screen") {
                    store.removeFromHome(app.packageName)
                    refreshHome()
                })
                if (!store.isInDock(app.packageName) && store.dock.size < HomeStore.DOCK_SIZE) {
                    items.add(IosMenuItem("Move to Dock") {
                        store.moveToDock(app.packageName)
                        refreshHome()
                    })
                }
            }
            // Aero Launcher নিজেকে লুকাতে পারে না — app list-এ সবসময় থাকে
            if (app.packageName != packageName) items.add(IosMenuItem("Hide App") {
                store.hide(app.packageName)
                refreshHome()
                applyFilter()
                refreshHidden()
                Toast.makeText(this, R.string.app_hidden, Toast.LENGTH_SHORT).show()
            })
        }
        items.add(IosMenuItem("App Info") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:${app.packageName}"))
            )
        })
        items.add(IosMenuItem("Delete App", destructive = true) {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
        })
        IosMenu.showAtView(this, anchor.findViewById<View>(R.id.appIcon) ?: anchor, items, isDarkUi())
    }

    private fun expandNotifications() {
        try {
            val service = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager")
                .getMethod("expandNotificationsPanel")
                .invoke(service)
        } catch (_: Exception) {
            // কিছু ডিভাইসে এই পদ্ধতি কাজ নাও করতে পারে
        }
    }

    // ---------- সেটিংস প্রয়োগ ----------

    /** আইকনের দেখানোর সাইজ: সেটিংসের scale, কিন্তু ঘরের (cell) ৮০%-এর বেশি নয় */
    private fun isLandscape() =
        resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    /** landscape-এ ঘড়ি নেই; কম সারি, বেশি কলাম */
    private fun homeCols() = if (isLandscape()) 8 else settings.homeCols
    private fun homeRows() = if (isLandscape()) 2 else settings.homeRows

    private fun iconSizeFor(cols: Int): Int {
        val cell = (resources.displayMetrics.widthPixels - dp(20)) / cols
        return minOf((dp(60) * settings.iconScale / 100f).toInt(), (cell * 0.80f).toInt())
    }

    /** সব সেটিং UI-তে বসায়; সেটিং বদলালে বা অ্যাপ লোড হলে চলে। */
    private fun applySettings() {
        val land = isLandscape()
        requestedOrientation = if (settings.landscape)
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        BadgeStore.enabled = settings.badges && hasBadgeAccess()
        store.landscape = land
        store.columns = homeCols()
        store.rows = homeRows()
        if (lastHomeCols != homeCols() || lastHomeRows != homeRows()) {
            lastHomeCols = homeCols()
            lastHomeRows = homeRows()
            store.ensureLayout("${homeCols()}x${homeRows()}x$land")
        }
        // আইকনের মাপ/কলাম/আকৃতি বদলালে grid ঝট করে না বদলে নরমভাবে নতুন রূপে ফুটে ওঠে
        val sig = listOf(
            homeCols(), iconSizeFor(homeCols()), settings.showLabels,
            settings.drawerCols, iconSizeFor(settings.drawerCols), settings.drawerLabels,
            settings.iconShape, settings.iconShadow, homeRows(), settings.labelSize
        ).joinToString("|")
        val layoutChanged = layoutSig.isNotEmpty() && sig != layoutSig && !isStopped
        layoutSig = sig
        if (layoutChanged) {
            Motion.settle(homePager, dur(340))
            Motion.settle(dockView, dur(340))
            Motion.settle(drawerGrid, dur(340))
        }

        val labelSp = when (settings.labelSize) { 0 -> 10f; 2 -> 13f; else -> 11.5f }
        pagerAdapter.labelSp = labelSp
        pagerAdapter.pressAnim = settings.pressAnim
        dockAdapter.labelSp = labelSp
        dockAdapter.pressAnim = settings.pressAnim
        drawerAdapter.labelSp = labelSp
        drawerAdapter.pressAnim = settings.pressAnim
        suggestedAdapter.labelSp = labelSp
        suggestedAdapter.pressAnim = settings.pressAnim
        hiddenAdapter.labelSp = labelSp
        hiddenAdapter.pressAnim = settings.pressAnim
        pagerAdapter.landscape = land
        pagerAdapter.configure(homeCols(), iconSizeFor(homeCols()), settings.showLabels)
        dockView.background = if (settings.dockBackground) dockBg else null
        applyStatusBar()

        dockAdapter.iconSize = iconSizeFor(4)
        (drawerGrid.layoutManager as GridLayoutManager).spanCount = settings.drawerCols
        drawerAdapter.iconSize = iconSizeFor(settings.drawerCols)
        drawerAdapter.showLabel = settings.drawerLabels
        suggestedAdapter.iconSize = iconSizeFor(4)
        suggestedAdapter.showLabel = settings.drawerLabels
        hiddenAdapter.iconSize = iconSizeFor(4)

        // দেখানো/লুকানো: মিলিয়ে যায় বা ফুটে ওঠে, নিচের জিনিস নরমভাবে সরে
        val animateToggles = homeLayer.isLaidOut && !isStopped
        // ঘড়ির alpha pager-এর swipe নিয়ন্ত্রণ করে, তাই শুধু দেখা/না-দেখা বদলালেই animation চালাই
        val clockWanted = settings.showClock && !land
        if (clockWanted != (clockWidget.visibility == View.VISIBLE)) {
            Motion.fadeVisible(
                clockWidget, clockWanted, if (animateToggles) dur(240) else 0L,
                if (homePager.currentItem == 1) 1f else 0f
            )
        }
        if (settings.showChip != (chip.visibility == View.VISIBLE)) {
            Motion.fadeVisible(chip, settings.showChip, if (animateToggles) dur(240) else 0L)
        }
        val col = homePager.parent as ViewGroup
        val pillVisible = searchPill.visibility == View.VISIBLE
        val dockVisible = dockView.visibility == View.VISIBLE
        val pillWanted = settings.showSearchPill && !land
        if (animateToggles && (pillVisible != pillWanted || dockVisible != settings.showDock)) {
            Motion.beginLayoutChange(col, dur(280), homePager)
        }
        searchPill.visibility = if (pillWanted) View.VISIBLE else View.GONE
        dockView.visibility = if (settings.showDock) View.VISIBLE else View.GONE

        val scrim = Color.argb(settings.dim * 255 / 100, 0, 0, 0)
        drawer.setBackgroundColor(scrim)
        hiddenPanel.setBackgroundColor(scrim)

        applyFilter()
        refreshHome()
        refreshHidden()
        widgets.rebuild()
        applyRefreshRate()
    }

    private fun openSearch() {
        openDrawer()
        searchBox.postDelayed({
            searchBox.requestFocus()
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(searchBox, 0)
        }, dur(240))
    }

    // ---------- Settings স্ক্রিন ----------

    private val settingsCallbacks = object : SettingsCallbacks {
        override fun onChanged(reloadIcons: Boolean) {
            if (reloadIcons) {
                iconCache.clear()
                loadApps()
            } else {
                applySettings()
            }
        }

        override fun clearUsage() {
            usagePrefs.edit().clear().apply()
            applyFilter()
            toast("Usage history cleared")
        }

        override fun onThemeChanged() {
            rebuildSettingsPanel()
            settingsPanel.animate().cancel()
            settingsPanel.alpha = 0f
            settingsPanel.animate().alpha(1f).setDuration(dur(240)).setInterpolator(smooth).start()
        }
        override fun onClose() = closeSettings()
        override fun openWallpapers() = closeSettings { wallpapers.openSheet() }
        override fun openWidgets() = closeSettings { widgets.openPicker() }
        override fun openHidden() = closeSettings { requestHiddenAccess() }
        override fun changePin() = closeSettings { pin.show(PinPurpose.CHANGE) }
        override fun hasBadgeAccess() = this@MainActivity.hasBadgeAccess()
        override fun requestBadgeAccess() {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (_: Exception) {
                toast("Couldn't open Notification access settings")
            }
        }
        override fun hasLockAccess() = LockAccessibilityService.isEnabled
        override fun requestLockAccess() {
            if (Build.VERSION.SDK_INT < 28) {
                toast("Needs Android 9 or newer")
                return
            }
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (_: Exception) {
                toast("Couldn't open Accessibility settings")
            }
        }
        override fun iconPackLabel(): String {
            val p = settings.iconPack
            if (p.isEmpty()) return "System"
            return try {
                packageManager.getApplicationInfo(p, 0).loadLabel(packageManager).toString()
            } catch (_: Exception) {
                "System"
            }
        }
        override fun chooseIconPack() = this@MainActivity.chooseIconPack()
        override fun canUseBiometric() = BiometricHelper.canUse(this@MainActivity)
        override fun setDefault() = defaultLauncher.request()
        override fun isDefaultLauncher() = defaultLauncher.isDefault()

        override fun resetLayout() {
            val dock = defaultDock()
            store.setDefaults(defaultHome(dock), dock)
            applySettings()
            toast("Home screen reset")
        }

        override fun resetAll() {
            settings.resetAll()
            store.columns = homeCols()
            iconCache.clear()
            IconPacks.invalidate()
            rebuildSettingsPanel()
            loadApps()
            toast("Settings reset")
        }
    }

    private fun hasBadgeAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun chooseIconPack() {
        val packs = IconPacks.list(packageManager)
        if (packs.isEmpty()) {
            toast("No icon packs installed")
            return
        }
        val names = (listOf("System default") + packs.map { it.label }).toTypedArray()
        val current = packs.indexOfFirst { it.pkg == settings.iconPack } + 1
        AlertDialog.Builder(this)
            .setTitle("Icon pack")
            .setSingleChoiceItems(names, current) { d, which ->
                settings.iconPack = if (which == 0) "" else packs[which - 1].pkg
                IconPacks.invalidate()
                iconCache.clear()
                loadApps()
                rebuildSettingsPanel()
                d.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun rebuildSettingsPanel() {
        val y = settingsUi?.scrollView?.scrollY ?: 0
        val page = settingsUi?.currentPage
        settingsPanel.removeAllViews()
        val ui = SettingsUi(this, settings, isDarkUi(), settingsCallbacks)
        settingsUi = ui
        settingsPanel.addView(ui.build(page))
        ui.scrollView?.post { ui.scrollView?.scrollTo(0, y) }
    }

    private fun openSettings() {
        if (settingsPanel.visibility == View.VISIBLE) return
        hideKeyboard()
        settingsUi = null
        rebuildSettingsPanel()
        settingsPanel.animate().cancel()
        settingsPanel.visibility = View.VISIBLE
        val w = resources.displayMetrics.widthPixels.toFloat()
        settingsPanel.translationX = w
        settingsPanel.animate().translationX(0f).setDuration(dur(380)).setInterpolator(smooth).start()
    }

    private fun closeSettings(after: (() -> Unit)? = null) {
        if (settingsPanel.visibility != View.VISIBLE) {
            after?.invoke()
            return
        }
        settingsPanel.animate().cancel()
        settingsPanel.animate()
            .translationX(resources.displayMetrics.widthPixels.toFloat())
            .setDuration(dur(320))
            .setInterpolator(smooth)
            .withEndAction {
                settingsPanel.visibility = View.GONE
                settingsPanel.removeAllViews()
                settingsUi = null
                after?.invoke()
            }
            .start()
    }

    // ---------- Widgets (Today View) ----------

    // widget বাঁধা / configure ডায়ালগের ফল
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        widgets.onActivityResult(requestCode, resultCode)
    }

    // ---------- Wallpapers ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
