package com.example.applauncher

import android.content.Context
import android.content.SharedPreferences

/** সব launcher সেটিংস এক জায়গায়। MainActivity আগের "launcher_prefs" ফাইলই ব্যবহার করে। */
class LauncherSettings(context: Context) {

    val prefs: SharedPreferences =
        context.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)

    private fun bool(key: String, def: Boolean) = prefs.getBoolean(key, def)
    private fun int(key: String, def: Int) = prefs.getInt(key, def)
    private fun put(key: String, v: Boolean) = prefs.edit().putBoolean(key, v).apply()
    private fun put(key: String, v: Int) = prefs.edit().putInt(key, v).apply()

    // ---- Home screen ----
    var homeCols: Int
        get() = int("home_cols", 4)
        set(v) = put("home_cols", v)
    var showLabels: Boolean
        get() = bool("show_labels", true)
        set(v) = put("show_labels", v)
    var showDots: Boolean
        get() = bool("show_dots", true)
        set(v) = put("show_dots", v)
    var showClock: Boolean
        get() = bool("show_clock", true)
        set(v) = put("show_clock", v)
    var showChip: Boolean
        get() = bool("show_chip", false)
        set(v) = put("show_chip", v)
    var showSearchPill: Boolean
        get() = bool("show_search_pill", true)
        set(v) = put("show_search_pill", v)
    var lockLayout: Boolean
        get() = bool("lock_layout", false)
        set(v) = put("lock_layout", v)
    var parallax: Boolean
        get() = bool("parallax", true)
        set(v) = put("parallax", v)

    /** প্রতি পেজে সারি: 4..6 */
    var homeRows: Int
        get() = int("home_rows", 5)
        set(v) = put("home_rows", v)
    /** 0 = ছোট, 1 = মাঝারি, 2 = বড় */
    var labelSize: Int
        get() = int("label_size", 1)
        set(v) = put("label_size", v)
    /** 0 = Soft (ছোট হয়ে ফিকে), 1 = Classic (সাধারণ slide), 2 = Zoom */
    var pageEffect: Int
        get() = int("page_effect", 0)
        set(v) = put("page_effect", v)
    var homeOnPress: Boolean
        get() = bool("home_on_press", true)
        set(v) = put("home_on_press", v)
    var hideStatusBar: Boolean
        get() = bool("hide_status_bar", false)
        set(v) = put("hide_status_bar", v)
    var edgeFlip: Boolean
        get() = bool("edge_flip", true)
        set(v) = put("edge_flip", v)
    var pressAnim: Boolean
        get() = bool("press_anim", true)
        set(v) = put("press_anim", v)

    /** অপঠিত notification badge (Notification access লাগে) */
    var badges: Boolean
        get() = bool("badges", false)
        set(v) = put("badges", v)
    /** Home-এর ফাঁকা জায়গায় double-tap করে screen lock (Accessibility লাগে) */
    var doubleTapLock: Boolean
        get() = bool("double_tap_lock", false)
        set(v) = put("double_tap_lock", v)
    /** landscape চালু (বন্ধ থাকলে শুধু portrait) */
    var landscape: Boolean
        get() = bool("landscape", false)
        set(v) = put("landscape", v)
    /** Hidden apps খুলতে fingerprint */
    var fingerprint: Boolean
        get() = bool("fingerprint", false)
        set(v) = put("fingerprint", v)
    /** Icon pack-এর package নাম; ফাঁকা = সিস্টেম আইকন */
    var iconPack: String
        get() = prefs.getString("icon_pack", "") ?: ""
        set(v) { prefs.edit().putString("icon_pack", v).apply() }

    // ---- Dock ----
    var showDock: Boolean
        get() = bool("show_dock", true)
        set(v) = put("show_dock", v)
    var dockBackground: Boolean
        get() = bool("dock_background", true)
        set(v) = put("dock_background", v)

    // ---- Icons ----
    /** 0 = iOS squircle, 1 = circle, 2 = rounded square, 3 = square */
    var iconShape: Int
        get() = int("icon_shape", 0)
        set(v) = put("icon_shape", v)
    /** শতকরা (70..130) */
    var iconScale: Int
        get() = int("icon_scale", 110)
        set(v) = put("icon_scale", v)
    var iconShadow: Boolean
        get() = bool("icon_shadow", true)
        set(v) = put("icon_shadow", v)

    // ---- App drawer ----
    var drawerCols: Int
        get() = int("drawer_cols", 4)
        set(v) = put("drawer_cols", v)
    /** 0 = A–Z, 1 = সবচেয়ে বেশি ব্যবহৃত, 2 = নিজের সাজানো (drag করে) */
    var sortMode: Int
        get() = int("sort_mode", 0)
        set(v) = put("sort_mode", v)
    /** Drawer-এ drag করে সাজানো অ্যাপের ক্রম (package নামের list) */
    var drawerOrder: List<String>
        get() = (prefs.getString("drawer_order", "") ?: "").split('\n').filter { it.isNotEmpty() }
        set(v) { prefs.edit().putString("drawer_order", v.joinToString("\n")).apply() }
    var drawerLabels: Boolean
        get() = bool("drawer_labels", true)
        set(v) = put("drawer_labels", v)
    var showSuggested: Boolean
        get() = bool("show_suggested", false)
        set(v) = put("show_suggested", v)
    var drawerKeyboard: Boolean
        get() = bool("drawer_keyboard", false)
        set(v) = put("drawer_keyboard", v)
    var blur: Boolean
        get() = bool("blur", true)
        set(v) = put("blur", v)
    /** drawer-এর পেছনের কালো পর্দা, 0..80 (শতকরা) */
    var dim: Int
        get() = int("dim", 30)
        set(v) = put("dim", v)

    // ---- Gestures ----
    var swipeUp: Boolean
        get() = bool("swipe_up", true)
        set(v) = put("swipe_up", v)
    /** 0 = notification, 1 = search, 2 = কিছু না */
    var swipeDown: Int
        get() = int("swipe_down", 0)
        set(v) = put("swipe_down", v)
    var pinchHidden: Boolean
        get() = bool("pinch_hidden", true)
        set(v) = put("pinch_hidden", v)
    var haptics: Boolean
        get() = bool("haptics", true)
        set(v) = put("haptics", v)

    // ---- Animation ----
    var iosAnim: Boolean
        get() = bool("ios_anim", true)
        set(v) = put("ios_anim", v)
    /** Default launcher না হলে মাঝে মাঝে মনে করিয়ে দেয় */
    var defaultReminder: Boolean
        get() = bool("default_reminder", true)
        set(v) = put("default_reminder", v)
    /** ফোন যত উঁচু refresh rate (90/120 Hz) সাপোর্ট করে তা ব্যবহার করে */
    var highRefresh: Boolean
        get() = bool("high_refresh", true)
        set(v) = put("high_refresh", v)
    /** 0 = ধীর, 1 = স্বাভাবিক, 2 = দ্রুত */
    var animSpeed: Int
        get() = int("anim_speed", 1)
        set(v) = put("anim_speed", v)

    // ---- Appearance ----
    /** 0 = সিস্টেম, 1 = Light, 2 = Dark */
    var theme: Int
        get() = int("theme", 0)
        set(v) = put("theme", v)

    /** PIN ও "asked_default" বাদে সব সেটিং মুছে ডিফল্টে ফেরায়। */
    fun resetAll() {
        val keepStr = mapOf(
            "pin6_hash" to prefs.getString("pin6_hash", null),
            "pin6_salt" to prefs.getString("pin6_salt", null)
        )
        val fails = prefs.getInt("pin_fails", 0)
        val lockUntil = prefs.getLong("pin_lock_until", 0L)
        prefs.edit().clear().apply()
        val e = prefs.edit().putBoolean("asked_default", true)
        keepStr.forEach { (k, v) -> if (v != null) e.putString(k, v) }
        // reset দিয়ে PIN lockout এড়ানো যাবে না
        if (fails > 0) e.putInt("pin_fails", fails)
        if (lockUntil > 0L) e.putLong("pin_lock_until", lockUntil)
        e.apply()
    }
}
