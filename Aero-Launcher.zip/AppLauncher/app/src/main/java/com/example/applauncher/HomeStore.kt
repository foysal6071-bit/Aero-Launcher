package com.example.applauncher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Home screen পেজ ও dock-এ কোন অ্যাপ আছে তা SharedPreferences-এ সংরক্ষণ করে। */
class HomeStore(context: Context) {

    /** Folder: একাধিক অ্যাপ এক আইকনে। পেজের তালিকায় এর id ("folder:...") বসে। */
    class Folder(val id: String, var name: String, val apps: MutableList<String>)

    companion object {
        const val DOCK_SIZE = 4
        const val FOLDER_PREFIX = "folder:"
        const val MAX_PAGES = 9
        fun isFolderId(s: String) = s.startsWith(FOLDER_PREFIX)
    }

    /** landscape-এ প্রথম পেজেও ঘড়ি থাকে না, তাই পুরো পেজ আইকনের */
    var landscape: Boolean = false

    /** Home গ্রিডের কলাম (Settings থেকে বদলায়) */
    var columns: Int = 4
    /** প্রতি পেজে সারি (Settings থেকে বদলায়); প্রথম পেজে ঘড়ি থাকে, তাই ২ সারি কম */
    var rows: Int = 5
    val pageSize: Int get() = columns * rows
    val firstPageSize: Int get() = if (landscape) pageSize else columns * (rows - 2).coerceAtLeast(2)

    private val prefs = context.getSharedPreferences("home_layout", Context.MODE_PRIVATE)

    var pages: MutableList<MutableList<String>> = mutableListOf()
        private set
    var dock: MutableList<String> = mutableListOf()
        private set

    /** Hidden অ্যাপ: drawer ও home থেকে লুকানো থাকে, শুধু home-এ pinch/zoom করলে দেখা যায়। */
    var hidden: MutableSet<String> = linkedSetOf()
        private set

    var folders: MutableMap<String, Folder> = linkedMapOf()
        private set

    /** Today View-এ বসানো widget-এর ID */
    var widgetIds: MutableList<Int> = mutableListOf()
        private set

    val isFirstRun: Boolean get() = !prefs.contains("pages")

    init {
        pages = readPages(prefs.getString("pages", null))
        dock = readFlat(prefs.getString("dock", null))
        hidden = readFlat(prefs.getString("hidden", null)).toCollection(linkedSetOf())
        widgetIds = readFlat(prefs.getString("widgets", null)).mapNotNull { it.toIntOrNull() }.toMutableList()
        folders = readFolders(prefs.getString("folders", null))
        if (pages.isEmpty()) pages.add(mutableListOf())
    }

    fun isOnHome(pkg: String) =
        dock.contains(pkg) || pages.any { it.contains(pkg) } || folders.values.any { it.apps.contains(pkg) }

    /** Home/dock/folder সব মিলিয়ে যত অ্যাপ আছে (folder-এর id বাদে) */
    fun allHomeApps(): Set<String> {
        val out = linkedSetOf<String>()
        pages.forEach { p -> p.forEach { if (!isFolderId(it)) out.add(it) } }
        out.addAll(dock)
        folders.values.forEach { out.addAll(it.apps) }
        return out
    }

    /** Layout-এর মাপ (কলাম/সারি/orientation) বদলালে true: পেজগুলো নতুন করে ভাগ হয়। */
    fun ensureLayout(key: String): Boolean {
        val old = prefs.getString("layout_key", null)
        prefs.edit().putString("layout_key", key).apply()
        if (old != null && old != key) {
            repaginate()
            return true
        }
        return false
    }

    fun isInDock(pkg: String) = dock.contains(pkg)

    fun isHidden(pkg: String) = hidden.contains(pkg)

    /** অ্যাপ লুকায়: home ও dock থেকেও সরে যায়। */
    fun hide(pkg: String) {
        pages.forEach { it.remove(pkg) }
        dock.remove(pkg)
        folders.values.forEach { it.apps.remove(pkg) }
        cleanFolders()
        dropEmptyPages()
        hidden.add(pkg)
        save()
    }

    fun unhide(pkg: String) {
        if (hidden.remove(pkg)) save()
    }

    fun setDefaults(home: List<String>, dockApps: List<String>) {
        val first = home.take(firstPageSize).toMutableList()
        val rest = home.drop(firstPageSize).chunked(pageSize).map { it.toMutableList() }
        pages = (listOf(first) + rest).toMutableList()
        if (pages.isEmpty()) pages.add(mutableListOf())
        dock = dockApps.take(DOCK_SIZE).toMutableList()
        folders.clear()
        save()
    }

    /** ইনস্টল না থাকা অ্যাপ মুছে ফেলে। */
    fun prune(valid: Set<String>) {
        pages.forEach { page -> page.retainAll { valid.contains(it) || folders.containsKey(it) } }
        dock.retainAll(valid)
        hidden.retainAll(valid)
        folders.values.forEach { it.apps.retainAll(valid) }
        cleanFolders()
        dropEmptyPages()
        save()
    }

    fun addToHome(pkg: String): Boolean {
        if (isOnHome(pkg)) return false
        val page = pages.withIndex()
            .firstOrNull { (i, p) -> p.size < (if (i == 0) firstPageSize else pageSize) }?.value
            ?: mutableListOf<String>().also { pages.add(it) }
        page.add(pkg)
        save()
        return true
    }

    fun removeFromHome(pkg: String) {
        pages.forEach { it.remove(pkg) }
        dock.remove(pkg)
        folders.values.forEach { it.apps.remove(pkg) }
        cleanFolders()
        dropEmptyPages()
        save()
    }

    fun moveToDock(pkg: String): Boolean {
        if (isFolderId(pkg) || dock.size >= DOCK_SIZE || dock.contains(pkg)) return false
        pages.forEach { it.remove(pkg) }
        folders.values.forEach { it.apps.remove(pkg) }
        cleanFolders()
        dock.add(pkg)
        dropEmptyPages()
        save()
        return true
    }

    // ---------- Folder ----------

    /** [dragged]-কে [target]-এর ওপর ফেললে: target সাধারণ অ্যাপ হলে নতুন folder, folder হলে তাতে যোগ। */
    fun mergeInto(target: String, dragged: String): Boolean {
        if (target == dragged || isFolderId(dragged)) return false
        return if (isFolderId(target)) addToFolder(target, dragged) else createFolder(target, dragged)
    }

    private fun createFolder(target: String, dragged: String): Boolean {
        val page = pages.firstOrNull { it.contains(target) } ?: return false
        val idx = page.indexOf(target)
        val id = FOLDER_PREFIX + System.currentTimeMillis()
        page[idx] = id
        pages.forEach { it.remove(dragged) }
        dock.remove(dragged)
        folders[id] = Folder(id, "Folder", mutableListOf(target, dragged))
        return true
    }

    private fun addToFolder(folderId: String, pkg: String): Boolean {
        val f = folders[folderId] ?: return false
        pages.forEach { it.remove(pkg) }
        dock.remove(pkg)
        if (!f.apps.contains(pkg)) f.apps.add(pkg)
        return true
    }

    fun renameFolder(id: String, name: String) {
        val f = folders[id] ?: return
        val n = name.trim().ifEmpty { "Folder" }
        if (f.name != n) {
            f.name = n
            save()
        }
    }

    /** Folder থেকে একটি অ্যাপ বের করে একই পেজে (জায়গা না থাকলে অন্য পেজে) রাখে। */
    fun removeFromFolder(folderId: String, pkg: String) {
        val f = folders[folderId] ?: return
        if (!f.apps.remove(pkg)) return
        val pageIdx = pages.indexOfFirst { it.contains(folderId) }.coerceAtLeast(0)
        val cap = if (pageIdx == 0) firstPageSize else pageSize
        val page = pages.getOrNull(pageIdx)
        if (page != null && page.size < cap) {
            val at = page.indexOf(folderId)
            page.add(if (at >= 0) at + 1 else page.size, pkg)
        } else {
            val target = pages.withIndex()
                .firstOrNull { (i, p) -> p.size < (if (i == 0) firstPageSize else pageSize) }?.value
                ?: mutableListOf<String>().also { pages.add(it) }
            target.add(pkg)
        }
        cleanFolders()
        save()
    }

    /** Folder ভেঙে ভেতরের অ্যাপগুলো Home-এ ছড়িয়ে দেয়। */
    fun dissolveFolder(id: String) {
        val f = folders[id] ?: return
        val page = pages.firstOrNull { it.contains(id) }
        if (page != null) {
            val at = page.indexOf(id)
            page.removeAt(at)
            page.addAll(at, f.apps)
        }
        folders.remove(id)
        repaginate()
    }

    /** ১টি বা ০টি অ্যাপ থাকা folder মুছে দেয় (১টি থাকলে অ্যাপটা folder-এর জায়গায় বসে)। */
    fun cleanFolders() {
        val iter = folders.values.iterator()
        while (iter.hasNext()) {
            val f = iter.next()
            val referenced = pages.any { p -> p.contains(f.id) }
            if (!referenced) {
                iter.remove()
                continue
            }
            if (f.apps.size <= 1) {
                pages.forEach { p ->
                    val at = p.indexOf(f.id)
                    if (at >= 0) {
                        if (f.apps.isEmpty()) p.removeAt(at) else p[at] = f.apps[0]
                    }
                }
                iter.remove()
            }
        }
    }

    // ---------- নতুন পেজ / drawer থেকে drag ----------

    fun canAddPage(draggedPkg: String): Boolean {
        if (pages.size >= MAX_PAGES) return false
        val last = pages.last()
        return last.isNotEmpty() && !(last.size == 1 && last[0] == draggedPkg)
    }

    /** শেষে ফাঁকা পেজ যোগ করে (সংরক্ষণ হয় [commit]-এ; ফাঁকা থাকলে commit-এ বাদ যায়) */
    fun addEmptyPage() {
        pages.add(mutableListOf())
    }

    /** Drawer থেকে drag শুরুর আগে অ্যাপটাকে Home-এর (পছন্দের পেজে) বসায়। */
    fun ensureOnHomePage(pkg: String, preferredPage: Int) {
        folders.values.forEach { it.apps.remove(pkg) }
        cleanFolders()
        if (dock.contains(pkg) || pages.any { it.contains(pkg) }) return
        val pi = preferredPage.coerceIn(0, pages.size - 1)
        val cap = if (pi == 0) firstPageSize else pageSize
        if (pages[pi].size < cap) pages[pi].add(pkg) else addToHome(pkg)
    }

    /** কলাম বদলালে সব অ্যাপ নতুন করে পেজে সাজায়। */
    fun repaginate() {
        val flat = pages.flatten()
        val first = flat.take(firstPageSize).toMutableList()
        val rest = flat.drop(firstPageSize).chunked(pageSize).map { it.toMutableList() }
        pages = (listOf(first) + rest).toMutableList()
        dropEmptyPages()
        save()
    }

    /** drag করে সাজানোর পর একটি পেজের নতুন ক্রম সংরক্ষণ করে। */
    fun setPageOrder(index: Int, pkgs: List<String>) {
        if (index !in pages.indices) return
        pages[index] = pkgs.toMutableList()
        save()
    }

    /**
     * drag করার সময় [pkg]-কে নতুন জায়গায় সরায় (শুধু মেমরিতে; সংরক্ষণ হয় [commit]-এ)।
     * [toDock] হলে dock-এ, নইলে [pageIndex] নম্বর পেজে, [index] অবস্থানে।
     * জায়গা না থাকলে বা কিছু বদলালে না হলে false।
     */
    fun moveTo(pkg: String, toDock: Boolean, pageIndex: Int, index: Int): Boolean {
        if (toDock && isFolderId(pkg)) return false
        val src: MutableList<String> = when {
            dock.contains(pkg) -> dock
            else -> pages.firstOrNull { it.contains(pkg) } ?: return false
        }
        val dst: MutableList<String> = if (toDock) dock else (pages.getOrNull(pageIndex) ?: return false)
        if (src === dst) {
            val from = dst.indexOf(pkg)
            val to = index.coerceIn(0, dst.size - 1)
            if (from == to) return false
            dst.add(to, dst.removeAt(from))
            return true
        }
        val capacity = when {
            toDock -> DOCK_SIZE
            pageIndex == 0 -> firstPageSize
            else -> pageSize
        }
        if (dst.size >= capacity) return false
        src.remove(pkg)
        dst.add(index.coerceIn(0, dst.size), pkg)
        return true
    }

    /** [pkg] কোন আইকন-পেজে আছে (dock-এ বা কোথাও না থাকলে -1) */
    fun pageIndexOf(pkg: String): Int = pages.indexOfFirst { it.contains(pkg) }

    /** drag শেষে: ফাঁকা পেজ বাদ দিয়ে সংরক্ষণ করে */
    fun commit() {
        dropEmptyPages()
        save()
    }

    fun setDockOrder(pkgs: List<String>) {
        dock = pkgs.toMutableList()
        save()
    }

    fun addWidget(id: Int) {
        if (!widgetIds.contains(id)) widgetIds.add(id)
        save()
    }

    fun removeWidget(id: Int) {
        widgetIds.remove(id)
        save()
    }

    private fun dropEmptyPages() {
        // প্রথম পেজে ঘড়ি থাকে (৩ সারির জায়গা), তাই সেটা ফাঁকা হলেও রাখি — নইলে পরের পেজের ৫ সারি ঢুকে যেত
        for (i in pages.indices.reversed()) {
            if (i > 0 && pages[i].isEmpty()) pages.removeAt(i)
        }
        if (pages.isEmpty()) pages.add(mutableListOf())
    }

    private fun save() {
        val outer = JSONArray()
        pages.forEach { page ->
            val inner = JSONArray()
            page.forEach { inner.put(it) }
            outer.put(inner)
        }
        val dockArr = JSONArray()
        dock.forEach { dockArr.put(it) }
        val hiddenArr = JSONArray()
        hidden.forEach { hiddenArr.put(it) }
        val widgetArr = JSONArray()
        widgetIds.forEach { widgetArr.put(it.toString()) }
        val folderArr = JSONArray()
        folders.values.forEach { f ->
            val o = JSONObject()
            o.put("id", f.id)
            o.put("name", f.name)
            val a = JSONArray()
            f.apps.forEach { a.put(it) }
            o.put("apps", a)
            folderArr.put(o)
        }
        prefs.edit()
            .putString("pages", outer.toString())
            .putString("dock", dockArr.toString())
            .putString("hidden", hiddenArr.toString())
            .putString("widgets", widgetArr.toString())
            .putString("folders", folderArr.toString())
            .apply()
    }

    private fun readFlat(json: String?): MutableList<String> {
        val out = mutableListOf<String>()
        if (json == null) return out
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (_: Exception) {
        }
        return out
    }

    private fun readPages(json: String?): MutableList<MutableList<String>> {
        val out = mutableListOf<MutableList<String>>()
        if (json == null) return out
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val inner = arr.getJSONArray(i)
                val page = mutableListOf<String>()
                for (j in 0 until inner.length()) page.add(inner.getString(j))
                out.add(page)
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun readFolders(json: String?): MutableMap<String, Folder> {
        val out = linkedMapOf<String, Folder>()
        if (json == null) return out
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val a = o.getJSONArray("apps")
                val apps = mutableListOf<String>()
                for (j in 0 until a.length()) apps.add(a.getString(j))
                val id = o.getString("id")
                out[id] = Folder(id, o.optString("name", "Folder"), apps)
            }
        } catch (_: Exception) {
        }
        return out
    }
}
