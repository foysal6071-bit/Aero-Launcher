package com.example.applauncher

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * "Default home app" সম্পর্কিত সব: প্রথমবার চালুতে জিজ্ঞাসা, না থাকলে মাঝে মাঝে মনে করানো,
 * আর সিস্টেম ডায়ালগ / Home app সেটিংস খোলা।
 *
 * [roleLauncher] = সিস্টেমের role-request intent চালানোর কাজ (Activity-র registerForActivityResult),
 * [canInterrupt] = এখন ডায়ালগ দেখালে বিরক্তিকর হবে না (অন্য প্যানেল/animation খোলা নেই)।
 */
class DefaultLauncher(
    private val activity: AppCompatActivity,
    private val settings: LauncherSettings,
    private val roleLauncher: (Intent) -> Unit,
    private val isStopped: () -> Boolean,
    private val canInterrupt: () -> Boolean
) {
    private val prefs get() = activity.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)

    private val handler = Handler(Looper.getMainLooper())
    private var dialog: AlertDialog? = null
    private val remindIntervalMs = 10 * 60_000L   // প্রতি ১০ মিনিটে একবার

    private val tick = object : Runnable {
        override fun run() {
            maybeRemind()
            handler.postDelayed(this, 60_000L)
        }
    }

    fun isDefault(): Boolean {
        // Android 10+: সিস্টেমের role থেকে সরাসরি জানা যায় — এটাই সবচেয়ে নির্ভরযোগ্য
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val rm = activity.getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    return rm.isRoleHeld(RoleManager.ROLE_HOME)
                }
            } catch (_: Exception) {
            }
        }
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val res = activity.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
        return res?.activityInfo?.packageName == activity.packageName
    }

    /** প্রথমবার চালু হলে "Default home app" বানানোর ডায়ালগ দেখায়। */
    fun askOnce() {
        if (prefs.getBoolean("asked_default", false)) return
        prefs.edit().putBoolean("asked_default", true)
            .putLong("last_default_ask", System.currentTimeMillis()).apply()
        request()
    }

    /** onResume-এ: ৫ সেকেন্ড পর থেকে প্রতি মিনিটে পরীক্ষা করে */
    fun startReminders() {
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 5000)
    }

    fun stopReminders() {
        handler.removeCallbacks(tick)
    }

    fun destroy() {
        handler.removeCallbacksAndMessages(null)
        dialog?.dismiss()
    }

    private fun maybeRemind() {
        if (isStopped() || !settings.defaultReminder) return
        if (isDefault()) {
            prefs.edit().remove("role_asks").apply()
            return
        }
        if (dialog?.isShowing == true) return
        // অন্য কিছু খোলা থাকলে বিরক্ত করি না
        if (!canInterrupt()) return
        val now = System.currentTimeMillis()
        if (now - prefs.getLong("last_default_ask", 0L) < remindIntervalMs) return
        prefs.edit().putLong("last_default_ask", now).apply()
        dialog = AlertDialog.Builder(activity)
            .setTitle("Make Aero Launcher your home app?")
            .setMessage("Set it as the default launcher so the Home button always opens it.")
            .setPositiveButton("Set as default") { _, _ -> request() }
            // "Later" চাপলে আর মনে করাব না (Settings থেকে আবার চালু করা যাবে)
            .setNegativeButton("Later") { _, _ -> settings.defaultReminder = false }
            .show()
    }

    fun request() {
        try {
            val asks = prefs.getInt("role_asks", 0)
            // সিস্টেম দুবার ডায়ালগ দেখানোর পর আর নাও দেখাতে পারে, তাই তখন সরাসরি Home app সেটিংসে নিয়ে যাই
            if (Build.VERSION.SDK_INT >= 29 && asks < 2) {
                val rm = activity.getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) &&
                    !rm.isRoleHeld(RoleManager.ROLE_HOME)
                ) {
                    prefs.edit().putInt("role_asks", asks + 1).apply()
                    roleLauncher(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                }
            } else {
                activity.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            }
        } catch (_: Exception) {
        }
    }
}
