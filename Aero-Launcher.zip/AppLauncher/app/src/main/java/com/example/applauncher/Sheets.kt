package com.example.applauncher

import android.app.Activity
import android.app.Dialog
import android.appwidget.AppWidgetProviderInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** নিচ থেকে উঠে আসা iOS-স্টাইল sheet (Widgets ও Wallpapers-এর জন্য)। */
class BottomSheet(private val activity: Activity, private val dark: Boolean, title: String) {

    val dialog = Dialog(activity, R.style.SheetDialog)
    val body = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
    private val root = FrameLayout(activity)
    private val d = activity.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    val textColor = if (dark) Color.WHITE else Color.BLACK
    val subColor = if (dark) Color.parseColor("#99EBEBF5") else Color.parseColor("#993C3C43")
    val cardColor = if (dark) Color.parseColor("#2C2C2E") else Color.WHITE
    private val sheetColor = if (dark) Color.parseColor("#1C1C1E") else Color.parseColor("#F2F2F7")

    private val card = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            setColor(sheetColor)
            cornerRadii = floatArrayOf(dp(26).toFloat(), dp(26).toFloat(), dp(26).toFloat(), dp(26).toFloat(), 0f, 0f, 0f, 0f)
        }
        setPadding(dp(16), dp(10), dp(16), dp(28))
    }

    init {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.4f)
        }
        // হ্যান্ডেল
        card.addView(View(activity).apply {
            background = GradientDrawable().apply { cornerRadius = dp(3).toFloat(); setColor(subColor) }
        }, LinearLayout.LayoutParams(dp(38), dp(5)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(12)
        })
        card.addView(TextView(activity).apply {
            text = title
            setTextColor(textColor)
            textSize = 20f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setPadding(dp(4), 0, 0, dp(10))
        })
        card.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        root.setOnClickListener { dismiss() }
        card.setOnClickListener { }
        dialog.setContentView(root)
    }

    fun show() {
        dialog.show()
        // Dialog-এর default মাপ wrap_content, তাই sheet সরু হয়ে যেত — show-এর পরে পুরো স্ক্রিন করি
        dialog.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setGravity(Gravity.BOTTOM)
        }
        card.alpha = 0f
        card.post {
            card.translationY = card.height.toFloat()
            card.alpha = 1f
            card.animate().translationY(0f).setDuration(340)
                .setInterpolator(PathInterpolator(0.22f, 1f, 0.36f, 1f)).start()
        }
    }

    private var dismissing = false

    fun dismiss() {
        if (dismissing) return
        dismissing = true
        card.animate().translationY(card.height.toFloat()).setDuration(220)
            .setInterpolator(PathInterpolator(0.4f, 0f, 1f, 1f))
            .withEndAction { if (dialog.isShowing) dialog.dismiss() }
            .start()
    }

    /** body-র ভেতরে সর্বোচ্চ উচ্চতার scroll area */
    fun scrollArea(maxHeightDp: Int): LinearLayout {
        val inner = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        val sv = object : ScrollView(activity) {
            override fun onMeasure(w: Int, h: Int) {
                super.onMeasure(w, MeasureSpec.makeMeasureSpec(dp(maxHeightDp), MeasureSpec.AT_MOST))
            }
        }
        sv.addView(inner)
        body.addView(sv)
        return inner
    }
}

object Sheets {

    // ---------------- Widgets ----------------

    fun showWidgetPicker(
        activity: Activity,
        dark: Boolean,
        providers: List<AppWidgetProviderInfo>,
        worker: java.util.concurrent.ExecutorService,
        onPick: (AppWidgetProviderInfo) -> Unit
    ) {
        val sheet = BottomSheet(activity, dark, "Widgets")
        val list = sheet.scrollArea(460)
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val loading = TextView(activity).apply {
            text = "Loading…"
            setTextColor(sheet.subColor)
            setPadding(dp(4), dp(8), 0, dp(8))
        }
        list.addView(loading)
        sheet.show()

        worker.execute {
            val pm = activity.packageManager
            data class Row(val info: AppWidgetProviderInfo, val label: String, val app: String, val preview: Drawable?)
            val rows = providers
                .filter { it.provider.packageName != activity.packageName }
                .mapNotNull { info ->
                    try {
                        val label = info.loadLabel(pm).toString()
                        val app = try {
                            pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString()
                        } catch (_: Exception) {
                            info.provider.packageName
                        }
                        val preview = try {
                            info.loadPreviewImage(activity, 0) ?: info.loadIcon(activity, 0)
                        } catch (_: Exception) {
                            null
                        }
                        Row(info, label, app, preview)
                    } catch (_: Exception) {
                        null
                    }
                }
                .sortedWith(compareBy({ it.app.lowercase() }, { it.label.lowercase() }))
            activity.runOnUiThread {
                if (!sheet.dialog.isShowing) return@runOnUiThread
                list.removeAllViews()
                if (rows.isEmpty()) {
                    list.addView(TextView(activity).apply {
                        text = "No widgets found on this device."
                        setTextColor(sheet.subColor)
                        setPadding(dp(4), dp(8), 0, dp(8))
                    })
                }
                rows.forEach { r ->
                    val row = LinearLayout(activity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(12), dp(10), dp(12), dp(10))
                        background = GradientDrawable().apply {
                            cornerRadius = dp(16).toFloat()
                            setColor(sheet.cardColor)
                        }
                        setOnClickListener {
                            sheet.dismiss()
                            onPick(r.info)
                        }
                    }
                    row.addView(ImageView(activity).apply {
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        setImageDrawable(r.preview)
                    }, LinearLayout.LayoutParams(dp(92), dp(64)))
                    val texts = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
                    texts.addView(TextView(activity).apply {
                        text = r.label
                        setTextColor(sheet.textColor)
                        textSize = 16f
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                    })
                    texts.addView(TextView(activity).apply {
                        text = r.app
                        setTextColor(sheet.subColor)
                        textSize = 13f
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                    })
                    row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginStart = dp(14)
                    })
                    list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = dp(8)
                    })
                }
            }
        }
    }

    // ---------------- Wallpapers ----------------

    class Preset(val name: String, val colors: IntArray, val glowA: Int, val glowB: Int)

    val presets = listOf(
        Preset("Aurora", intArrayOf(c("#1B1464"), c("#5B2A9E"), c("#E0559C")), c("#5CE1E6"), c("#FF9A8B")),
        Preset("Sunset", intArrayOf(c("#FF7E5F"), c("#FD3A84"), c("#7F00FF")), c("#FFD36E"), c("#00C6FF")),
        Preset("Ocean", intArrayOf(c("#0F2027"), c("#1E5F8E"), c("#2BC0E4")), c("#7CF7D4"), c("#6A82FB")),
        Preset("Mint", intArrayOf(c("#0BA360"), c("#3CBA92"), c("#B8F2E6")), c("#FFFFFF"), c("#30CFD0")),
        Preset("Blossom", intArrayOf(c("#FBC2EB"), c("#F78FAD"), c("#A18CD1")), c("#FFFFFF"), c("#FFD1FF")),
        Preset("Midnight", intArrayOf(c("#000000"), c("#16213E"), c("#0F3460")), c("#533483"), c("#E94560")),
        Preset("Ember", intArrayOf(c("#42275A"), c("#B24A4A"), c("#F7971E")), c("#FFD200"), c("#FF512F")),
        Preset("Graphite", intArrayOf(c("#232526"), c("#414345"), c("#6C7A89")), c("#BDC3C7"), c("#2C3E50"))
    )

    private fun c(s: String) = Color.parseColor(s)

    /** iOS-এর মতো রঙিন gradient + নরম আলোর ছোপ দিয়ে wallpaper বানায়। */
    fun renderPreset(p: Preset, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(0f, 0f, w * 0.55f, h.toFloat(), p.colors, floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        fun glow(cx: Float, cy: Float, r: Float, color: Int) {
            val soft = Color.argb(150, Color.red(color), Color.green(color), Color.blue(color))
            val none = Color.argb(0, Color.red(color), Color.green(color), Color.blue(color))
            paint.shader = RadialGradient(cx, cy, r, soft, none, Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, r, paint)
        }
        glow(w * 0.18f, h * 0.22f, w * 0.85f, p.glowA)
        glow(w * 0.88f, h * 0.78f, w * 0.95f, p.glowB)
        return bmp
    }

    fun showWallpaperSheet(
        activity: Activity,
        dark: Boolean,
        onPreset: (Preset) -> Unit,
        onGallery: () -> Unit,
        onSystemPicker: () -> Unit
    ) {
        val sheet = BottomSheet(activity, dark, "Wallpapers")
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val strip = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        presets.forEach { p ->
            val thumb = View(activity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, p.colors).apply {
                    cornerRadius = dp(18).toFloat()
                }
                setOnClickListener {
                    sheet.dismiss()
                    onPreset(p)
                }
            }
            val cell = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            cell.addView(thumb, LinearLayout.LayoutParams(dp(86), dp(150)))
            cell.addView(TextView(activity).apply {
                text = p.name
                setTextColor(sheet.subColor)
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, 0)
            })
            strip.addView(cell, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dp(12)
            })
        }
        val hs = HorizontalScrollView(activity).apply {
            isHorizontalScrollBarEnabled = false
            addView(strip)
        }
        sheet.body.addView(hs)

        fun action(text: String, run: () -> Unit) {
            sheet.body.addView(TextView(activity).apply {
                this.text = text
                setTextColor(Color.parseColor("#0A84FF"))
                textSize = 16f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
                background = GradientDrawable().apply {
                    cornerRadius = dp(14).toFloat()
                    setColor(sheet.cardColor)
                }
                setOnClickListener {
                    sheet.dismiss()
                    run()
                }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)).apply { topMargin = dp(12) })
        }
        action("Choose from Photos") { onGallery() }
        action("Open system wallpaper picker") { onSystemPicker() }
        sheet.show()
    }
}
