package com.example.applauncher

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.ExecutorService

/**
 * Wallpaper বদলানো: বিল্ট-ইন gradient, গ্যালারির ছবি বা সিস্টেম picker।
 * গ্যালারি picker-এর registerForActivityResult কাজ করে বলে এটা Activity-র onCreate-এ বানাতে হবে।
 */
class WallpaperController(
    private val activity: AppCompatActivity,
    private val worker: ExecutorService,
    private val host: Host
) {

    interface Host {
        fun isDarkUi(): Boolean
        fun toast(msg: String)
        /** wallpaper বদলানো হলে (ঝাপসা কপি নতুন করে বানাতে) */
        fun onWallpaperChanged()
    }

    private val galleryPicker =
        activity.registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) setFromUri(uri)
        }

    fun openSheet() {
        Sheets.showWallpaperSheet(
            activity, host.isDarkUi(),
            onPreset = { p ->
                worker.execute {
                    val dm = activity.resources.displayMetrics
                    applyBitmap(Sheets.renderPreset(p, dm.widthPixels, dm.heightPixels))
                }
            },
            onGallery = { galleryPicker.launch("image/*") },
            onSystemPicker = {
                try {
                    activity.startActivity(
                        Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")
                    )
                } catch (_: Exception) {
                    host.toast("No wallpaper picker found")
                }
            }
        )
    }

    /** Background thread-এ চলে */
    private fun applyBitmap(bmp: Bitmap) {
        val ok = WallpaperTools.apply(activity, bmp)
        activity.runOnUiThread {
            host.toast(if (ok) "Wallpaper updated" else "Couldn't set wallpaper")
            if (ok) host.onWallpaperChanged()
        }
    }

    private fun setFromUri(uri: Uri) {
        worker.execute {
            try {
                val dm = activity.resources.displayMetrics
                applyBitmap(WallpaperTools.decodeForScreen(activity, uri, dm.widthPixels, dm.heightPixels))
            } catch (_: Exception) {
                activity.runOnUiThread { host.toast("Couldn't load that image") }
            }
        }
    }
}
