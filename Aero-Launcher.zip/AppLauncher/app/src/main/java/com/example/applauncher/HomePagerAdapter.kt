package com.example.applauncher

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * ViewPager2-এর জন্য।
 * position 0  = Today View (widget পেজ, iPhone-এর মতো বাঁয়ে)
 * position 1+ = আইকনের পেজ (প্রতিটি একটি গ্রিড)
 */
class HomePagerAdapter(
    private val widgetPage: View,
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo, View) -> Unit,
    private val drag: DragState = DragState()
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val TYPE_WIDGETS = 0
        const val TYPE_PAGE = 1
    }

    private var pages: List<List<AppInfo>> = emptyList()

    // এখন তৈরি থাকা সব আইকন-পেজ (drag শেষে আসল আইকন আবার দেখানোর জন্য)
    private val livePages = mutableListOf<PageVH>()

    // সব পেজ একই view pool শেয়ার করে, তাই পেজ বদলালে নতুন করে view বানাতে হয় না
    private val pool = RecyclerView.RecycledViewPool()

    private var columns = 4
    private var iconSize = 0
    private var showLabels = true
    var labelSp = 11.5f
    var pressAnim = true
    /** landscape-এ ঘড়ি নেই, তাই উপরে কম ফাঁকা */
    var landscape = false

    fun configure(columns: Int, iconSize: Int, showLabels: Boolean) {
        this.columns = columns
        this.iconSize = iconSize
        this.showLabels = showLabels
        notifyDataSetChanged()
    }

    /** ব্যাকগ্রাউন্ডে গেলে পুল খালি করে দেয় */
    fun release() {
        pool.clear()
    }

    /**
     * পেজ-সংখ্যা একই থাকলে শুধু ভেতরের আইকনগুলো diff করে বদলায় — তাই আইকন নরমভাবে সরে/মিলিয়ে যায়,
     * পুরো পেজ ঝট করে নতুন করে আঁকা হয় না।
     */
    fun submit(newPages: List<List<AppInfo>>) {
        val sameCount = pages.size == newPages.size
        pages = newPages
        if (sameCount) notifyItemRangeChanged(1, newPages.size, true) else notifyDataSetChanged()
    }

    /** drag শেষে লুকানো আইকনটা আবার দেখায় */
    fun refreshVisible() {
        livePages.forEach { it.adapter.notifyItemRangeChanged(0, it.adapter.itemCount) }
    }

    class PageVH(val recycler: RecyclerView, val adapter: AppAdapter) :
        RecyclerView.ViewHolder(recycler)

    class WidgetVH(view: View) : RecyclerView.ViewHolder(view)

    override fun getItemViewType(position: Int) = if (position == 0) TYPE_WIDGETS else TYPE_PAGE

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if (viewType == TYPE_WIDGETS) {
            (widgetPage.parent as? ViewGroup)?.removeView(widgetPage)
            widgetPage.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            return WidgetVH(widgetPage)
        }
        // page transformer-এর alpha-র জন্য আলাদা offscreen layer লাগে না — swipe অনেক হালকা হয়
        val rv = object : RecyclerView(parent.context) {
            override fun hasOverlappingRendering() = false
        }
        rv.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        // Home পেজ স্ক্রল হয় না — স্ক্রল বন্ধ থাকলে ViewPager2-এর swipe অনেক মসৃণ হয়
        rv.layoutManager = object : GridLayoutManager(parent.context, columns) {
            override fun canScrollVertically() = false
        }
        rv.overScrollMode = View.OVER_SCROLL_NEVER
        rv.clipToPadding = false
        rv.isNestedScrollingEnabled = false
        rv.itemAnimator = SoftItemAnimator()
        rv.setHasFixedSize(true)
        rv.setRecycledViewPool(pool)
        val adapter = AppAdapter(true, onClick, onLongClick, drag)
        rv.adapter = adapter
        val vh = PageVH(rv, adapter)
        livePages.add(vh)
        return vh
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder !is PageVH) return
        val d = holder.recycler.resources.displayMetrics.density
        // প্রথম আইকন-পেজে উপরে ঘড়ির জায়গা ছাড়া হয়
        val top = if (landscape) 12 else if (position == 1) 276 else 64
        holder.recycler.setPadding((10 * d).toInt(), (top * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
        (holder.recycler.layoutManager as GridLayoutManager).spanCount = columns
        holder.adapter.iconSize = iconSize
        holder.adapter.labelSp = labelSp
        holder.adapter.pressAnim = pressAnim
        holder.adapter.showLabel = showLabels
        holder.adapter.submit(pages[position - 1])
    }

    override fun getItemCount() = pages.size + 1
}
