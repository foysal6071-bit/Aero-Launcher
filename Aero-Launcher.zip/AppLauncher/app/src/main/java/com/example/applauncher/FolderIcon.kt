package com.example.applauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF

/** Folder-এর আইকন: স্বচ্ছ ব্যাকগ্রাউন্ডে ভেতরের অ্যাপগুলোর ৩×৩ ছোট ছবি। */
object FolderIcon {

    fun render(icons: List<Bitmap>, size: Int, shape: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val inset = size * 0.06f
        val rect = RectF(inset, inset, size - inset, size - inset)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(120, 235, 235, 245) }
        c.drawPath(IconRenderer.shapePath(shape, rect), bg)

        val pad = size * 0.17f
        val gap = size * 0.03f
        val cell = (size - 2 * pad - 2 * gap) / 3f
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        icons.take(9).forEachIndexed { i, b ->
            val col = i % 3
            val row = i / 3
            val l = pad + col * (cell + gap)
            val t = pad + row * (cell + gap)
            c.drawBitmap(b, null, RectF(l, t, l + cell, t + cell), p)
        }
        return out
    }
}
