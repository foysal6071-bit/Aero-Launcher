package com.example.applauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.view.accessibility.AccessibilityEvent

/**
 * Home-এ double-tap করে screen lock করার জন্য। শুধু GLOBAL_ACTION_LOCK_SCREEN চালায় (Android 9+);
 * স্ক্রিনের কোনো লেখা বা ডেটা পড়ে না।
 */
class LockAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile private var instance: LockAccessibilityService? = null

        val isEnabled: Boolean get() = instance != null

        /** lock করতে পারলে true */
        fun lock(): Boolean {
            val s = instance ?: return false
            return if (Build.VERSION.SDK_INT >= 28) {
                s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            } else {
                false
            }
        }
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}
}
