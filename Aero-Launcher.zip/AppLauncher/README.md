# Aero Launcher

POCO Launcher-এর ধাঁচে বানানো একটি সহজ Android launcher (Kotlin)।

## v3.5

Drag-এর সময় ওপরে Remove / Uninstall জায়গা আসে; সার্চে ভালো ক্রম (শুরু/শব্দ/package), টাইপে কম CPU; drag আরও মসৃণ।

## v3.4 — Drawer থেকে ধরে Home-এ আনা

App list-এ আইকন চেপে ধরে ওপরে বা বাঁ/ডান কিনারায় নিলে সেটা Home-এ চলে আসে; তারপর ইচ্ছামতো বসানো যায়। Suggested থেকেও কাজ করে।

## v3.2 — যা বদলেছে

- **আরও smooth**: আইকন যোগ/সরানো/লুকানো/সার্চ — সবকিছু fade ও slide animation-এ হয়, হুট করে বদলায় না।
  Settings বদলালে (কলাম, আইকন সাইজ, Dock, Search বাটন, ঘড়ি…) grid নরমভাবে নতুন রূপে ফুটে ওঠে।
  PIN screen, Suggested কার্ড, Widget পেজ, ডট — সবখানে animation।
- **Home-এ আইকন ধরে সরানো**: আইকন চেপে ধরে আঙুল সরালে সেটা আঙুলের সাথে ভাসে, বাকিরা সরে জায়গা করে দেয়।
  পাশের কিনারায় ধরে রাখলে পরের/আগের পেজে যায়; Dock ↔ Home-এর মধ্যেও আনা-নেওয়া যায়।
  (Settings → Home screen → Lock layout চালু থাকলে বন্ধ)
- **নতুন সেটিংস**: Rows (4–6), Name size, Home বাটনে প্রথম পেজে ফেরা, Dock background, Status bar দেখানো/লুকানো,
  Drawer-এ সার্চের সাথে keyboard, drag-এ কিনারায় পেজ বদল, Icon press effect, Page effect (Soft/Classic/Zoom), Clear usage history।
- **Aero Launcher এখন app list-এ দেখা যায়** এবং নিজেকে Hide করা যায় না।

## ফিচার (v3.1 — iPhone স্টাইল)

- **iPhone app open animation**: আইকন থেকে গোল-কোণা পর্দা বড় হয়ে পুরো স্ক্রিন ভরে, অ্যাপ ফুটে ওঠে; অ্যাপ বন্ধ করলে আবার সেই আইকনে ছোট হয়ে ফিরে আসে (Settings → Animations থেকে বন্ধ/গতি বদল)
- **iOS UI**: squircle আইকন, গোল ডট, translucent dock, Search বাটন, iOS context menu, iOS Settings-এর মতো grouped list
- **Today View**: Home-এর একদম বাঁয়ের পেজে widget (সত্যিকারের Android widget)
- **Home-এর ফাঁকা জায়গায় long-press** → Settings / Wallpapers / Widgets
- **Wallpapers**: ৮টি বিল্ট-ইন gradient, গ্যালারি থেকে ছবি, সিস্টেম picker
- **Widgets**: ডিভাইসে ইনস্টল করা যেকোনো widget যোগ করা; widget-এ চেপে ধরলে Remove
- **Settings** (Home screen / Icons / App Library / Gestures / Animations / Appearance / Privacy / General):
  কলাম, আইকন সাইজ ও আকৃতি, নাম দেখানো, ডট, ঘড়ি, chip, Search বাটন, Dock, layout lock, parallax,
  sort, suggested, blur, dim, swipe up/down, pinch, haptic, animation গতি, Light/Dark মেনু, hidden apps + PIN,
  default launcher, reset
- **App Library** (swipe up): সার্চ, সাজানো (A–Z / বেশি ব্যবহৃত), Suggested
- **Hidden apps**: Home-এ দুই আঙুলে ছড়ালে; PIN লাগে
- **App shortcuts**: লং-প্রেস মেনুতে (default launcher হলে)

## ব্যবহারের টিপ

- Home-এর ফাঁকা জায়গায় আঙুল চেপে ধরে রাখুন → মেনু আসবে
- বাঁ দিকে swipe করলে Today View (widgets)
- আইকনে চেপে ধরলে iPhone-এর মতো মেনু (Hide, App Info, Delete…)

## GitHub Actions দিয়ে APK বানানো

1. এই ফোল্ডারের সব ফাইল একটি GitHub repo-তে push করুন (branch: `main`)।
2. repo-র **Actions** ট্যাবে **Build APK** workflow চালান।
3. শেষ হলে APK পাবেন (Artifacts বা Releases থেকে)।

## Home launcher হিসেবে সেট করা

ইনস্টলের পর Home বাটন চাপলে "Open with" থেকে **Aero Launcher** বেছে নিন, অথবা
Settings → Apps → Default apps → Home app থেকে সেট করুন।

## লোকালি build

Android Studio-তে প্রজেক্ট খুলে Run করুন, অথবা JDK 17 ও Gradle 8.7 থাকলে:

```
gradle assembleDebug
```

## v3.3 — নতুন ফিচার
- **Drawer → Home drag**: Drawer-এ আইকন ধরে স্ক্রিনের উপরের দিকে (~০.৪ সেকেন্ড) নিলে আইকন Home-এ চলে আসে।
- **নতুন পেজ**: drag করে শেষ পেজের ডান কিনারায় ধরে রাখলে নতুন ফাঁকা পেজ খোলে (ফাঁকা থাকলে ছাড়ার পর মুছে যায়)।
- **Folder**: একটা আইকন আরেকটার মাঝখানে ~০.৬ সেকেন্ড ধরে রেখে ছাড়ুন। Folder-এ ট্যাপ = খোলা/নাম বদল; আইকনে long-press = Rename / Remove Folder।
- **Notification badge**: Settings → Home Screen → Notification badges (Notification access লাগে)।
- **Icon pack**: Settings → Icons → Icon pack (ADW/Nova/Apex/GO প্যাক)।
- **Double-tap lock**: Settings → Gestures (Accessibility চালু করতে হয়, Android 9+)।
- **Landscape**: Settings → Home Screen → Allow landscape (landscape-এ ৮×২ গ্রিড, ঘড়ি/search বাটন নেই)।
- **Fingerprint**: Settings → Privacy (PIN-ই fallback)।
- **কোড**: Wallpaper/blur → `WallpaperTools.kt`, PIN hash → `PinHasher.kt`; নতুন ফিচার আলাদা ফাইলে।

## v3.4 — কোড গোছানো

`MainActivity.kt` ২৫৫১ লাইন থেকে ~১৭৯০ লাইনে নেমেছে; আচরণ একই, শুধু অংশগুলো আলাদা ফাইলে:

| ফাইল | কী আছে |
|---|---|
| `PinController.kt` | Hidden apps-এর PIN স্ক্রিন, ভুল হলে অপেক্ষা, fingerprint |
| `LaunchOverlay.kt` | অ্যাপ খোলা/বন্ধের গোল-কোণা পর্দা animation |
| `WidgetController.kt` | Today View: widget যোগ/সরানো/সাজানো |
| `WallpaperController.kt` | Wallpaper বদলানো (preset / গ্যালারি / সিস্টেম picker) |
| `DefaultLauncher.kt` | Default home app জিজ্ঞাসা ও মনে করানো |
| `ViewUtils.kt` | ছোট সাধারণ helper |

- নতুন ফিচার এখন সংশ্লিষ্ট ফাইলে যোগ করুন; `MainActivity` শুধু এদের জোড়া লাগায় (`Host` interface-এর মাধ্যমে)।
- Icon pack: `appfilter.xml`-এ ছোট ক্লাস-নাম (`pkg/.MainActivity`) থাকলেও এখন মেলে।
- **Double-tap lock**: Android 13+ এ APK সরাসরি ইনস্টল করলে Accessibility চালানোর আগে
  Settings → Apps → Aero Launcher → ⋮ → "Allow restricted settings" দিতে হতে পারে।

> v3.3 ও v3.4 কোনোটাই Android SDK দিয়ে build করে ফোনে চালিয়ে পরীক্ষা করা হয়নি।
> Kotlin কম্পাইলার দিয়ে শুধু syntax ও নামের মিল যাচাই করা হয়েছে — GitHub Actions-এ build করে আগে চালিয়ে দেখুন।
