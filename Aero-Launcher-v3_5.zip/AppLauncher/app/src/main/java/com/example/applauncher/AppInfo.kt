package com.example.applauncher

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build

/** icon আগে থেকেই ছোট Bitmap-এ রেন্ডার করা থাকে, তাই স্ক্রল করার সময় কোনো ভারী কাজ হয় না। */
data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: Bitmap
)

object IconRenderer {

    /** shape: 0 = iOS squircle, 1 = circle, 2 = rounded square, 3 = square */
    fun shapePath(shape: Int, rect: RectF): Path {
        val path = Path()
        when (shape) {
            1 -> path.addOval(rect, Path.Direction.CW)
            2 -> path.addRoundRect(rect, rect.width() * 0.22f, rect.width() * 0.22f, Path.Direction.CW)
            3 -> path.addRoundRect(rect, rect.width() * 0.06f, rect.width() * 0.06f, Path.Direction.CW)
            else -> {
                // iOS-এর "continuous corner": superellipse |x|^n + |y|^n = 1
                val n = 5.0
                val cx = rect.centerX()
                val cy = rect.centerY()
                val a = rect.width() / 2f
                val b = rect.height() / 2f
                val steps = 120
                for (i in 0..steps) {
                    val t = 2.0 * Math.PI * i / steps
                    val c = Math.cos(t)
                    val s = Math.sin(t)
                    val x = cx + a * Math.signum(c) * Math.pow(Math.abs(c), 2.0 / n)
                    val y = cy + b * Math.signum(s) * Math.pow(Math.abs(s), 2.0 / n)
                    if (i == 0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
                }
                path.close()
            }
        }
        return path
    }

    /** Icon pack-এর আইকন: আকৃতি কাটা/ছায়া ছাড়াই [size]×[size] Bitmap-এ আঁকে (pack নিজেই আকৃতি ঠিক করে)। */
    fun renderRaw(d: Drawable, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return out
    }

    /** Drawable-কে [size]×[size] আইকন Bitmap বানায়। Background thread-এ চালানো ভালো। */
    fun render(d: Drawable, size: Int, shape: Int = 0, shadow: Boolean = true): Bitmap {
        val raw = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(raw)
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            // Adaptive icon-এর layer ১০৮dp; মাঝের ৭২dp অংশটাই দেখা যায়
            val pad = (size * 0.25f).toInt()
            d.background?.let {
                it.setBounds(-pad, -pad, size + pad, size + pad)
                it.draw(c)
            }
            d.foreground?.let {
                it.setBounds(-pad, -pad, size + pad, size + pad)
                it.draw(c)
            }
        } else {
            d.setBounds(0, 0, size, size)
            d.draw(c)
        }

        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val inset = if (shadow) size * 0.06f else 0f
        val inner = size - 2 * inset
        val top = if (shadow) inset - size * 0.01f else 0f
        val shader = BitmapShader(raw, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).apply {
            setLocalMatrix(Matrix().apply {
                setScale(inner / size, inner / size)
                postTranslate(inset, top)
            })
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            this.shader = shader
            if (shadow) setShadowLayer(size * 0.04f, 0f, size * 0.025f, Color.argb(70, 0, 0, 0))
        }
        val rect = RectF(inset, top, inset + inner, top + inner)
        Canvas(out).drawPath(shapePath(shape, rect), paint)
        raw.recycle()
        return out
    }
}
