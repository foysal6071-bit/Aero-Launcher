package com.example.applauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.RectF
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils

/**
 * HyperOS-এর মতো: আইকন থেকে গোল-কোণা পর্দা spring-এ বড় হয়ে পুরো স্ক্রিন ভরে, তার ওপর অ্যাপ ফুটে ওঠে।
 * অ্যাপ বন্ধ করলে ([collapse]) পর্দা আবার সেই আইকনে ছোট হয়ে ফিরে যায়।
 */
class LaunchOverlay(
    private val activity: AppCompatActivity,
    private val settings: LauncherSettings,
    private val dur: (Int) -> Long
) {
    private val overlay: FrameLayout = activity.findViewById(R.id.launchOverlay)
    private val icon: ImageView = activity.findViewById(R.id.launchIcon)

    private var animator: ValueAnimator? = null
    private val rect = RectF()
    private val iconRect = RectF()
    private val iconBox = RectF()
    private var radius = 0f
    private var iconRadius = 0f
    private var color = Color.WHITE
    private var progress = 0f
    private var fromHome = true
    private var pausedSinceLaunch = false
    private var token = 0

    /** পর্দা এখন স্ক্রিনে আছে (অ্যাপ খোলা চলছে বা খোলা) */
    var active = false
        private set

    init {
        overlay.clipToOutline = true
        overlay.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val r = radius.coerceAtMost(minOf(rect.width(), rect.height()) / 2f)
                outline.setRoundRect(
                    rect.left.toInt(), rect.top.toInt(),
                    rect.right.toInt(), rect.bottom.toInt(), r.coerceAtLeast(0f)
                )
            }
        }
    }

    private fun dp(v: Int): Int = (v * activity.resources.displayMetrics.density).toInt()

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    /** Launcher pause হলে অ্যাপ সত্যিই খুলেছে — তখন "খুলল না" timeout আর কাজ করবে না */
    fun onPause() {
        pausedSinceLaunch = true
    }

    /** আইকনের গড় রং + সাদা/কালো মিশিয়ে অ্যাপ-পর্দার রং (অ্যাপ ফুটে ওঠা পর্যন্ত দেখায়)। */
    private fun colorFor(icon: Bitmap): Int {
        return try {
            val px = Bitmap.createScaledBitmap(icon, 1, 1, true).getPixel(0, 0)
            val base = if ((activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES) Color.parseColor("#121212") else Color.WHITE
            ColorUtils.blendARGB(Color.rgb(Color.red(px), Color.green(px), Color.blue(px)), base, 0.72f)
        } catch (_: Exception) {
            Color.WHITE
        }
    }

    /** t = 0 → আইকনের মাপ, t = 1 → পুরো স্ক্রিন */
    private fun applyFrame(t: Float) {
        progress = t
        val w = overlay.width.toFloat()
        val h = overlay.height.toFloat()
        rect.set(
            lerp(iconRect.left, 0f, t), lerp(iconRect.top, 0f, t),
            lerp(iconRect.right, w, t), lerp(iconRect.bottom, h, t)
        )
        // কোণার গোলতা দ্রুত কমে (HyperOS-এ আইকনের গোল কোণা আগে স্ক্রিনের কোণায় মিলে যায়)
        val tr = minOf(1f, t * 1.5f)
        radius = lerp(iconRadius, dp(36).toFloat(), tr)
        val alpha = (minOf(1f, t * 4f) * 255).toInt()
        overlay.setBackgroundColor(Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color)))
        overlay.invalidateOutline()
        val size = iconBox.width()
        val cx = lerp(iconBox.centerX(), w / 2f, t)
        val cy = lerp(iconBox.centerY(), h / 2f, t)
        val sc = lerp(1f, 1.8f, t)
        icon.translationX = cx - size / 2f
        icon.translationY = cy - size / 2f
        icon.scaleX = sc
        icon.scaleY = sc
        icon.alpha = (1f - t * 2.6f).coerceIn(0f, 1f)
    }

    /** [anchor] = যে আইকনে চাপা হয়েছে; [fromHome] = Home থেকে খুলছে (drawer/hidden থেকে নয়) */
    fun begin(app: AppInfo, anchor: View, fromHome: Boolean) {
        this.fromHome = fromHome
        val iv = anchor.findViewById<View>(R.id.appIcon) ?: anchor
        val a = IntArray(2)
        val b = IntArray(2)
        iv.getLocationOnScreen(a)
        (overlay.parent as View).getLocationOnScreen(b)
        val l = (a[0] - b[0]).toFloat()
        val t = (a[1] - b[1]).toFloat()
        val size = iv.width.toFloat().coerceAtLeast(1f)
        iconBox.set(l, t, l + size, t + size)
        val inset = if (settings.iconShadow) size * 0.06f else 0f
        iconRect.set(l + inset, t + inset, l + size - inset, t + size - inset)
        val inner = size - 2 * inset
        iconRadius = when (settings.iconShape) {
            1 -> inner / 2f
            2 -> inner * 0.22f
            3 -> inner * 0.06f
            else -> inner * 0.27f
        }
        color = colorFor(app.icon)
        icon.layoutParams = FrameLayout.LayoutParams(size.toInt(), size.toInt())
        icon.setImageBitmap(app.icon)
        animator?.cancel()
        overlay.visibility = View.VISIBLE
        overlay.alpha = 1f
        if (overlay.width == 0) {
            // প্রথমবার: layout না হওয়া পর্যন্ত অপেক্ষা
            overlay.post { runExpand() }
        } else {
            runExpand()
        }
        active = true
        pausedSinceLaunch = false
        val myToken = ++token
        // অ্যাপ না খুললে (যেমন ব্যর্থ হলে) overlay নিজে থেকে ফিরে আসে
        overlay.postDelayed({
            if (myToken == token && active && !pausedSinceLaunch) collapse()
        }, 1800)
    }

    private fun runExpand() {
        applyFrame(0f)
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur(480)
            interpolator = HyperSpring.OPEN
            addUpdateListener { applyFrame(it.animatedValue as Float) }
            start()
        }
    }

    /** পর্দা আইকনে ছোট হয়ে মিলিয়ে যায় (না থাকলে কিছু করে না) */
    fun collapse() {
        if (!active) return
        active = false
        animator?.cancel()
        if (overlay.visibility != View.VISIBLE) return
        if (!fromHome) {
            // drawer/hidden থেকে খোলা অ্যাপ: আইকন নেই, তাই শুধু ফিকে হয়ে যায়
            overlay.animate().alpha(0f).setDuration(dur(240)).withEndAction {
                overlay.visibility = View.GONE
                overlay.alpha = 1f
            }.start()
            return
        }
        val from = progress
        animator = ValueAnimator.ofFloat(from, 0f).apply {
            duration = dur(400)
            interpolator = HyperSpring.CLOSE
            addUpdateListener { applyFrame(it.animatedValue as Float) }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    overlay.visibility = View.GONE
                }
            })
            start()
        }
    }

    /** মেমরি ছাড়ার সময়: animation থামিয়ে সব লুকিয়ে ফেলে */
    fun reset() {
        animator?.cancel()
        overlay.visibility = View.GONE
        icon.setImageDrawable(null)
        active = false
    }
}
